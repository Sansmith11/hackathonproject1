# Treasury Pulse — Frontend Build Spec (for Claude Code)

> **How to use this file:** Save it as `docs/FRONTEND_SPEC.md` in an empty repo. Then tell Claude Code:
> *"Read docs/FRONTEND_SPEC.md. Do Phase 0 only, run it, verify the acceptance criteria, then stop and summarize."*
> Repeat phase by phase. Commit after every phase. Don't ask for the whole thing in one go.

---

## 0. Context for Claude Code

You are building the **frontend only** of *Treasury Pulse: Short-term Liquidity Manager*, a hackathon project (BNP Paribas use case). It is a Liquidity Command Center for a global treasury team: daily cash positions per entity/currency, a 30-day forecast with confidence intervals, liquidity gap vs thresholds, an alert matrix, what-if scenarios, scheduled SOD/EOD reports, role-based access, and an AI chatbot.

The backend (FastAPI) is being built separately. **The frontend must run fully on its own against a mock API (MSW)** that follows the API contract in Section 4 exactly, so swapping to the real backend is a one-line env change.

### Hard rules
- **No external network calls at runtime.** No CDN fonts, scripts, or analytics. Fonts via `@fontsource/*`. (Guardrail: no external cloud services.)
- **Synthetic data only.** The mock generator produces fake data; never hardcode real names or account numbers.
- **Working demo over perfection.** Prefer finished, wired-up screens over clever abstractions.
- **TypeScript strict mode.** No `any` except at JSON boundaries, validated with Zod.
- All money is handled as `number` in the minor-safe range for display; format with `Intl.NumberFormat`. Never do currency math in components; use `src/lib/`.

---

## 1. Tech stack (fixed — do not substitute)

| Concern | Choice |
|---|---|
| Build | Vite + React 18 + TypeScript (strict) |
| Styling | Tailwind CSS + CSS variables for theme tokens; light + dark mode |
| UI primitives | shadcn/ui (Radix-based), lucide-react icons |
| Routing | React Router v6 (data routers, `createBrowserRouter`) |
| Server state | TanStack Query v5 |
| Client state | Zustand (auth, global filters, scenario params, UI) |
| Forms | React Hook Form + Zod |
| Tables | TanStack Table v8 (sorting, filtering, pagination, column visibility) |
| Charts | Recharts (all charts incl. CI bands, stacked area, donut, sparklines) |
| CSV parsing (client preview) | PapaParse; SheetJS (`xlsx`) for .xlsx |
| Dates | date-fns |
| Mock API | MSW v2 (browser worker) + a seeded synthetic data generator |
| Chat streaming | `fetch` + ReadableStream for SSE-style token streaming (mocked) |
| Testing | Vitest + React Testing Library; Playwright for 3 smoke flows |
| Lint/format | ESLint (typescript-eslint, react-hooks) + Prettier |

---

## 2. Folder structure

```
treasury-pulse-frontend/
├─ .env.example                 # VITE_API_BASE_URL=/api, VITE_USE_MOCKS=true
├─ index.html
├─ src/
│  ├─ main.tsx                  # starts MSW if VITE_USE_MOCKS, renders <App/>
│  ├─ app/
│  │  ├─ App.tsx
│  │  ├─ router.tsx             # all routes + RoleGuard wrappers
│  │  └─ providers.tsx          # QueryClient, Theme, Toaster, Tooltip
│  ├─ api/
│  │  ├─ client.ts              # fetch wrapper: base URL, session header, Zod parse, ApiError
│  │  ├─ queryKeys.ts           # central query-key factory
│  │  └─ endpoints/             # one file per resource (positions.ts, forecast.ts, ...)
│  ├─ types/
│  │  ├─ domain.ts              # Transaction, Entity, Position, Forecast, Alert, ...
│  │  └─ schemas.ts             # Zod schemas mirroring domain.ts
│  ├─ lib/
│  │  ├─ format.ts              # money, %, dates, compact numbers
│  │  ├─ gap.ts                 # G = P - T, headroom %, surplus check
│  │  ├─ alerts.ts              # severity classification + band colors
│  │  ├─ permissions.ts         # role → capability matrix, can(user, action, scope)
│  │  └─ csv.ts                 # column mapping + validation for uploads
│  ├─ stores/
│  │  ├─ authStore.ts           # user, role, allowed entities/regions, session token
│  │  ├─ filterStore.ts         # region → entity → currency, date range, reporting ccy
│  │  ├─ scenarioStore.ts       # what-if params (synced to URL query string)
│  │  └─ uiStore.ts             # sidebar, theme
│  ├─ mocks/
│  │  ├─ browser.ts
│  │  ├─ handlers/              # one handler file per resource
│  │  └─ data/
│  │     ├─ generator.ts        # seeded PRNG; 8 entities, 10+ ccys, 12 months, ~50k txns
│  │     ├─ forecast.ts         # fake 30-day forecast w/ CI derived from history
│  │     └─ chat.ts             # canned, data-grounded chatbot replies
│  ├─ components/
│  │  ├─ ui/                    # shadcn primitives + EmptyState, ErrorState, KpiCard, MoneyCell
│  │  ├─ layout/                # AppShell, Sidebar, TopBar, EntitySelector, AlertBanner, RoleGuard
│  │  └─ charts/                # see Section 6
│  └─ features/
│     ├─ auth/                  # LoginPage
│     ├─ dashboard/             # DashboardPage + widgets
│     ├─ transactions/          # TransactionsPage
│     ├─ upload/                # UploadPage (wizard)
│     ├─ forecast/              # ForecastPage
│     ├─ liquidity/             # LiquidityGapPage
│     ├─ alerts/                # AlertsPage (live + history)
│     ├─ what-if/               # WhatIfPage
│     ├─ reports/               # ReportsPage (generate, schedule, history)
│     ├─ chat/                  # ChatPage + floating ChatDrawer
│     ├─ recommendations/       # RecommendationsPage (surplus + scored actions)
│     ├─ benchmarks/            # BenchmarksPage (MAPE/RMSE, timings)
│     └─ admin/                 # Users, Thresholds (alert matrix), Report scheduler config
└─ tests/ (e2e/)
```

Each feature folder contains: `XxxPage.tsx`, `components/`, `hooks.ts` (TanStack Query hooks for that feature), and optional `utils.ts`.

---

## 3. Domain types (`src/types/domain.ts`)

Mirror the dataset's data dictionary. Use string-literal unions, not enums.

```ts
export type Role = 'VIEWER' | 'ANALYST' | 'TREASURY_MANAGER' | 'ADMIN';
export type Region = 'APAC' | 'EMEA' | 'NAMER';
export type Direction = 'INFLOW' | 'OUTFLOW';
export type RiskRating = 'A' | 'B' | 'C' | 'D';
export type Severity = 'OK' | 'WARNING' | 'CRITICAL' | 'EMERGENCY';
export type AlertStatus = 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED';

export interface Entity {
  code: string;            // 4-char entity_code, e.g. "PARI"
  name: string;            // e.g. "BNPPARIBAS_PARIS"
  region: Region; country: string; city: string;
  baseCurrency: string;
}

export interface Transaction {
  transactionId: string; transactionDate: string; dueDate: string | null;
  entityCode: string; region: Region; country: string; city: string;
  accountType: string; accountNumber: string;   // masked in UI: ****1234
  currency: string; originalAmount: number; direction: Direction;
  productType: string; category: string; frequency: string; isRecurring: boolean;
  paymentMethod: string; counterparty: string; settlementStatus: string;
  department: string; counterpartyRiskRating: RiskRating;
  originCurrency: string; destinationCurrency: string; isCrossBorder: boolean;
  fxRate: number; maturityDate: string | null;
}

export interface DailyPosition {          // EOD snapshot per entity/currency
  date: string; entityCode: string; currency: string;
  openingBalance: number; inflows: number; outflows: number; closingBalance: number;
}

export interface ForecastPoint {
  date: string; projected: number; lower80: number; upper80: number;
  lower95: number; upper95: number; actual?: number;
}

export interface Forecast {
  entityCode: string; currency: string; model: 'PROPHET' | 'SARIMA';
  generatedAt: string; horizonDays: 30; points: ForecastPoint[];
  drivers?: ForecastDriver[];             // advanced: rationale
}

export interface ForecastDriver { date: string; label: string; amount: number; direction: Direction; }

export interface Threshold {
  id: string; scope: 'CURRENCY' | 'ENTITY' | 'REGION';
  entityCode?: string; region?: Region; currency: string;
  mode: 'ABSOLUTE' | 'PERCENT'; value: number;
}

export interface GapRow {
  date: string; entityCode: string; currency: string;
  projected: number; threshold: number; gap: number;        // gap = projected - threshold
  headroomPct: number; severity: Severity; isSurplus: boolean;
}

export interface Alert {
  id: string; createdAt: string; entityCode: string; currency: string;
  severity: Exclude<Severity, 'OK'>; gap: number; projected: number; threshold: number;
  forDate: string; status: AlertStatus; resolvedAt?: string; note?: string;
}

export interface ScenarioParams {
  paymentDelayDays: 0 | 1 | 2 | 3 | 4 | 5;
  capexShiftDays: number;                    // 0..30
  fxShockPct: Record<string, number>;        // e.g. { EUR: -5 } ; allowed ±5, ±10, ±15
  rateShockBps: -200 | -100 | -50 | 0 | 50 | 100 | 200;
  ratingDowngrades: Record<string, RiskRating>; // counterparty -> new rating
}

export interface ScenarioResult {
  baseline: ForecastPoint[]; scenario: ForecastPoint[];
  impact: { minGapBaseline: number; minGapScenario: number;
            overdraftCostDelta: number; fxGainLoss: number;
            interestDelta: number; deployableSurplusDelta: number; };
}

export interface Recommendation {
  id: string; action: 'ACCELERATE_COLLECTIONS' | 'DELAY_PAYMENTS' | 'INVEST_SURPLUS'
        | 'INTERCOMPANY_TRANSFER' | 'CASH_POOLING';
  title: string; rationale: string; entityCode: string; currency: string;
  expectedImpact: number; score: number; priority: 1 | 2 | 3;
}

export interface ReportSchedule {
  id: string; type: 'SOD' | 'EOD'; enabled: boolean; cron: string; timezone: string;
  formats: ('PDF' | 'CSV')[]; recipients: string[];
}

export interface User {
  id: string; name: string; email: string; role: Role;
  entityCodes: string[]; regions: Region[];   // data-isolation scope
}

export interface ChatMessage {
  id: string; role: 'user' | 'assistant'; content: string; createdAt: string;
  chart?: ChartSpec; actionPlan?: Recommendation[]; sources?: { label: string; ref: string }[];
}

export interface ChartSpec {
  kind: 'line' | 'bar' | 'area' | 'donut';
  title: string; xKey: string; series: { key: string; label: string }[];
  data: Record<string, string | number>[];
}
```

Every type gets a matching Zod schema in `schemas.ts`; `api/client.ts` parses every response.

---

## 4. API contract (mock with MSW; the real backend must match)

Base: `${VITE_API_BASE_URL}` (default `/api`). Auth: `X-Session-Token` header from `authStore`. Every list endpoint is server-scoped to the user's allowed entities; mocks must enforce this too (return 403 for out-of-scope `entityCode`).

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/login` | `{email}` → `{token, user}` (demo users, no password) |
| GET | `/auth/me` | current user |
| GET | `/entities` | entities in scope |
| GET | `/fx-rates?date=` | rates to reporting ccy |
| POST | `/uploads` | multipart CSV/XLSX → `{uploadId, rowsParsed, rowsRejected, errors[]}` |
| GET | `/uploads` | upload history |
| GET | `/transactions?entity=&currency=&direction=&from=&to=&q=&page=&pageSize=&sort=` | paginated |
| GET | `/positions/daily?entity=&currency=&from=&to=` | `DailyPosition[]` |
| GET | `/positions/summary?date=&reportingCcy=` | KPIs: total cash, by ccy, by region, # alerts |
| GET | `/positions/intraday?entity=&currency=&date=` | hourly inflow/outflow buckets |
| GET | `/forecast?entity=&currency=` | `Forecast` |
| GET | `/liquidity-gap?entity=&currency=&horizon=30` | `GapRow[]` |
| GET/POST/PUT/DELETE | `/thresholds` | alert matrix CRUD (Admin) |
| GET | `/alerts?status=&severity=&from=&to=` | alert history |
| PATCH | `/alerts/:id` | acknowledge / resolve with note |
| POST | `/scenarios/run` | `ScenarioParams + {entity, currency}` → `ScenarioResult` |
| GET | `/recommendations?entity=` | scored `Recommendation[]` + surplus list |
| POST | `/reports/generate` | `{type, format, entity?}` → file blob |
| GET | `/reports/history` | generated reports |
| GET/PUT | `/reports/schedules` | SOD/EOD schedule config |
| GET/POST/PUT | `/users` | Admin user + role assignment |
| POST | `/chat` | `{conversationId?, message, context}` → streamed tokens, final JSON chunk with optional `chart`/`actionPlan`/`sources` |
| GET | `/benchmarks` | `{mape, rmse, perEntity[], timings: {dashboardLoadMs, forecastMs, chatMs, parse10k, parse50k, parse100k}}` |

Errors: `{error: {code, message, details?}}` with proper HTTP status. The client throws a typed `ApiError`; a global handler shows a toast and, on 401, logs out.

---

## 5. Business logic in `src/lib/` (unit-test all of it)

```ts
// gap.ts
projected = prevBalance + (totalInflows - totalOutflows)   // P = B_prev + (In - Out)
gap = projected - threshold                                // G = P - T
headroomPct = (projected - threshold) / threshold * 100
isSurplus = projected > threshold * 1.2                    // > threshold + 20%

// alerts.ts — severity from headroom
projected < threshold OR projected < 0     → EMERGENCY  (red)
0  <= headroomPct < 5                      → CRITICAL   (red)
5  <= headroomPct < 10                     → WARNING    (amber)
headroomPct >= 10                          → OK         (green)
```

Default per-currency thresholds (seeded, Admin-editable): **EUR 50,000 · USD 60,000 · JPY 5,000,000 · GBP 40,000**. Other currencies: Admin must set one; until then show "No threshold" chip, not a fake value.

Threshold resolution order: ENTITY+CURRENCY → REGION+CURRENCY → CURRENCY default. `PERCENT` mode = percent of the 30-day average closing balance.

Band colors as tokens: `--band-ok`, `--band-warn`, `--band-crit` (works in dark mode).

---

## 6. Shared chart components (`src/components/charts/`)

All charts: responsive container, loading skeleton, empty state, tooltip with formatted money, currency-aware axis formatting, accessible title/description.

| Component | Used in | Spec |
|---|---|---|
| `CashPositionChart` | Dashboard | Line of daily closing balance, last 90 days |
| `ForecastChart` | Dashboard, Forecast, What-If | Actuals (solid) + projected (dashed) + 80% & 95% CI as stacked `Area` ranges; vertical "today" reference line; optional threshold line |
| `LiquidityGapChart` | Liquidity, Dashboard | Projected position line, threshold `ReferenceLine`, **alert bands** as `ReferenceArea` (green ≥10% above, amber 5–10%, red <5%/negative), breach dots on points where severity ≠ OK |
| `InflowOutflowAreaChart` | Dashboard | Stacked area, hourly inflows vs outflows; drill-down by entity/currency |
| `CurrencyDonut` | Dashboard | Position share by currency (converted to reporting ccy), % labels, click slice → filter |
| `Sparkline` | Position Trend Table | 30-day mini line, colored by trend |
| `ScenarioCompareChart` | What-If | Baseline vs scenario overlay + delta bars |
| `ChatChart` | Chat | Renders any `ChartSpec` from the bot |

---

## 7. Roles & permissions (`src/lib/permissions.ts`)

| Capability | Viewer | Analyst | Treasury Mgr | Admin |
|---|---|---|---|---|
| View dashboard/positions/forecast/gap/alerts (own scope) | ✅ | ✅ | ✅ | ✅ |
| Scope | assigned entities | assigned entities | assigned regions + drill to entities | all |
| Region-level aggregated view | ❌ | ❌ | ✅ | ✅ |
| Upload transactions | ❌ | ✅ | ✅ | ✅ |
| What-if scenarios | ❌ | ✅ | ✅ | ✅ |
| Generate/export reports | ❌ | ✅ | ✅ | ✅ |
| Acknowledge/resolve alerts | ❌ | ✅ | ✅ | ✅ |
| Chatbot | ✅ (read-only Qs) | ✅ | ✅ | ✅ |
| Alert matrix config | ❌ | ❌ | ❌ | ✅ |
| Report scheduler + recipients | ❌ | ❌ | ❌ | ✅ |
| User/role management | ❌ | ❌ | ❌ | ✅ |

Enforce in three places: `RoleGuard` on routes, `can()` to hide/disable controls (disabled buttons get a tooltip explaining why), and the `EntitySelector` only lists in-scope entities. Mocks enforce scope server-side too.

Seed demo users (login screen shows them as one-click cards): `viewer@demo`, `analyst.paris@demo` (EMEA entities), `manager.apac@demo` (APAC), `admin@demo`.

---

## 8. Routes & pages

```
/login
/                     → redirect /dashboard
/dashboard
/transactions
/upload               (Analyst+)
/forecast
/liquidity
/alerts
/what-if              (Analyst+)
/recommendations
/reports              (Analyst+)
/chat
/benchmarks
/admin/users          (Admin)
/admin/thresholds     (Admin)
/admin/schedules      (Admin)
```

**AppShell:** collapsible sidebar (icons + labels, grouped: Monitor / Analyze / Act / Admin), top bar with: global `EntitySelector` (Region → Entity hierarchical tree + Currency multi-select), date picker, reporting-currency switch (USD/EUR), alert bell with open count, theme toggle, user menu with role badge. A sticky **AlertBanner** appears under the top bar whenever any in-scope EMERGENCY/CRITICAL alert is OPEN. Floating chat button opens `ChatDrawer` from any page, pre-filled with current filters as context.

Global filters live in `filterStore` and are mirrored to the URL query string so any view is shareable/reloadable.

---

## 9. Build phases (do them in order; stop after each)

Every phase ends with: `npm run lint`, `npm run typecheck`, `npm test` all passing, the app running, and a short summary of what was built and what's stubbed.

### Phase 0 — Scaffold
1. Vite React-TS project, strict tsconfig, path alias `@/` → `src/`.
2. Tailwind + shadcn/ui init; theme tokens (incl. band colors) in `index.css`; dark mode via `class`.
3. Install all deps from Section 1. Self-hosted font via `@fontsource/inter` (+ a mono font for numbers, tabular-nums everywhere money appears).
4. ESLint, Prettier, Vitest, Playwright configured; npm scripts: `dev, build, preview, lint, typecheck, test, e2e`.
5. Folder structure from Section 2 with placeholder index files.

**Done when:** `npm run dev` shows a blank "Treasury Pulse" page; all scripts pass.

### Phase 1 — Types, API client, mock backend
1. Write `domain.ts` + `schemas.ts` (Section 3).
2. `api/client.ts`: fetch wrapper, token header, Zod validation, `ApiError`, 401 handling.
3. `mocks/data/generator.ts`: seeded PRNG (fixed seed → same data every reload). 8 entities across APAC/EMEA/NAMER, 10+ currencies, 12 months, ~50k transactions with realistic patterns: monthly payroll spikes, quarterly tax outflows, weekly supplier runs, a few large loan repayments with maturity dates, cross-border FX transactions, rating mix A–D. Derive `DailyPosition` snapshots from transactions. Generate lazily and cache in memory.
4. Mock forecast: seasonal naive projection from history + widening CI; inject 2–3 deliberate future shortfalls (e.g. EUR in Paris around day 3 from a loan repayment) so alerts and the chatbot have something to explain.
5. MSW handlers for every endpoint in Section 4 including scope enforcement, pagination, sorting, filtering, and 300–800 ms artificial latency.
6. Query-key factory + endpoint modules + one TanStack hook per endpoint.

**Done when:** a temporary debug page lists entities and the first page of transactions via real hooks; Zod parsing tests pass for every schema.

### Phase 2 — Auth, RBAC, layout shell
1. LoginPage with demo-user cards; `authStore` persisted to `sessionStorage`.
2. `permissions.ts` + unit tests for the full matrix in Section 7.
3. Router with `RoleGuard` (redirect to `/login` if not authed, to a 403 page if not permitted).
4. AppShell, Sidebar (items hidden per role), TopBar, `EntitySelector` (hierarchical, scoped), `filterStore` ⇄ URL sync.
5. Placeholder pages for every route.

**Done when:** logging in as each demo user shows only their allowed nav items and entities; deep-linking to a forbidden route shows 403.

### Phase 3 — Data ingestion & transactions
1. **UploadPage** as a 4-step wizard: (a) drop CSV/XLSX, (b) client-side preview of first 50 rows with auto column-mapping to the data dictionary and manual override, (c) validation report (missing required columns, bad dates, non-numeric amounts, unknown currencies) with downloadable error CSV, (d) submit to `/uploads` with progress, then show parsed/rejected counts. Upload history table below.
2. **TransactionsPage**: TanStack Table, server-side pagination/sort/filter; filters for entity, currency, direction, category, product type, settlement status, rating, date range, free-text search; column visibility toggle; masked account numbers; inflow green / outflow red amounts; row click opens a side sheet with full detail; CSV export of current filter.

**Done when:** uploading a sample CSV (generate one in `public/sample-transactions.csv`) shows preview → validation → success; table handles 50k rows smoothly.

### Phase 4 — Dashboard
Top-to-bottom layout:
1. **KPI row:** total cash (reporting ccy), # entities in shortfall, # open alerts by severity, deployable surplus total, forecast min-gap next 30d.
2. **CashPositionChart + ForecastChart** side by side for the selected entity/currency.
3. **LiquidityGapChart** with alert bands and live gap readout (`Gap = Projected − Threshold`).
4. **InflowOutflowAreaChart** (hourly) + **CurrencyDonut**.
5. **Position Trend Table:** entity × currency rows, current position, threshold, gap, headroom %, severity chip, 30-day sparkline, click → drill to that entity.
6. Treasury Manager sees a **Region summary strip** (APAC / EMEA / NAMER cards) above, clicking drills into entities.

Every widget has its own skeleton/error/empty state; one failing widget never breaks the page.

**Done when:** switching entity/currency/region updates every widget; band colors match `alerts.ts`.

### Phase 5 — Forecast & Liquidity Gap pages
1. **ForecastPage:** entity/currency picker, large `ForecastChart` with 80/95% toggle, model badge (Prophet/SARIMA), generated-at timestamp, forecast table (date, projected, lower, upper), and a **Forecast Rationale** panel listing `drivers` ("Shortfall driven by 3 large loan repayments on Day 3"). Show counterparty-rating legend explaining wider bands for C/D-rated flows.
2. **LiquidityGapPage:** 30-day gap table for all in-scope entity×currency combos (sortable by worst gap), heatmap view (rows = entity/ccy, cols = days, cell color = severity), and `LiquidityGapChart` for the selected row. Surplus rows get a "Deployable surplus" badge.

**Done when:** the seeded EUR/Paris shortfall is visible on both pages and its rationale is shown.

### Phase 6 — Alert system
1. **AlertsPage** with two tabs: *Live* (current breaches grouped by severity, cards with entity, ccy, projected, threshold, gap, for-date) and *History* (table: timestamp, severity, entity, ccy, gap, status, resolved-at, note; filters + export).
2. Acknowledge / resolve actions with note (Analyst+), optimistic updates.
3. **AlertBanner** + bell count driven by a query refetching every 60 s (mock "hourly evaluation" — in demo, add a dev button "Run evaluation now").
4. **Admin › Thresholds (alert matrix):** grid of entity/region × currency with editable value and ABSOLUTE/PERCENT toggle; shows resolved effective threshold and its source (entity / region / currency default); warning-band % values (5/10) editable; Zod-validated; save with diff confirmation.

**Done when:** lowering a threshold in Admin immediately changes severities on Dashboard, Gap and Alerts pages.

### Phase 7 — What-If analysis
1. **WhatIfPage** layout: left control panel, right results.
2. Controls: Payment delay slider (+0…+5 days), Capex postponement slider (0…30 days) with list of capex items to include, FX shock per currency (segmented: −15/−10/−5/0/+5/+10/+15 %), Interest-rate shock (−200…+200 bps, applies to loan/deposit flows), Counterparty rating shift (pick counterparty → new rating). "Reset to baseline" button. Params mirrored to URL.
3. Debounced (400 ms) call to `/scenarios/run`.
4. Results: `ScenarioCompareChart` baseline vs scenario, impact cards (min gap Δ, overdraft cost Δ, FX gain/loss, interest income/expense Δ, deployable surplus Δ), side-by-side table per day, and "Ask the assistant about this scenario" button that opens chat with the params as context.
5. Save/load named scenarios (local per user is fine).

**Done when:** a +3 day delay on the Paris EUR entity visibly changes the gap and impact cards.

### Phase 8 — Reporting
1. **ReportsPage:** "Generate now" (SOD / EOD, PDF / CSV, entity scope) → downloads the blob; report history table with re-download.
2. Report preview pane rendering what SOD contains (opening position, payments next 24–48 h, forecast outlook, overnight alerts) and EOD (position summary, forecast, alerts triggered, gap status) — use the same components, print-friendly CSS.
3. User-level toggles: enable/disable SOD and EOD for themselves.
4. **Admin › Schedules:** per report type: enabled, time + timezone (human-friendly picker that writes cron), formats, recipients (email chip input with validation), "Send test" button (mock).

**Done when:** an Analyst can generate and download both report types; Admin can edit schedules; non-admins can't reach Admin pages.

### Phase 9 — Admin users
**Admin › Users:** table of users, create/edit dialog (name, email, role, entity scope multi-select, region scope), role change takes effect on that user's next login. Guard against removing the last Admin.

### Phase 10 — AI chatbot (advanced)
1. **ChatPage** (full screen) + **ChatDrawer** (from anywhere) sharing one `useChat` hook.
2. Streaming token rendering, stop button, retry, markdown rendering for replies, conversation list (local), new chat.
3. Context chips above the input showing what's sent (entity, currency, date, active scenario); user can remove chips.
4. Suggested prompts: "Why is there a shortfall in EUR next week?", "What if we delay payments by 3 days?", "What's my surplus position in APAC?", "What action plan do you recommend?".
5. Rich message parts: `ChatChart` for `chart`, an **Action Plan** card for `actionPlan` (prioritized list with expected impact and "Open in What-If" link), and a **Sources** footer listing the data the answer was grounded in (RAG).
6. Follow-ups keep `conversationId`; clicking an entity/currency mentioned in a reply drills into it.
7. Mock `/chat` returns grounded canned answers built from the generated data (actual numbers from the mock store, not lorem ipsum).

**Done when:** all four suggested prompts return sensible, data-consistent answers, one of them with a chart and one with an action plan.

### Phase 11 — Recommendations & surplus (advanced)
**RecommendationsPage:** surplus table (entities with projected > threshold +20%, deployable amount), scored action cards (accelerate collections, delay non-urgent payments, invest surplus short-term, inter-entity/currency transfer, cash pooling) sorted by score with expected liquidity impact, filter by entity/action type, "Simulate" button that pre-fills What-If.

### Phase 12 — Benchmarks (advanced)
**BenchmarksPage:** MAPE and RMSE overall and per entity (bar chart + table), forecast vs actual backtest chart, timing cards (dashboard load, forecast gen, chat response, parse 10k/50k/100k). Also measure real frontend timings with `performance.now()` around dashboard first-load and show them alongside backend numbers.

### Phase 13 — Polish & demo readiness
1. Keyboard navigation and focus states; ARIA labels on charts; color is never the only signal (severity chips have icons + text).
2. Responsive down to 1280 px laptop and usable on tablet; sidebar collapses.
3. Code-split routes with `React.lazy`; memoize heavy chart data; virtualize long tables.
4. Error boundary per route + global fallback.
5. Playwright smoke tests: (a) analyst logs in → dashboard shows EUR shortfall alert; (b) upload sample CSV succeeds; (c) what-if delay changes the gap.
6. `README.md`: setup, env vars, demo users, how to switch from mocks to real backend, screenshot list for the demo video.
7. A **Demo mode** toggle in the user menu that resets mock data to the seed and walks through the shortfall story.

---

## 10. UX & visual guidelines
- Finance-grade, calm and dense: neutral surfaces, one accent color, color reserved for status (green/amber/red bands).
- Numbers right-aligned, tabular figures, compact format on cards (€1.2M) with full value in tooltip.
- Always show the currency code next to amounts; show reporting-currency conversions with the FX rate and date in a tooltip.
- Every page states its data freshness ("As of 10 Oct 2026, 16:00 IST").
- Empty states explain what to do next ("No transactions yet — upload a CSV").
- Loading: skeletons, never spinners on whole pages.

---

## 11. Definition of done (frontend)
- **Core:** CSV upload + parsing, transactions table, dashboard with daily cash position, 30-day forecast with CIs, entity filter, liquidity gap table, alert matrix, what-if sliders, role-based access with entity isolation, SOD/EOD reports (PDF + CSV) with scheduler UI.
- **Advanced:** chatbot with RAG sources, charts and action plans; recommendation engine UI; benchmarks page.
- Runs fully offline with `VITE_USE_MOCKS=true`; switches to the real API with `VITE_USE_MOCKS=false`.
