import { expect, test, type Page } from '@playwright/test';

async function loginAs(page: Page, email: string) {
  await page.goto('/login');
  await page.getByText(email, { exact: true }).click();
  await expect(page).toHaveURL(/dashboard/);
}

test('analyst sees the Paris EUR shortfall alert on the dashboard', async ({ page }) => {
  await loginAs(page, 'analyst.paris@demo');
  const banner = page.getByRole('alert').first();
  await expect(banner).toContainText(/open alerts? need attention/i, { timeout: 20_000 });
  await expect(banner).toContainText('PARI EUR');
});

test('analyst uploads the sample CSV', async ({ page }) => {
  await loginAs(page, 'analyst.paris@demo');
  await page.goto('/upload');
  await page.getByTestId('file-input').setInputFiles('public/sample-transactions.csv');
  await page.getByRole('button', { name: 'Validate' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Submit upload' }).click();
  await expect(page.getByTestId('upload-success')).toContainText('197 rows parsed', { timeout: 20_000 });
});

test('what-if payment delay changes the gap', async ({ page }) => {
  await loginAs(page, 'analyst.paris@demo');
  await page.goto('/what-if?entity=PARI&ccy=EUR');
  const minGap = page.getByTestId('impact-cards').locator('div').filter({ hasText: 'Min gap Δ' }).first();
  await expect(minGap).toContainText(/EUR 0$/, { timeout: 20_000 });
  await page.getByLabel('Payment delay days').fill('3');
  await expect(minGap).not.toContainText(/EUR 0$/, { timeout: 20_000 });
});
