import { create } from 'zustand';
import type { Region } from '@/types/domain';

export type ReportingCcy = 'USD' | 'EUR';

export interface FilterState {
  region: Region | null;
  entity: string | null;
  currencies: string[];
  from: string | null;
  to: string | null;
  reportingCcy: ReportingCcy;
  set: (patch: Partial<Omit<FilterState, 'set' | 'reset'>>) => void;
  reset: () => void;
}

const initial = {
  region: null,
  entity: null,
  currencies: [],
  from: null,
  to: null,
  reportingCcy: 'USD' as ReportingCcy,
};

export const useFilterStore = create<FilterState>()((set) => ({
  ...initial,
  set: (patch) => set(patch),
  reset: () => set(initial),
}));

export function filtersToSearch(f: Pick<FilterState, 'region' | 'entity' | 'currencies' | 'from' | 'to' | 'reportingCcy'>) {
  const p = new URLSearchParams();
  if (f.region) p.set('region', f.region);
  if (f.entity) p.set('entity', f.entity);
  if (f.currencies.length) p.set('ccy', f.currencies.join(','));
  if (f.from) p.set('from', f.from);
  if (f.to) p.set('to', f.to);
  if (f.reportingCcy !== 'USD') p.set('rep', f.reportingCcy);
  return p;
}

export function searchToFilters(p: URLSearchParams): Partial<FilterState> {
  const out: Partial<FilterState> = {};
  const region = p.get('region');
  if (region === 'APAC' || region === 'EMEA' || region === 'NAMER') out.region = region;
  const entity = p.get('entity');
  if (entity) out.entity = entity;
  const ccy = p.get('ccy');
  if (ccy) out.currencies = ccy.split(',').filter(Boolean);
  if (p.get('from')) out.from = p.get('from');
  if (p.get('to')) out.to = p.get('to');
  const rep = p.get('rep');
  if (rep === 'EUR' || rep === 'USD') out.reportingCcy = rep;
  return out;
}
