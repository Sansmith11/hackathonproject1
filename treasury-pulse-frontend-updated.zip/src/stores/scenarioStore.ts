import { create } from 'zustand';
import type { RiskRating, ScenarioParams } from '@/types/domain';

export const BASELINE: ScenarioParams = {
  paymentDelayDays: 0,
  capexShiftDays: 0,
  fxShockPct: {},
  rateShockBps: 0,
  ratingDowngrades: {},
};

interface ScenarioState {
  params: ScenarioParams;
  setParams: (p: Partial<ScenarioParams>) => void;
  replace: (p: ScenarioParams) => void;
  reset: () => void;
}

export const useScenarioStore = create<ScenarioState>()((set) => ({
  params: BASELINE,
  setParams: (p) => set((s) => ({ params: { ...s.params, ...p } })),
  replace: (params) => set({ params }),
  reset: () => set({ params: BASELINE }),
}));

export function isBaseline(p: ScenarioParams): boolean {
  return (
    p.paymentDelayDays === 0 &&
    p.capexShiftDays === 0 &&
    p.rateShockBps === 0 &&
    Object.values(p.fxShockPct).every((v) => v === 0) &&
    Object.keys(p.ratingDowngrades).length === 0
  );
}

export function paramsToSearch(p: ScenarioParams): URLSearchParams {
  const s = new URLSearchParams();
  if (p.paymentDelayDays) s.set('delay', String(p.paymentDelayDays));
  if (p.capexShiftDays) s.set('capex', String(p.capexShiftDays));
  if (p.rateShockBps) s.set('rate', String(p.rateShockBps));
  const fx = Object.entries(p.fxShockPct).filter(([, v]) => v !== 0);
  if (fx.length) s.set('fx', fx.map(([c, v]) => `${c}:${v}`).join(','));
  const dg = Object.entries(p.ratingDowngrades);
  if (dg.length) s.set('dg', dg.map(([c, r]) => `${c}:${r}`).join(','));
  return s;
}

export function searchToParams(s: URLSearchParams): ScenarioParams {
  const delay = Math.min(5, Math.max(0, Number(s.get('delay') ?? 0))) as ScenarioParams['paymentDelayDays'];
  const rates = [-200, -100, -50, 0, 50, 100, 200];
  const rate = Number(s.get('rate') ?? 0);
  const fxShockPct: Record<string, number> = {};
  for (const part of (s.get('fx') ?? '').split(',').filter(Boolean)) {
    const [c, v] = part.split(':');
    if (c && !Number.isNaN(Number(v))) fxShockPct[c] = Number(v);
  }
  const ratingDowngrades: Record<string, RiskRating> = {};
  for (const part of (s.get('dg') ?? '').split(',').filter(Boolean)) {
    const [c, r] = part.split(':');
    if (c && ['A', 'B', 'C', 'D'].includes(r)) ratingDowngrades[c] = r as RiskRating;
  }
  return {
    paymentDelayDays: Number.isNaN(delay) ? 0 : delay,
    capexShiftDays: Math.min(30, Math.max(0, Number(s.get('capex') ?? 0)) || 0),
    rateShockBps: (rates.includes(rate) ? rate : 0) as ScenarioParams['rateShockBps'],
    fxShockPct,
    ratingDowngrades,
  };
}
