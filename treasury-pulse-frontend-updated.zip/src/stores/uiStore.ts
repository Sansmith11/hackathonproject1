import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Theme = 'light' | 'dark' | 'system';

interface UiState {
  sidebarCollapsed: boolean;
  theme: Theme;
  chatOpen: boolean;
  chatSeed: string | null;
  toggleSidebar: () => void;
  setTheme: (t: Theme) => void;
  openChat: (seed?: string) => void;
  closeChat: () => void;
  clearSeed: () => void;
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      theme: 'system',
      chatOpen: false,
      chatSeed: null,
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setTheme: (theme) => set({ theme }),
      openChat: (seed) => set({ chatOpen: true, chatSeed: seed ?? null }),
      closeChat: () => set({ chatOpen: false }),
      clearSeed: () => set({ chatSeed: null }),
    }),
    {
      name: 'tp-ui',
      partialize: (s) => ({ sidebarCollapsed: s.sidebarCollapsed, theme: s.theme }),
    },
  ),
);

export function applyTheme(theme: Theme): void {
  const dark =
    theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('dark', dark);
}
