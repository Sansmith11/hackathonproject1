import { useMemo, useState } from 'react';
import { CheckCheck, Download, Eye } from 'lucide-react';
import { useAlertMutation, useAlerts } from '@/api/hooks';
import { MoneyCell, SeverityChip } from '@/components/ui/display';
import { EmptyState, QueryBoundary } from '@/components/ui/feedback';
import { Dialog, Tabs, TabsContent } from '@/components/ui/overlay';
import { Badge, Button, Card, Input, PageHeader, Select } from '@/components/ui/primitives';
import { useScopeFilter } from '@/hooks/useScopeFilter';
import { downloadText } from '@/lib/csv';
import { formatDate, formatDateTime } from '@/lib/format';
import { can, whyDenied } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import type { Alert, AlertStatus } from '@/types/domain';
import { toast } from '@/components/ui/toast';
import Papa from 'papaparse';

const ORDER = ['EMERGENCY', 'CRITICAL', 'WARNING'] as const;

function StatusBadge({ s }: { s: AlertStatus }) {
  return <Badge tone={s === 'OPEN' ? 'crit' : s === 'ACKNOWLEDGED' ? 'warn' : 'ok'}>{s.toLowerCase()}</Badge>;
}

export default function AlertsPage() {
  const user = useAuthStore((s) => s.user);
  const canAck = can(user, 'ack_alerts');
  const [tab, setTab] = useState('live');
  const [status, setStatus] = useState('');
  const [severity, setSeverity] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [target, setTarget] = useState<{ alert: Alert; action: AlertStatus } | null>(null);
  const [note, setNote] = useState('');
  const matches = useScopeFilter();
  const mut = useAlertMutation();

  const liveQ = useAlerts({}, 60_000);
  const histQ = useAlerts({ status, severity, from, to });
  const live = useMemo(
    () => (liveQ.data ?? []).filter((a) => a.status !== 'RESOLVED' && matches(a.entityCode, a.currency)),
    [liveQ.data, matches],
  );
  const history = useMemo(() => (histQ.data ?? []).filter((a) => matches(a.entityCode, a.currency)), [histQ.data, matches]);

  const submit = () => {
    if (!target) return;
    mut.mutate(
      { id: target.alert.id, status: target.action, note: note || undefined },
      { onSuccess: () => toast(`Alert ${target.action.toLowerCase()}`, 'success') },
    );
    setTarget(null);
    setNote('');
  };

  const exportCsv = () =>
    downloadText(
      'alert-history.csv',
      Papa.unparse(history.map((a) => ({ createdAt: a.createdAt, severity: a.severity, entity: a.entityCode, currency: a.currency, gap: a.gap, status: a.status, resolvedAt: a.resolvedAt ?? '', note: a.note ?? '' }))),
    );

  return (
    <div>
      <PageHeader title="Alerts" description="Live breaches and history" />
      <Tabs
        value={tab}
        onValueChange={setTab}
        tabs={[
          { value: 'live', label: `Live (${live.length})` },
          { value: 'history', label: 'History' },
        ]}
      >
        <TabsContent value="live">
          <QueryBoundary query={liveQ} isEmpty={() => live.length === 0} empty={<Card><EmptyState title="No open alerts" hint="All in-scope positions are above their thresholds." /></Card>}>
            {() => (
              <div className="space-y-5">
                {ORDER.map((sev) => {
                  const list = live.filter((a) => a.severity === sev);
                  if (!list.length) return null;
                  return (
                    <section key={sev} aria-label={`${sev} alerts`}>
                      <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold">
                        <SeverityChip severity={sev} /> <span className="text-muted-foreground">{list.length}</span>
                      </h2>
                      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                        {list.map((a) => (
                          <Card key={a.id} className="p-4">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold">
                                {a.entityCode} · {a.currency}
                              </span>
                              <StatusBadge s={a.status} />
                            </div>
                            <dl className="mt-3 grid grid-cols-2 gap-y-1.5 text-xs">
                              <dt className="text-muted-foreground">For date</dt>
                              <dd className="text-right">{formatDate(a.forDate)}</dd>
                              <dt className="text-muted-foreground">Projected</dt>
                              <dd className="text-right"><MoneyCell amount={a.projected} currency={a.currency} /></dd>
                              <dt className="text-muted-foreground">Threshold</dt>
                              <dd className="text-right"><MoneyCell amount={a.threshold} currency={a.currency} /></dd>
                              <dt className="text-muted-foreground">Gap</dt>
                              <dd className="text-right"><MoneyCell amount={a.gap} currency={a.currency} tone="auto" className="font-semibold" /></dd>
                            </dl>
                            {a.note && <p className="mt-2 rounded bg-muted px-2 py-1 text-xs">{a.note}</p>}
                            <div className="mt-3 flex gap-2">
                              <Button size="sm" disabled={a.status !== 'OPEN'} disabledReason={canAck ? undefined : whyDenied('ack_alerts')} onClick={() => setTarget({ alert: a, action: 'ACKNOWLEDGED' })}>
                                <Eye className="h-3.5 w-3.5" /> Acknowledge
                              </Button>
                              <Button size="sm" variant="primary" disabledReason={canAck ? undefined : whyDenied('ack_alerts')} onClick={() => setTarget({ alert: a, action: 'RESOLVED' })}>
                                <CheckCheck className="h-3.5 w-3.5" /> Resolve
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </section>
                  );
                })}
              </div>
            )}
          </QueryBoundary>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <div className="flex flex-wrap items-end gap-3 border-b border-border p-3">
              <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="">All statuses</option>
                {['OPEN', 'ACKNOWLEDGED', 'RESOLVED'].map((s) => <option key={s}>{s}</option>)}
              </Select>
              <Select aria-label="Severity" value={severity} onChange={(e) => setSeverity(e.target.value)}>
                <option value="">All severities</option>
                {ORDER.map((s) => <option key={s}>{s}</option>)}
              </Select>
              <Input aria-label="From" type="date" className="w-40" value={from} onChange={(e) => setFrom(e.target.value)} />
              <Input aria-label="To" type="date" className="w-40" value={to} onChange={(e) => setTo(e.target.value)} />
              <Button className="ml-auto" onClick={exportCsv} disabled={history.length === 0}>
                <Download className="h-4 w-4" /> Export CSV
              </Button>
            </div>
            <QueryBoundary query={histQ} isEmpty={() => history.length === 0} empty={<EmptyState title="No alerts match these filters" />}>
              {() => (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-left text-xs text-muted-foreground">
                      <tr>
                        {['Created', 'Severity', 'Entity', 'Ccy', 'Gap', 'Status', 'Resolved', 'Note'].map((h) => (
                          <th key={h} className={`px-3 py-2 font-medium ${h === 'Gap' ? 'text-right' : ''}`}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {history.map((a) => (
                        <tr key={a.id} className="border-t border-border">
                          <td className="px-3 py-2">{formatDateTime(a.createdAt)}</td>
                          <td className="px-3 py-2"><SeverityChip severity={a.severity} /></td>
                          <td className="px-3 py-2 font-medium">{a.entityCode}</td>
                          <td className="px-3 py-2">{a.currency}</td>
                          <td className="px-3 py-2 text-right"><MoneyCell amount={a.gap} currency={a.currency} tone="auto" compact /></td>
                          <td className="px-3 py-2"><StatusBadge s={a.status} /></td>
                          <td className="px-3 py-2">{a.resolvedAt ? formatDateTime(a.resolvedAt) : '—'}</td>
                          <td className="px-3 py-2 text-muted-foreground">{a.note ?? ''}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </QueryBoundary>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog
        open={!!target}
        onOpenChange={(o) => !o && setTarget(null)}
        title={target?.action === 'RESOLVED' ? 'Resolve alert' : 'Acknowledge alert'}
        description={target ? `${target.alert.entityCode} ${target.alert.currency} · ${target.alert.severity}` : undefined}
        footer={
          <>
            <Button onClick={() => setTarget(null)}>Cancel</Button>
            <Button variant="primary" onClick={submit}>Confirm</Button>
          </>
        }
      >
        <label className="mb-1 block text-xs font-medium text-muted-foreground">Note (optional)</label>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={4}
          className="w-full rounded-md border border-border bg-surface p-2 text-sm"
          placeholder="e.g. Intercompany funding arranged with FRAN"
        />
      </Dialog>
    </div>
  );
}
