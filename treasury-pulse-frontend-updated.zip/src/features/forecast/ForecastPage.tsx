import { useMemo, useState } from 'react';
import { Info } from 'lucide-react';
import { useDailyPositions, useForecast, useGap } from '@/api/hooks';
import { ForecastChart } from '@/components/charts';
import { PairPicker } from '@/components/layout/PairPicker';
import { MoneyCell } from '@/components/ui/display';
import { DataFreshness, EmptyState, Widget } from '@/components/ui/feedback';
import { Badge, Card, CardHeader, PageHeader, Switch } from '@/components/ui/primitives';
import { shiftDate, useFocus, useLatestPositions } from '@/hooks/useFocus';
import { formatDate, formatMoney } from '@/lib/format';
import type { Forecast } from '@/types/domain';

function Rationale({ f }: { f: Forecast }) {
  const out = (f.drivers ?? []).filter((d) => d.direction === 'OUTFLOW');
  const inn = (f.drivers ?? []).filter((d) => d.direction === 'INFLOW');
  const byDate = new Map<string, typeof out>();
  for (const d of out) byDate.set(d.date, [...(byDate.get(d.date) ?? []), d]);
  const first = f.points[0]?.date;
  const dayOf = (d: string) => Math.round((Date.parse(d) - Date.parse(first)) / 86_400_000) + 1;
  return (
    <Card>
      <CardHeader title="Forecast rationale" description="Scheduled flows that move the projection" />
      <div className="space-y-3 p-4 text-sm">
        {out.length === 0 && <p className="text-muted-foreground">No unusual scheduled flows — projection follows the seasonal pattern.</p>}
        {[...byDate].map(([date, list]) => (
          <div key={date}>
            <p className="font-medium">
              Shortfall driven by {list.length} large outflow{list.length > 1 ? 's' : ''} on Day {dayOf(date)} ({formatDate(date)})
            </p>
            <ul className="mt-1 space-y-0.5 text-muted-foreground">
              {list.map((d) => (
                <li key={d.label} className="flex justify-between gap-4">
                  <span>{d.label}</span>
                  <MoneyCell amount={d.amount} currency={f.currency} tone="outflow" />
                </li>
              ))}
            </ul>
          </div>
        ))}
        {inn.map((d) => (
          <p key={d.label} className="text-muted-foreground">
            Recovery: {d.label} of <MoneyCell amount={d.amount} currency={f.currency} tone="inflow" /> expected {formatDate(d.date)}.
          </p>
        ))}
        <div className="flex items-start gap-2 rounded-md bg-muted p-3 text-xs">
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          <div>
            <p className="font-medium">Counterparty ratings and band width</p>
            <p className="mt-0.5 text-muted-foreground">
              Flows from C- and D-rated counterparties are less certain, so confidence bands widen with their share of flows —
              currently {Math.round((f.lowRatedShare ?? 0) * 100)}% of this position's volume.
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
}

export default function ForecastPage() {
  const focus = useFocus();
  const [band, setBand] = useState<'80' | '95'>('95');
  const [show80, setShow80] = useState(true);
  const forecast = useForecast(focus.entity, focus.currency);
  const gap = useGap({ entity: focus.entity, currency: focus.currency });
  const latest = useLatestPositions();
  const history = useDailyPositions({
    entity: focus.entity,
    currency: focus.currency,
    from: latest.asOfDate ? shiftDate(latest.asOfDate, -59) : undefined,
  });
  const threshold = gap.data?.[0]?.threshold ?? null;
  const rows = useMemo(
    () =>
      (forecast.data?.points ?? []).map((p) => ({
        date: p.date,
        projected: p.projected,
        lower: band === '95' ? p.lower95 : p.lower80,
        upper: band === '95' ? p.upper95 : p.upper80,
      })),
    [forecast.data, band],
  );

  return (
    <div>
      <PageHeader
        title="Cash forecast"
        description="30-day projection with confidence intervals"
        actions={
          <>
            <PairPicker />
          </>
        }
      />
      {!focus.ready ? (
        <EmptyState title="Select an entity and currency" />
      ) : (
        <div className="space-y-4">
          <Widget
            title={
              <span className="flex items-center gap-2">
                {focus.entity} · {focus.currency}
                {forecast.data && <Badge tone="accent">{forecast.data.model === 'PROPHET' ? 'Prophet' : 'SARIMA'}</Badge>}
              </span>
            }
            description={forecast.data ? `Generated ${formatDate(forecast.data.generatedAt, 'dd MMM yyyy, HH:mm')} UTC` : undefined}
            actions={
              <div className="flex items-center gap-3 text-xs">
                <label className="flex items-center gap-1.5">
                  <Switch checked={show80} onChange={setShow80} label="Show 80% band" /> 80%
                </label>
                <div className="flex rounded-md border border-border">
                  {(['80', '95'] as const).map((b) => (
                    <button key={b} onClick={() => setBand(b)} aria-pressed={band === b} className={`px-2 py-1 ${band === b ? 'bg-accent text-accent-foreground' : ''}`}>
                      {b}% table
                    </button>
                  ))}
                </div>
                <DataFreshness asOf={latest.asOfDate ? `${latest.asOfDate}T16:00:00` : undefined} />
              </div>
            }
            query={forecast}
            height="h-96"
          >
            {(f) => <ForecastChart history={history.data} forecast={f} threshold={threshold} show80={show80} height={380} historyDays={45} />}
          </Widget>

          <div className="grid gap-4 xl:grid-cols-3">
            <Card className="xl:col-span-2">
              <CardHeader title="Forecast table" description={`${band}% confidence interval`} />
              <div className="max-h-96 overflow-auto">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-surface text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="px-4 py-2 font-medium">Date</th>
                      <th className="px-2 py-2 text-right font-medium">Projected</th>
                      <th className="px-2 py-2 text-right font-medium">Lower</th>
                      <th className="px-4 py-2 text-right font-medium">Upper</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.date} className="border-t border-border">
                        <td className="px-4 py-1.5">{formatDate(r.date, 'EEE dd MMM')}</td>
                        <td className="px-2 py-1.5 text-right">
                          <MoneyCell amount={r.projected} currency={focus.currency!} tone={threshold != null && r.projected < threshold ? 'outflow' : undefined} />
                        </td>
                        <td className="num px-2 py-1.5 text-right text-muted-foreground">{formatMoney(r.lower, focus.currency!, { compact: true })}</td>
                        <td className="num px-4 py-1.5 text-right text-muted-foreground">{formatMoney(r.upper, focus.currency!, { compact: true })}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
            {forecast.data && <Rationale f={forecast.data} />}
          </div>
        </div>
      )}
    </div>
  );
}
