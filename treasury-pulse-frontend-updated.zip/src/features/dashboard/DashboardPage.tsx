import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Banknote, BellRing, Building2, Coins, TrendingDown } from 'lucide-react';
import { useAlerts, useBands, useDailyPositions, useForecast, useFxRates, useGap, useIntraday, usePositionSummary } from '@/api/hooks';
import { CashPositionChart, CurrencyDonut, ForecastChart, InflowOutflowAreaChart, LiquidityGapChart, Sparkline } from '@/components/charts';
import { KpiCard, MoneyCell, NoThresholdChip, SeverityChip } from '@/components/ui/display';
import { DataFreshness, EmptyState, Widget } from '@/components/ui/feedback';
import { Card, CardHeader, PageHeader } from '@/components/ui/primitives';
import { shiftDate, useFocus, useLatestPositions } from '@/hooks/useFocus';
import { useScopeFilter } from '@/hooks/useScopeFilter';
import { formatMoney, formatPct } from '@/lib/format';
import { summarizePairs, toReporting } from '@/lib/portfolio';
import { can } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import { useFilterStore } from '@/stores/filterStore';
import { cn } from '@/lib/cn';

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user);
  const { reportingCcy, set } = useFilterStore();
  const selectedCcy = useFilterStore((s) => s.currencies[0] ?? null);
  const nav = useNavigate();
  const matches = useScopeFilter();
  const focus = useFocus();
  const summary = usePositionSummary(reportingCcy);
  const fx = useFxRates(reportingCcy);
  const latest = useLatestPositions();
  const gapAll = useGap({});
  const alerts = useAlerts({ status: 'OPEN' }, 60_000);
  const bands = useBands();

  const asOf = summary.data?.asOf;
  const asOfDate = latest.asOfDate;
  const history = useDailyPositions({
    entity: focus.entity,
    currency: focus.currency,
    from: asOfDate ? shiftDate(asOfDate, -89) : undefined,
  });
  const forecast = useForecast(focus.entity, focus.currency);
  const focusGap = useGap({ entity: focus.entity, currency: focus.currency });
  const intraday = useIntraday({ entity: focus.entity, currency: focus.currency, date: asOfDate });

  const pairs = useMemo(
    () => summarizePairs(latest.data, gapAll.data ?? []).filter((p) => matches(p.entityCode, p.currency)),
    [latest.data, gapAll.data, matches],
  );
  const rates = fx.data?.rates;
  const kpi = useMemo(() => {
    const total = pairs.reduce((a, p) => a + toReporting(p.current, p.currency, rates), 0);
    const shortfall = new Set(pairs.filter((p) => p.severity === 'EMERGENCY').map((p) => p.entityCode)).size;
    const surplus = pairs.reduce((a, p) => a + toReporting(p.deployable, p.currency, rates), 0);
    const withGap = pairs.filter((p) => p.worst);
    const minGap = withGap.length ? Math.min(...withGap.map((p) => toReporting(p.worst!.gap, p.currency, rates))) : null;
    return { total, shortfall, surplus, minGap };
  }, [pairs, rates]);

  const openAlerts = (alerts.data ?? []).filter((a) => matches(a.entityCode, a.currency));
  const sev = (s: string) => openAlerts.filter((a) => a.severity === s).length;

  const donut = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of pairs) m.set(p.currency, (m.get(p.currency) ?? 0) + toReporting(p.current, p.currency, rates));
    const total = [...m.values()].reduce((a, b) => a + b, 0) || 1;
    return [...m].map(([currency, amount]) => ({ currency, amount, share: amount / total })).sort((a, b) => b.amount - a.amount);
  }, [pairs, rates]);

  const threshold = focusGap.data?.[0]?.threshold ?? null;
  const worstRow = focusGap.data?.length ? focusGap.data.reduce((a, r) => (r.gap < a.gap ? r : a), focusGap.data[0]) : null;
  const loadingKpi = latest.isPending || gapAll.isPending || fx.isPending;
  const pairLabel = focus.entity ? `${focus.entity} · ${focus.currency}` : '—';

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description={`Liquidity overview · focus ${pairLabel}`}
        actions={<DataFreshness asOf={asOf} />}
      />

      {can(user, 'region_view') && summary.data && (
        <div className="mb-4 grid gap-3 sm:grid-cols-3" aria-label="Region summary">
          {summary.data.byRegion.map((r) => (
            <button key={r.region} onClick={() => set({ region: r.region, entity: null, currencies: [] })} className="text-left">
              <Card className="p-4 transition-colors hover:border-accent">
                <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
                  <span>{r.region}</span>
                  <span>{r.entities} entities</span>
                </div>
                <div className="num mt-1 text-xl">{formatMoney(r.amount, reportingCcy, { compact: true })}</div>
                <div className={cn('mt-1 text-xs', r.openAlerts ? 'text-crit' : 'text-muted-foreground')}>{r.openAlerts} open alerts</div>
              </Card>
            </button>
          ))}
        </div>
      )}

      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <KpiCard label={`Total cash (${reportingCcy})`} value={formatMoney(kpi.total, reportingCcy, { compact: true })} loading={loadingKpi} icon={<Banknote className="h-4 w-4" />} sub={`${pairs.length} positions`} />
        <KpiCard
          label="Entities in shortfall"
          value={kpi.shortfall}
          tone={kpi.shortfall ? 'crit' : 'ok'}
          loading={loadingKpi}
          icon={<Building2 className="h-4 w-4" />}
          sub="Emergency within 30 days"
        />
        <KpiCard
          label="Open alerts"
          value={openAlerts.length}
          tone={sev('EMERGENCY') + sev('CRITICAL') ? 'crit' : openAlerts.length ? 'warn' : 'ok'}
          loading={alerts.isPending}
          icon={<BellRing className="h-4 w-4" />}
          sub={`${sev('EMERGENCY')} emergency · ${sev('CRITICAL')} critical · ${sev('WARNING')} warning`}
        />
        <KpiCard label="Deployable surplus" value={formatMoney(kpi.surplus, reportingCcy, { compact: true })} loading={loadingKpi} icon={<Coins className="h-4 w-4" />} sub="Above threshold + 20%" />
        <KpiCard
          label="Forecast min gap (30d)"
          value={kpi.minGap === null ? '—' : formatMoney(kpi.minGap, reportingCcy, { compact: true })}
          tone={kpi.minGap !== null && kpi.minGap < 0 ? 'crit' : undefined}
          loading={loadingKpi}
          icon={<TrendingDown className="h-4 w-4" />}
          sub="Projected − threshold"
        />
      </div>

      <div className="mb-4 grid gap-4 xl:grid-cols-2">
        <Widget title="Cash position" description={`${pairLabel} · last 90 days`} query={history} height="h-72" isEmpty={(d) => d.length === 0}>
          {(rows) => <CashPositionChart rows={rows} currency={focus.currency ?? ''} />}
        </Widget>
        <Widget title="30-day forecast" description={`${pairLabel} · with 80% / 95% confidence`} query={forecast} height="h-72">
          {(f) => <ForecastChart history={history.data} forecast={f} threshold={threshold} />}
        </Widget>
      </div>

      <Widget
        className="mb-4"
        title="Liquidity gap vs threshold"
        description={`${pairLabel} · green ≥10% headroom, amber 5–10%, red below`}
        query={focusGap}
        height="h-80"
        isEmpty={(d) => d.length === 0}
        empty={<EmptyState title="No threshold set" hint="Ask an Admin to set a threshold for this currency in the alert matrix." />}
      >
        {(rows) => (
          <div>
            <LiquidityGapChart rows={rows} bands={bands.data} />
            {worstRow && (
              <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-md bg-muted px-3 py-2 text-sm" aria-live="polite">
                <span className="font-medium">Gap = Projected − Threshold</span>
                <span>
                  <MoneyCell amount={worstRow.projected} currency={worstRow.currency} /> −{' '}
                  <MoneyCell amount={worstRow.threshold} currency={worstRow.currency} /> ={' '}
                  <MoneyCell amount={worstRow.gap} currency={worstRow.currency} tone="auto" className="font-semibold" />
                </span>
                <span className="text-muted-foreground">
                  lowest on {worstRow.date} · headroom {formatPct(worstRow.headroomPct)}
                </span>
                <SeverityChip severity={worstRow.severity} />
              </div>
            )}
          </div>
        )}
      </Widget>

      <div className="mb-4 grid gap-4 xl:grid-cols-3">
        <Widget className="xl:col-span-2" title="Hourly inflows vs outflows" description={`${pairLabel} · latest business day`} query={intraday} height="h-64">
          {(b) => <InflowOutflowAreaChart buckets={b} currency={focus.currency ?? ''} />}
        </Widget>
        <Widget title="Position by currency" description={`In ${reportingCcy} · click a slice to filter`} query={gapAll} height="h-64">
          {() => (
            <CurrencyDonut
              data={donut}
              reportingCcy={reportingCcy}
              selected={selectedCcy}
              onSelect={(c) => set({ currencies: [c] })}
            />
          )}
        </Widget>
      </div>

      <Card>
        <CardHeader title="Position trend" description="Entity × currency · lowest point over the next 30 days" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-2 font-medium">Entity</th>
                <th className="px-2 py-2 font-medium">Ccy</th>
                <th className="px-2 py-2 text-right font-medium">Position</th>
                <th className="px-2 py-2 text-right font-medium">Threshold</th>
                <th className="px-2 py-2 text-right font-medium">Min gap</th>
                <th className="px-2 py-2 text-right font-medium">Headroom</th>
                <th className="px-2 py-2 font-medium">Severity</th>
                <th className="px-4 py-2 font-medium">30-day trend</th>
              </tr>
            </thead>
            <tbody>
              {pairs.length === 0 && (
                <tr>
                  <td colSpan={8}>
                    <EmptyState title="No positions for these filters" />
                  </td>
                </tr>
              )}
              {pairs
                .sort((a, b) => (a.worst?.gap ?? Infinity) - (b.worst?.gap ?? Infinity))
                .map((p) => (
                  <tr
                    key={`${p.entityCode}${p.currency}`}
                    className="cursor-pointer border-t border-border hover:bg-muted/60"
                    onClick={() => {
                      set({ entity: p.entityCode, region: null, currencies: [p.currency] });
                      nav({ pathname: '/forecast', search: `?entity=${p.entityCode}&ccy=${p.currency}` });
                    }}
                  >
                    <td className="px-4 py-2 font-medium">{p.entityCode}</td>
                    <td className="px-2 py-2">{p.currency}</td>
                    <td className="px-2 py-2 text-right"><MoneyCell amount={p.current} currency={p.currency} compact /></td>
                    <td className="px-2 py-2 text-right">
                      {p.threshold === null ? <NoThresholdChip /> : <MoneyCell amount={p.threshold} currency={p.currency} compact />}
                    </td>
                    <td className="px-2 py-2 text-right">
                      {p.worst ? <MoneyCell amount={p.worst.gap} currency={p.currency} compact tone="auto" /> : '—'}
                    </td>
                    <td className="num px-2 py-2 text-right">{p.worst ? formatPct(p.worst.headroomPct) : '—'}</td>
                    <td className="px-2 py-2">{p.worst ? <SeverityChip severity={p.severity} /> : '—'}</td>
                    <td className="px-4 py-2">
                      <Sparkline values={p.series} />
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
