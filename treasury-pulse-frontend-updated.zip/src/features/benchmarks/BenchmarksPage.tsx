import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, Tooltip, XAxis, YAxis } from 'recharts';
import { useBenchmarks } from '@/api/hooks';
import { axisTick, ChartFrame, COLORS, compactTick, dateTick } from '@/components/charts/common';
import { KpiCard } from '@/components/ui/display';
import { Card, CardHeader, PageHeader } from '@/components/ui/primitives';
import { QueryBoundary } from '@/components/ui/feedback';
import { formatNumber, formatPct } from '@/lib/format';

/** Measures real frontend first-load time of this page's data + render. */
function useFrontendTimings() {
  const [t, setT] = useState<{ nav: number | null; fcp: number | null }>({ nav: null, fcp: null });
  useEffect(() => {
    const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined;
    const fcp = performance.getEntriesByName('first-contentful-paint')[0];
    setT({ nav: nav ? Math.round(nav.domContentLoadedEventEnd) : null, fcp: fcp ? Math.round(fcp.startTime) : null });
  }, []);
  return t;
}

export default function BenchmarksPage() {
  const q = useBenchmarks();
  const fe = useFrontendTimings();
  const [start] = useState(() => performance.now());
  const [rendered, setRendered] = useState<number | null>(null);
  useEffect(() => {
    if (q.data && rendered === null) setRendered(Math.round(performance.now() - start));
  }, [q.data, rendered, start]);

  return (
    <div>
      <PageHeader title="Benchmarks" description="Forecast accuracy and performance timings" />
      <QueryBoundary query={q}>
        {(b) => (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <KpiCard label="MAPE (30-day backtest)" value={formatPct(b.mape, 2)} sub="Lower is better" />
              <KpiCard label="RMSE (USD eq.)" value={formatNumber(b.rmse)} sub="Root mean squared error" />
              <KpiCard label="Forecast generation" value={`${formatNumber(b.timings.forecastMs)} ms`} sub="Backend" />
              <KpiCard label="Chat response" value={`${formatNumber(b.timings.chatMs)} ms`} sub="Backend, to first answer" />
            </div>
            <div className="grid gap-4 xl:grid-cols-2">
              <Card>
                <CardHeader title="Error by entity" description="MAPE % on each entity's base currency" />
                <div className="p-4">
                  <ChartFrame title="MAPE by entity" height={260}>
                    <BarChart data={b.perEntity}>
                      <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="entityCode" tick={axisTick} />
                      <YAxis tick={axisTick} unit="%" width={44} />
                      <Tooltip />
                      <Bar dataKey="mape" name="MAPE %" fill={COLORS.accent} isAnimationActive={false} />
                    </BarChart>
                  </ChartFrame>
                  <table className="mt-3 w-full text-sm">
                    <thead className="text-left text-xs text-muted-foreground">
                      <tr><th className="py-1 font-medium">Entity</th><th className="py-1 text-right font-medium">MAPE</th><th className="py-1 text-right font-medium">RMSE</th></tr>
                    </thead>
                    <tbody>
                      {b.perEntity.map((e) => (
                        <tr key={e.entityCode} className="border-t border-border">
                          <td className="py-1 font-medium">{e.entityCode}</td>
                          <td className="num py-1 text-right">{formatPct(e.mape, 2)}</td>
                          <td className="num py-1 text-right">{formatNumber(e.rmse)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
              <Card>
                <CardHeader title="Forecast vs actual" description="PARI base currency, last 30 days" />
                <div className="p-4">
                  <ChartFrame title="Backtest forecast vs actual" height={300}>
                    <LineChart data={b.backtest}>
                      <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="date" tick={axisTick} tickFormatter={dateTick} minTickGap={30} />
                      <YAxis tick={axisTick} tickFormatter={compactTick} width={52} domain={['auto', 'auto']} />
                      <Tooltip />
                      <Legend />
                      <Line dataKey="actual" name="Actual" stroke={COLORS.accent} dot={false} strokeWidth={2} isAnimationActive={false} />
                      <Line dataKey="forecast" name="Forecast" stroke={COLORS.warn} dot={false} strokeDasharray="5 4" strokeWidth={2} isAnimationActive={false} />
                    </LineChart>
                  </ChartFrame>
                </div>
              </Card>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <KpiCard label="Parse 10k rows" value={`${formatNumber(b.timings.parse10k)} ms`} sub="Backend" />
              <KpiCard label="Parse 50k rows" value={`${formatNumber(b.timings.parse50k)} ms`} sub="Backend" />
              <KpiCard label="Parse 100k rows" value={`${formatNumber(b.timings.parse100k)} ms`} sub="Backend" />
              <KpiCard label="Dashboard load (backend)" value={`${formatNumber(b.timings.dashboardLoadMs)} ms`} sub="Backend" />
            </div>
            <Card>
              <CardHeader title="Measured in this browser" description="performance.now() around this page's load" />
              <div className="grid gap-3 p-4 sm:grid-cols-3">
                <KpiCard label="DOM content loaded" value={fe.nav === null ? '—' : `${fe.nav} ms`} />
                <KpiCard label="First contentful paint" value={fe.fcp === null ? '—' : `${fe.fcp} ms`} />
                <KpiCard label="This page: data + render" value={rendered === null ? '…' : `${rendered} ms`} />
              </div>
            </Card>
          </div>
        )}
      </QueryBoundary>
    </div>
  );
}
