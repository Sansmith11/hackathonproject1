import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRightLeft, Clock, Coins, Layers, Zap } from 'lucide-react';
import { useRecommendations } from '@/api/hooks';
import { MoneyCell } from '@/components/ui/display';
import { EmptyState, QueryBoundary } from '@/components/ui/feedback';
import { Badge, Button, Card, CardHeader, PageHeader, Select } from '@/components/ui/primitives';
import { useScopeFilter } from '@/hooks/useScopeFilter';
import { useEntities } from '@/api/hooks';
import { useFilterStore } from '@/stores/filterStore';
import type { RecommendationAction } from '@/types/domain';

const ACTION_META: Record<RecommendationAction, { label: string; icon: JSX.Element }> = {
  ACCELERATE_COLLECTIONS: { label: 'Accelerate collections', icon: <Zap className="h-4 w-4" /> },
  DELAY_PAYMENTS: { label: 'Delay payments', icon: <Clock className="h-4 w-4" /> },
  INVEST_SURPLUS: { label: 'Invest surplus', icon: <Coins className="h-4 w-4" /> },
  INTERCOMPANY_TRANSFER: { label: 'Intercompany transfer', icon: <ArrowRightLeft className="h-4 w-4" /> },
  CASH_POOLING: { label: 'Cash pooling', icon: <Layers className="h-4 w-4" /> },
};

export default function RecommendationsPage() {
  const q = useRecommendations(null);
  const entities = useEntities();
  const matches = useScopeFilter();
  const set = useFilterStore((s) => s.set);
  const nav = useNavigate();
  const [entity, setEntity] = useState('');
  const [action, setAction] = useState('');

  const recs = useMemo(
    () => (q.data?.recommendations ?? []).filter((r) => matches(r.entityCode, r.currency) && (!entity || r.entityCode === entity) && (!action || r.action === action)),
    [q.data, matches, entity, action],
  );
  const surplus = useMemo(
    () => (q.data?.surplus ?? []).filter((s) => matches(s.entityCode, s.currency) && (!entity || s.entityCode === entity)),
    [q.data, matches, entity],
  );

  const simulate = (e: string, c: string, a: RecommendationAction) => {
    set({ entity: e, currencies: [c], region: null });
    nav({ pathname: '/what-if', search: `?entity=${e}&ccy=${c}&${a === 'DELAY_PAYMENTS' ? 'capex=7' : 'delay=2'}` });
  };

  return (
    <div>
      <PageHeader
        title="Recommendations"
        description="Scored actions and deployable surplus"
        actions={
          <>
            <Select aria-label="Entity" value={entity} onChange={(e) => setEntity(e.target.value)}>
              <option value="">All entities</option>
              {(entities.data ?? []).map((e) => <option key={e.code}>{e.code}</option>)}
            </Select>
            <Select aria-label="Action type" value={action} onChange={(e) => setAction(e.target.value)}>
              <option value="">All actions</option>
              {Object.entries(ACTION_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </Select>
          </>
        }
      />
      <QueryBoundary query={q}>
        {() => (
          <div className="space-y-4">
            <Card>
              <CardHeader title="Deployable surplus" description="Projected balance stays above threshold + 20% for the whole horizon" />
              {surplus.length === 0 ? (
                <EmptyState title="No deployable surplus" />
              ) : (
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="px-4 py-2 font-medium">Entity</th>
                      <th className="px-2 py-2 font-medium">Ccy</th>
                      <th className="px-2 py-2 text-right font-medium">Lowest projected</th>
                      <th className="px-2 py-2 text-right font-medium">Threshold</th>
                      <th className="px-4 py-2 text-right font-medium">Deployable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {surplus.map((s) => (
                      <tr key={s.entityCode + s.currency} className="border-t border-border">
                        <td className="px-4 py-2 font-medium">{s.entityCode}</td>
                        <td className="px-2 py-2">{s.currency}</td>
                        <td className="px-2 py-2 text-right"><MoneyCell amount={s.minProjected} currency={s.currency} compact /></td>
                        <td className="px-2 py-2 text-right"><MoneyCell amount={s.threshold} currency={s.currency} compact /></td>
                        <td className="px-4 py-2 text-right"><MoneyCell amount={s.deployable} currency={s.currency} compact tone="inflow" /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </Card>

            {recs.length === 0 ? (
              <Card><EmptyState title="No recommendations" hint="Nothing needs action for these filters." /></Card>
            ) : (
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {recs.map((r) => (
                  <Card key={r.id} className="flex flex-col p-4">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                        {ACTION_META[r.action].icon} {ACTION_META[r.action].label}
                      </span>
                      <Badge tone={r.priority === 1 ? 'crit' : r.priority === 2 ? 'warn' : 'neutral'}>P{r.priority}</Badge>
                    </div>
                    <h3 className="mt-2 font-semibold">{r.title}</h3>
                    <p className="mt-1 flex-1 text-xs text-muted-foreground">{r.rationale}</p>
                    <div className="mt-3 flex items-end justify-between">
                      <div>
                        <div className="text-xs text-muted-foreground">Expected impact</div>
                        <MoneyCell amount={r.expectedImpact} currency={r.currency} compact tone="inflow" className="text-lg" />
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-muted-foreground">Score</div>
                        <div className="num text-lg font-medium">{r.score}</div>
                      </div>
                    </div>
                    <Button className="mt-3" size="sm" onClick={() => simulate(r.entityCode, r.currency, r.action)}>
                      Simulate
                    </Button>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </QueryBoundary>
    </div>
  );
}
