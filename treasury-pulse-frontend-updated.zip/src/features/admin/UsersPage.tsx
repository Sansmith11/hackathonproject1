import { zodResolver } from '@hookform/resolvers/zod';
import { Pencil, Plus } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { useEntities, useUserMutations, useUsers } from '@/api/hooks';
import { QueryBoundary } from '@/components/ui/feedback';
import { Dialog } from '@/components/ui/overlay';
import { Badge, Button, Card, Input, Label, PageHeader, Select } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { ROLE_LABEL } from '@/lib/permissions';
import type { Region, Role, User } from '@/types/domain';

const schema = z.object({
  name: z.string().min(2, 'Name is required'),
  email: z.string().email('Enter a valid email'),
  role: z.enum(['VIEWER', 'ANALYST', 'TREASURY_MANAGER', 'ADMIN']),
  entityCodes: z.array(z.string()),
  regions: z.array(z.enum(['APAC', 'EMEA', 'NAMER'])),
});
type FormValues = z.infer<typeof schema>;

const REGIONS: Region[] = ['APAC', 'EMEA', 'NAMER'];

function UserDialog({ user, onClose }: { user: User | 'new' | null; onClose: () => void }) {
  const entities = useEntities();
  const { create, update } = useUserMutations();
  const editing = user && user !== 'new' ? user : null;
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    values: editing
      ? { name: editing.name, email: editing.email, role: editing.role, entityCodes: editing.entityCodes, regions: editing.regions }
      : { name: '', email: '', role: 'VIEWER', entityCodes: [], regions: [] },
  });
  const { register, handleSubmit, watch, setValue, formState } = form;
  const codes = watch('entityCodes');
  const regions = watch('regions');

  const toggle = <T extends string>(list: T[], v: T) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  const onSubmit = handleSubmit((v) => {
    const done = () => {
      toast(editing ? 'User updated — role change applies at their next login' : 'User created', 'success');
      onClose();
    };
    if (editing) update.mutate({ ...editing, ...v }, { onSuccess: done });
    else create.mutate(v, { onSuccess: done });
  });

  return (
    <Dialog
      open={!!user}
      onOpenChange={(o) => !o && onClose()}
      title={editing ? 'Edit user' : 'New user'}
      description="Role and entity scope control what this person can see and do."
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={() => void onSubmit()}>Save</Button>
        </>
      }
    >
      <form onSubmit={(e) => void onSubmit(e)} className="space-y-4">
        <div>
          <Label>Name</Label>
          <Input {...register('name')} />
          {formState.errors.name && <p className="mt-1 text-xs text-crit">{formState.errors.name.message}</p>}
        </div>
        <div>
          <Label>Email</Label>
          <Input {...register('email')} disabled={!!editing} />
          {formState.errors.email && <p className="mt-1 text-xs text-crit">{formState.errors.email.message}</p>}
        </div>
        <div>
          <Label>Role</Label>
          <Select className="w-full" {...register('role')}>
            {(Object.keys(ROLE_LABEL) as Role[]).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
          </Select>
        </div>
        <div>
          <Label>Entity scope</Label>
          <div className="flex flex-wrap gap-2">
            {(entities.data ?? []).map((e) => (
              <label key={e.code} className="flex items-center gap-1.5 text-sm">
                <input type="checkbox" checked={codes.includes(e.code)} onChange={() => setValue('entityCodes', toggle(codes, e.code))} />
                {e.code}
              </label>
            ))}
          </div>
        </div>
        <div>
          <Label>Region scope</Label>
          <div className="flex gap-4">
            {REGIONS.map((r) => (
              <label key={r} className="flex items-center gap-1.5 text-sm">
                <input type="checkbox" checked={regions.includes(r)} onChange={() => setValue('regions', toggle(regions, r))} />
                {r}
              </label>
            ))}
          </div>
        </div>
      </form>
    </Dialog>
  );
}

export default function UsersPage() {
  const users = useUsers();
  const [dlg, setDlg] = useState<User | 'new' | null>(null);
  return (
    <div>
      <PageHeader
        title="Users & roles"
        description="Role changes take effect on the user's next login."
        actions={<Button variant="primary" onClick={() => setDlg('new')}><Plus className="h-4 w-4" /> New user</Button>}
      />
      <Card>
        <QueryBoundary query={users}>
          {(rows) => (
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-foreground">
                <tr>{['Name', 'Email', 'Role', 'Entities', 'Regions', ''].map((h) => <th key={h} className="px-4 py-2 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map((u) => (
                  <tr key={u.id} className="border-t border-border">
                    <td className="px-4 py-2 font-medium">{u.name}</td>
                    <td className="num px-4 py-2 text-xs">{u.email}</td>
                    <td className="px-4 py-2"><Badge tone={u.role === 'ADMIN' ? 'accent' : 'neutral'}>{ROLE_LABEL[u.role]}</Badge></td>
                    <td className="px-4 py-2 text-xs">{u.role === 'ADMIN' ? 'All' : u.entityCodes.join(', ') || '—'}</td>
                    <td className="px-4 py-2 text-xs">{u.regions.join(', ') || '—'}</td>
                    <td className="px-4 py-2 text-right">
                      <Button size="sm" aria-label={`Edit ${u.name}`} onClick={() => setDlg(u)}><Pencil className="h-3.5 w-3.5" /></Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </QueryBoundary>
      </Card>
      {dlg && <UserDialog user={dlg} onClose={() => setDlg(null)} />}
    </div>
  );
}
