import { useMemo, useState } from 'react';
import { z } from 'zod';
import { useBands, useEntities, useThresholdMutations, useThresholds } from '@/api/hooks';
import { QueryBoundary } from '@/components/ui/feedback';
import { Dialog } from '@/components/ui/overlay';
import { Badge, Button, Card, CardHeader, Input, Label, PageHeader } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { useLatestPositions } from '@/hooks/useFocus';
import { cn } from '@/lib/cn';
import { formatNumber } from '@/lib/format';
import { resolveThreshold } from '@/lib/gap';
import type { Entity, Region, Threshold } from '@/types/domain';

const valueSchema = z.number({ message: 'Enter a number' }).positive('Must be greater than 0');
const bandSchema = z.object({ critical: z.number().positive(), warning: z.number().positive() }).refine((b) => b.warning > b.critical, {
  message: 'Warning band must be larger than critical band',
});

type Level = { kind: 'CURRENCY' } | { kind: 'REGION'; region: Region } | { kind: 'ENTITY'; entity: Entity };

interface Edit {
  level: Level;
  currency: string;
  existing?: Threshold;
}

const levelLabel = (l: Level) => (l.kind === 'CURRENCY' ? 'Currency default' : l.kind === 'REGION' ? `${l.region} region` : `${l.entity.code} · ${l.entity.city}`);
const fmt = (t: Threshold) => (t.mode === 'PERCENT' ? `${formatNumber(t.value, 1)}%` : formatNumber(t.value));

function BandsCard() {
  const bands = useBands();
  const { setBands } = useThresholdMutations();
  const [crit, setCrit] = useState<string | null>(null);
  const [warn, setWarn] = useState<string | null>(null);
  const c = crit ?? String(bands.data?.critical ?? 5);
  const w = warn ?? String(bands.data?.warning ?? 10);
  const parsed = bandSchema.safeParse({ critical: Number(c), warning: Number(w) });
  return (
    <Card>
      <CardHeader title="Warning bands" description="Headroom % above threshold that triggers each severity" />
      <div className="flex flex-wrap items-end gap-4 p-4">
        <div>
          <Label>Critical below (%)</Label>
          <Input className="w-28" type="number" value={c} onChange={(e) => setCrit(e.target.value)} />
        </div>
        <div>
          <Label>Warning below (%)</Label>
          <Input className="w-28" type="number" value={w} onChange={(e) => setWarn(e.target.value)} />
        </div>
        <Button
          variant="primary"
          disabled={!parsed.success || setBands.isPending}
          onClick={() => parsed.success && setBands.mutate(parsed.data, { onSuccess: () => toast('Bands updated — severities re-evaluated', 'success') })}
        >
          Save bands
        </Button>
        {!parsed.success && <span className="text-xs text-crit">{parsed.error.issues[0]?.message}</span>}
      </div>
    </Card>
  );
}

export default function ThresholdsPage() {
  const thresholds = useThresholds();
  const entities = useEntities();
  const latest = useLatestPositions();
  const { create, update, remove } = useThresholdMutations();
  const [edit, setEdit] = useState<Edit | null>(null);
  const [mode, setMode] = useState<'ABSOLUTE' | 'PERCENT'>('ABSOLUTE');
  const [value, setValue] = useState('');
  const [confirming, setConfirming] = useState(false);

  const currencies = useMemo(
    () => [...new Set([...latest.data.map((p) => p.currency), ...(thresholds.data ?? []).map((t) => t.currency)])].sort(),
    [latest.data, thresholds.data],
  );
  const regions = useMemo(() => [...new Set((entities.data ?? []).map((e) => e.region))], [entities.data]);
  const avg = (entity: string, ccy: string) => {
    const s = latest.data.filter((p) => p.entityCode === entity && p.currency === ccy);
    return s.length ? s.reduce((a, r) => a + r.closingBalance, 0) / s.length : 0;
  };

  const find = (level: Level, ccy: string) =>
    (thresholds.data ?? []).find(
      (t) =>
        t.currency === ccy &&
        t.scope === level.kind &&
        (level.kind === 'REGION' ? t.region === level.region : level.kind === 'ENTITY' ? t.entityCode === level.entity.code : true),
    );

  const open = (level: Level, currency: string) => {
    const existing = find(level, currency);
    setEdit({ level, currency, existing });
    setMode(existing?.mode ?? 'ABSOLUTE');
    setValue(existing ? String(existing.value) : '');
    setConfirming(false);
  };

  const num = Number(value);
  const valid = valueSchema.safeParse(value === '' ? undefined : num);
  const save = () => {
    if (!edit || !valid.success) return;
    const base = {
      scope: edit.level.kind,
      currency: edit.currency,
      mode,
      value: num,
      ...(edit.level.kind === 'REGION' ? { region: edit.level.region } : {}),
      ...(edit.level.kind === 'ENTITY' ? { entityCode: edit.level.entity.code } : {}),
    } as Omit<Threshold, 'id'>;
    const done = () => {
      toast('Threshold saved — severities re-evaluated everywhere', 'success');
      setEdit(null);
    };
    if (edit.existing) update.mutate({ ...base, id: edit.existing.id }, { onSuccess: done });
    else create.mutate(base, { onSuccess: done });
  };

  const rows: Level[] = [
    { kind: 'CURRENCY' },
    ...regions.map((r): Level => ({ kind: 'REGION', region: r })),
    ...(entities.data ?? []).map((e): Level => ({ kind: 'ENTITY', entity: e })),
  ];

  return (
    <div>
      <PageHeader title="Alert matrix" description="Thresholds resolve Entity → Region → Currency default" />
      <div className="space-y-4">
        <BandsCard />
        <Card>
          <CardHeader title="Thresholds" description="Click a cell to set or change a rule. Dimmed values are inherited." />
          <QueryBoundary query={thresholds}>
            {(all) => (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-muted-foreground">
                    <tr>
                      <th className="px-4 py-2 font-medium">Scope</th>
                      {currencies.map((c) => <th key={c} className="num px-2 py-2 text-right font-medium">{c}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((level) => (
                      <tr key={levelLabel(level)} className="border-t border-border">
                        <td className="whitespace-nowrap px-4 py-1.5 font-medium">{levelLabel(level)}</td>
                        {currencies.map((c) => {
                          const own = find(level, c);
                          let inherited: { text: string; source: string } | null = null;
                          if (!own && level.kind === 'ENTITY') {
                            const r = resolveThreshold(all, level.entity.code, level.entity.region, c, avg(level.entity.code, c));
                            if (r) inherited = { text: formatNumber(r.value), source: r.source.toLowerCase() };
                          } else if (!own && level.kind === 'REGION') {
                            const r = all.find((t) => t.scope === 'CURRENCY' && t.currency === c);
                            if (r) inherited = { text: fmt(r), source: 'currency' };
                          }
                          return (
                            <td key={c} className="px-1 py-1 text-right">
                              <button
                                onClick={() => open(level, c)}
                                className={cn('num w-full rounded px-2 py-1 text-right text-xs hover:bg-muted', own ? 'font-semibold' : 'text-muted-foreground')}
                                aria-label={`${levelLabel(level)} ${c}`}
                              >
                                {own ? (
                                  <>{fmt(own)}</>
                                ) : inherited ? (
                                  <span title={`Inherited from ${inherited.source}`}>{inherited.text} <span className="text-[10px]">↑{inherited.source[0]}</span></span>
                                ) : (
                                  <span>{level.kind === 'CURRENCY' ? 'No threshold' : '+'}</span>
                                )}
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </QueryBoundary>
        </Card>
      </div>

      <Dialog
        open={!!edit}
        onOpenChange={(o) => !o && setEdit(null)}
        title={edit ? `${edit.currency} · ${levelLabel(edit.level)}` : ''}
        description={confirming ? 'Review the change before applying it.' : 'Set an absolute amount or a percent of the 30-day average closing balance.'}
        footer={
          confirming ? (
            <>
              <Button onClick={() => setConfirming(false)}>Back</Button>
              <Button variant="primary" onClick={save}>Apply change</Button>
            </>
          ) : (
            <>
              {edit?.existing && (
                <Button
                  variant="danger"
                  className="mr-auto"
                  onClick={() => remove.mutate(edit.existing!.id, { onSuccess: () => { toast('Rule removed', 'success'); setEdit(null); } })}
                >
                  Remove rule
                </Button>
              )}
              <Button onClick={() => setEdit(null)}>Cancel</Button>
              <Button variant="primary" disabled={!valid.success} onClick={() => setConfirming(true)}>Review</Button>
            </>
          )
        }
      >
        {confirming && edit ? (
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Before</span><span className="num">{edit.existing ? fmt(edit.existing) : 'not set'}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">After</span><span className="num font-semibold">{mode === 'PERCENT' ? `${num}%` : formatNumber(num)}</span></div>
            <p className="rounded bg-muted p-2 text-xs">Alerts, gap severities and the dashboard re-evaluate immediately for every user in scope.</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex rounded-md border border-border">
              {(['ABSOLUTE', 'PERCENT'] as const).map((m) => (
                <button key={m} aria-pressed={mode === m} onClick={() => setMode(m)} className={cn('flex-1 px-3 py-1.5 text-sm', mode === m && 'bg-accent text-accent-foreground')}>
                  {m === 'ABSOLUTE' ? 'Absolute amount' : '% of 30d avg balance'}
                </button>
              ))}
            </div>
            <div>
              <Label>Value {mode === 'PERCENT' ? '(%)' : `(${edit?.currency ?? ''})`}</Label>
              <Input type="number" value={value} onChange={(e) => setValue(e.target.value)} autoFocus />
              {value !== '' && !valid.success && <p className="mt-1 text-xs text-crit">{valid.error.issues[0]?.message}</p>}
            </div>
            {edit?.level.kind !== 'CURRENCY' && <Badge tone="neutral">Overrides the inherited threshold for this scope</Badge>}
          </div>
        )}
      </Dialog>
    </div>
  );
}
