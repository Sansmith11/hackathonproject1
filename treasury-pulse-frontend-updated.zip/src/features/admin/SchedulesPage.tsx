import { X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { z } from 'zod';
import { useSaveSchedules, useSchedules } from '@/api/hooks';
import { QueryBoundary } from '@/components/ui/feedback';
import { Badge, Button, Card, CardHeader, Input, Label, PageHeader, Select, Switch } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import type { ReportSchedule } from '@/types/domain';

const email = z.string().email();
const TZ = ['Europe/Paris', 'Europe/London', 'Asia/Singapore', 'Asia/Tokyo', 'Asia/Kolkata', 'America/New_York', 'UTC'];
const DAYS: Record<string, string> = { '1-5': 'Weekdays', '*': 'Every day', '1': 'Mondays only' };

function parseCron(cron: string): { time: string; days: string } {
  const [m = '0', h = '7', , , d = '1-5'] = cron.split(' ');
  return { time: `${h.padStart(2, '0')}:${m.padStart(2, '0')}`, days: DAYS[d] ? d : '1-5' };
}
const toCron = (time: string, days: string) => {
  const [h, m] = time.split(':').map(Number);
  return `${m} ${h} * * ${days}`;
};

function ScheduleCard({ s, onChange }: { s: ReportSchedule; onChange: (s: ReportSchedule) => void }) {
  const { time, days } = parseCron(s.cron);
  const [draft, setDraft] = useState('');
  const [err, setErr] = useState('');
  const add = () => {
    const v = draft.trim();
    if (!v) return;
    if (!email.safeParse(v).success) return setErr('Enter a valid email address');
    if (s.recipients.includes(v)) return setErr('Already added');
    onChange({ ...s, recipients: [...s.recipients, v] });
    setDraft('');
    setErr('');
  };
  return (
    <Card>
      <CardHeader
        title={s.type === 'SOD' ? 'Start-of-day report' : 'End-of-day report'}
        description={`Cron: ${s.cron} (${s.timezone})`}
        actions={<Switch checked={s.enabled} onChange={(v) => onChange({ ...s, enabled: v })} label={`Enable ${s.type}`} />}
      />
      <div className="grid gap-4 p-4 md:grid-cols-2">
        <div>
          <Label>Send at</Label>
          <div className="flex gap-2">
            <Input type="time" value={time} onChange={(e) => onChange({ ...s, cron: toCron(e.target.value || time, days) })} />
            <Select aria-label="Days" value={days} onChange={(e) => onChange({ ...s, cron: toCron(time, e.target.value) })}>
              {Object.entries(DAYS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </Select>
          </div>
        </div>
        <div>
          <Label>Timezone</Label>
          <Select className="w-full" value={s.timezone} onChange={(e) => onChange({ ...s, timezone: e.target.value })}>
            {TZ.map((t) => <option key={t}>{t}</option>)}
          </Select>
        </div>
        <div>
          <Label>Formats</Label>
          <div className="flex gap-4">
            {(['PDF', 'CSV'] as const).map((f) => (
              <label key={f} className="flex items-center gap-1.5 text-sm">
                <input
                  type="checkbox"
                  checked={s.formats.includes(f)}
                  onChange={() => {
                    const next = s.formats.includes(f) ? s.formats.filter((x) => x !== f) : [...s.formats, f];
                    if (next.length) onChange({ ...s, formats: next });
                  }}
                />
                {f}
              </label>
            ))}
          </div>
        </div>
        <div>
          <Label>Recipients</Label>
          <div className="flex gap-2">
            <Input
              placeholder="name@company.com"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), add())}
            />
            <Button onClick={add}>Add</Button>
          </div>
          {err && <p className="mt-1 text-xs text-crit">{err}</p>}
          <div className="mt-2 flex flex-wrap gap-1.5">
            {s.recipients.map((r) => (
              <Badge key={r} className="gap-1">
                {r}
                <button aria-label={`Remove ${r}`} onClick={() => onChange({ ...s, recipients: s.recipients.filter((x) => x !== r) })}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-border px-4 py-3">
        <Button size="sm" disabled={s.recipients.length === 0} onClick={() => toast(`Test ${s.type} report sent to ${s.recipients.length} recipient(s) (mock)`, 'success')}>
          Send test
        </Button>
      </div>
    </Card>
  );
}

export default function SchedulesPage() {
  const q = useSchedules();
  const save = useSaveSchedules();
  const [draft, setDraft] = useState<ReportSchedule[] | null>(null);
  useEffect(() => {
    if (q.data && !draft) setDraft(q.data);
  }, [q.data, draft]);

  return (
    <div>
      <PageHeader
        title="Report schedules"
        description="Automated SOD / EOD delivery"
        actions={
          <Button variant="primary" disabled={!draft || save.isPending} onClick={() => draft && save.mutate(draft, { onSuccess: () => toast('Schedules saved', 'success') })}>
            Save changes
          </Button>
        }
      />
      <QueryBoundary query={q}>
        {() => (
          <div className="space-y-4">
            {(draft ?? []).map((s) => (
              <ScheduleCard key={s.id} s={s} onChange={(n) => setDraft((d) => (d ?? []).map((x) => (x.id === n.id ? n : x)))} />
            ))}
          </div>
        )}
      </QueryBoundary>
    </div>
  );
}
