import { BarChart3 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { authApi } from '@/api/endpoints/core';
import { Badge, Card } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { ROLE_LABEL } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import { useFilterStore } from '@/stores/filterStore';
import type { Role } from '@/types/domain';

const DEMO: { email: string; name: string; role: Role; scope: string }[] = [
  { email: 'viewer@demo', name: 'Vera Viewer', role: 'VIEWER', scope: 'Paris, Frankfurt — read-only' },
  { email: 'analyst.paris@demo', name: 'Anaïs Analyst', role: 'ANALYST', scope: 'EMEA entities — upload, what-if, reports' },
  { email: 'manager.apac@demo', name: 'Mei Manager', role: 'TREASURY_MANAGER', scope: 'APAC region — region view + drill-down' },
  { email: 'admin@demo', name: 'Adam Admin', role: 'ADMIN', scope: 'All entities — users, thresholds, schedules' },
];

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined;

interface GoogleId {
  initialize: (o: { client_id: string; callback: (r: { credential: string }) => void }) => void;
  renderButton: (el: HTMLElement, o: Record<string, unknown>) => void;
}
declare global {
  interface Window {
    google?: { accounts: { id: GoogleId } };
  }
}

/** Loads Google Identity Services on demand and renders the official button. */
function GoogleButton({ onCredential }: { onCredential: (credential: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const cb = useRef(onCredential);
  cb.current = onCredential;
  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) return;
    const render = () => {
      const g = window.google?.accounts.id;
      if (!g || !ref.current) return;
      g.initialize({ client_id: GOOGLE_CLIENT_ID, callback: (r) => cb.current(r.credential) });
      g.renderButton(ref.current, { theme: 'outline', size: 'large', text: 'signin_with', width: 280 });
    };
    if (window.google) {
      render();
      return;
    }
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true;
    s.onload = render;
    document.head.appendChild(s);
  }, []);
  return <div ref={ref} aria-label="Sign in with Google" />;
}

export default function LoginPage() {
  const { user, setSession } = useAuthStore();
  const nav = useNavigate();
  const loc = useLocation();
  const [busy, setBusy] = useState<string | null>(null);
  const resetFilters = useFilterStore((s) => s.reset);

  if (user) return <Navigate to="/dashboard" replace />;

  const loginWithGoogle = (credential: string) => void login('google', () => authApi.google(credential));

  const login = async (key: string, call: () => ReturnType<typeof authApi.login> = () => authApi.login(key)) => {
    setBusy(key);
    try {
      const res = await call();
      setSession(res.token, res.user);
      resetFilters();
      const from = (loc.state as { from?: string } | null)?.from;
      nav(from && from !== '/login' ? from : '/dashboard', { replace: true });
    } catch (e) {
      toast((e as Error).message, 'error');
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <div className="w-full max-w-xl">
        <div className="mb-6 flex items-center gap-2">
          <BarChart3 className="h-7 w-7 text-accent" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Treasury Pulse</h1>
            <p className="text-sm text-muted-foreground">Short-term liquidity command center — demo with synthetic data</p>
          </div>
        </div>
        {GOOGLE_CLIENT_ID && (
          <div className="mb-5">
            <GoogleButton onCredential={loginWithGoogle} />
            <p className="mt-2 text-xs text-muted-foreground">
              First-time Google users get read-only Viewer access until an Admin assigns a role.
            </p>
            <div className="my-4 text-center text-xs text-muted-foreground">or use a demo user</div>
          </div>
        )}
        <div className="grid gap-3 sm:grid-cols-2">
          {DEMO.map((d) => (
            <button key={d.email} onClick={() => void login(d.email)} disabled={!!busy} className="text-left">
              <Card className="h-full p-4 transition-colors hover:border-accent">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{d.name}</span>
                  <Badge tone="accent">{ROLE_LABEL[d.role]}</Badge>
                </div>
                <div className="num mt-1 text-xs text-muted-foreground">{d.email}</div>
                <div className="mt-2 text-xs">{busy === d.email ? 'Signing in…' : d.scope}</div>
              </Card>
            </button>
          ))}
        </div>
        <p className="mt-4 text-xs text-muted-foreground">One-click demo sign-in — no password. All data is synthetic.</p>
      </div>
    </div>
  );
}
