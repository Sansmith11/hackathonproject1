import { X } from 'lucide-react';
import { useUiStore } from '@/stores/uiStore';
import { ChatView } from './ChatView';

export function ChatDrawer() {
  const { chatOpen, closeChat } = useUiStore();
  if (!chatOpen) return null;
  return (
    <aside
      role="complementary"
      aria-label="Assistant"
      className="no-print fixed bottom-0 right-0 top-0 z-50 flex w-full max-w-[460px] flex-col border-l border-border bg-background p-4 shadow-2xl"
    >
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-semibold">Assistant</h2>
        <button onClick={closeChat} aria-label="Close assistant" className="rounded p-1 hover:bg-muted">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="min-h-0 flex-1">
        <ChatView />
      </div>
    </aside>
  );
}
