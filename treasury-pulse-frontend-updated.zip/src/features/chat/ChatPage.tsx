import { PageHeader } from '@/components/ui/primitives';
import { ChatView } from './ChatView';

export default function ChatPage() {
  return (
    <div className="flex h-full flex-col">
      <PageHeader title="Assistant" description="Grounded answers with charts, action plans and sources." />
      <div className="min-h-0 flex-1">
        <ChatView showList />
      </div>
    </div>
  );
}
