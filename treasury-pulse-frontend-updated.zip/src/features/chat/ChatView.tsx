import { Bot, Plus, RotateCcw, Send, Square, Trash2, User as UserIcon, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Link, useNavigate } from 'react-router-dom';
import { ChatChart } from '@/components/charts';
import { Badge, Button, Card } from '@/components/ui/primitives';
import { MoneyCell } from '@/components/ui/display';
import { cn } from '@/lib/cn';
import { useFilterStore } from '@/stores/filterStore';
import { useUiStore } from '@/stores/uiStore';
import type { ChatMessage, Recommendation } from '@/types/domain';
import { SUGGESTED_PROMPTS, useChat } from './useChat';

const DRILL = /\b(PARI|LOND|FRAN|SING|TOKY|MUMB|NEWY|TORO)(?: ([A-Z]{3}))?\b/g;

/** Turn "PARI EUR" mentions into drill-down links. */
function linkify(text: string): string {
  return text.replace(DRILL, (m, e: string, c?: string) => `[${m}](#drill:${e}:${c ?? ''})`);
}

function ActionPlan({ items }: { items: Recommendation[] }) {
  return (
    <Card className="mt-3 border-accent/40 bg-accent/5 p-3">
      <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-accent">Action plan</div>
      <ol className="space-y-2">
        {items.map((r, i) => (
          <li key={r.id} className="flex items-start gap-2 text-sm">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground">
              {i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="font-medium">{r.title}</div>
              <div className="text-xs text-muted-foreground">{r.rationale}</div>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                <Badge tone={r.priority === 1 ? 'crit' : r.priority === 2 ? 'warn' : 'neutral'}>P{r.priority}</Badge>
                <span>
                  Impact: <MoneyCell amount={r.expectedImpact} currency={r.currency} compact />
                </span>
                <Link
                  className="text-accent underline"
                  to={`/what-if?entity=${r.entityCode}&ccy=${r.currency}${r.action === 'DELAY_PAYMENTS' ? '&capex=5' : '&delay=2'}`}
                >
                  Open in What-If
                </Link>
              </div>
            </div>
          </li>
        ))}
      </ol>
    </Card>
  );
}

function Message({ m }: { m: ChatMessage }) {
  const set = useFilterStore((s) => s.set);
  const nav = useNavigate();
  const closeChat = useUiStore((s) => s.closeChat);
  const user = m.role === 'user';
  return (
    <div className={cn('flex gap-2.5', user && 'flex-row-reverse')}>
      <div className={cn('flex h-7 w-7 shrink-0 items-center justify-center rounded-full', user ? 'bg-muted' : 'bg-accent text-accent-foreground')}>
        {user ? <UserIcon className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </div>
      <div className={cn('max-w-[85%] rounded-lg px-3 py-2 text-sm', user ? 'bg-accent text-accent-foreground' : 'border border-border bg-surface')}>
        {user ? (
          m.content
        ) : (
          <>
            {m.content === '' ? (
              <span className="text-muted-foreground">Thinking…</span>
            ) : (
              <div className="prose-sm [&_a]:text-accent [&_a]:underline [&_li]:ml-4 [&_li]:list-disc [&_p]:mb-2 [&_strong]:font-semibold">
                <ReactMarkdown
                  urlTransform={(u) => u}
                  components={{
                    a: ({ href, children }) =>
                      href?.startsWith('#drill:') ? (
                        <button
                          className="text-accent underline"
                          onClick={() => {
                            const [, e, c] = href.split(':');
                            set({ region: null, entity: e, currencies: c ? [c] : [] });
                            closeChat();
                            nav('/dashboard');
                          }}
                        >
                          {children}
                        </button>
                      ) : (
                        <a href={href}>{children}</a>
                      ),
                  }}
                >
                  {linkify(m.content)}
                </ReactMarkdown>
              </div>
            )}
            {m.chart && (
              <div className="mt-2">
                <ChatChart spec={m.chart} />
              </div>
            )}
            {m.actionPlan && m.actionPlan.length > 0 && <ActionPlan items={m.actionPlan} />}
            {m.sources && m.sources.length > 0 && (
              <div className="mt-3 border-t border-border pt-2 text-xs text-muted-foreground">
                <span className="font-medium">Sources: </span>
                {m.sources.map((s, i) => (
                  <span key={s.ref}>
                    {i > 0 && ' · '}
                    <Link to={s.ref} className="underline">
                      {s.label}
                    </Link>
                  </span>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export function ChatView({ showList }: { showList?: boolean }) {
  const chat = useChat();
  const [text, setText] = useState('');
  const bottom = useRef<HTMLDivElement>(null);
  const seed = useUiStore((s) => s.chatSeed);
  const clearSeed = useUiStore((s) => s.clearSeed);
  const activeMessages = chat.active?.messages;
  const messages = useMemo(() => activeMessages ?? [], [activeMessages]);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  useEffect(() => {
    if (seed) {
      setText(seed);
      clearSeed();
    }
  }, [seed, clearSeed]);

  const submit = () => {
    const t = text;
    setText('');
    void chat.send(t);
  };

  return (
    <div className="flex h-full min-h-0 gap-4">
      {showList && (
        <Card className="hidden w-60 shrink-0 flex-col md:flex">
          <div className="p-2">
            <Button variant="primary" className="w-full" onClick={() => chat.store.newChat()}>
              <Plus className="h-4 w-4" /> New chat
            </Button>
          </div>
          <ul className="min-h-0 flex-1 overflow-y-auto p-2 pt-0">
            {chat.store.conversations.map((c) => (
              <li key={c.id} className="group flex items-center">
                <button
                  onClick={() => chat.store.select(c.id)}
                  className={cn('min-w-0 flex-1 truncate rounded px-2 py-1.5 text-left text-sm hover:bg-muted', c.id === chat.active?.id && 'bg-muted font-medium')}
                >
                  {c.title}
                </button>
                <button aria-label="Delete conversation" onClick={() => chat.store.remove(c.id)} className="p-1 opacity-0 group-hover:opacity-100">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        </Card>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1" aria-live="polite">
          {messages.length === 0 ? (
            <div className="mx-auto max-w-md py-10 text-center">
              <Bot className="mx-auto h-10 w-10 text-accent" />
              <h2 className="mt-2 text-lg font-semibold">Treasury assistant</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Ask about shortfalls, scenarios, surplus or what to do next. Answers are grounded in your in-scope data.
              </p>
              <div className="mt-4 grid gap-2">
                {SUGGESTED_PROMPTS.map((p) => (
                  <button key={p} onClick={() => void chat.send(p)} className="rounded-md border border-border bg-surface px-3 py-2 text-left text-sm hover:bg-muted">
                    {p}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) => <Message key={m.id} m={m} />)
          )}
          <div ref={bottom} />
        </div>
        <div className="mt-3">
          <div className="mb-2 flex flex-wrap items-center gap-1.5" aria-label="Context sent with your question">
            {chat.activeChips.map((c) => (
              <span key={c.key} className="inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-xs">
                {c.label}
                <button aria-label={`Remove ${c.label}`} onClick={() => chat.removeChip(c.key)}>
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            {chat.activeChips.length < chat.chips.length && (
              <button className="text-xs text-accent underline" onClick={chat.resetChips}>
                Restore context
              </button>
            )}
          </div>
          <form
            className="flex items-end gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
          >
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  submit();
                }
              }}
              rows={2}
              placeholder="Ask about liquidity, e.g. “Why is there a shortfall in EUR next week?”"
              className="min-h-[44px] flex-1 resize-none rounded-md border border-border bg-surface px-3 py-2 text-sm"
            />
            {chat.streaming ? (
              <Button onClick={chat.stop} type="button" aria-label="Stop generating">
                <Square className="h-4 w-4" /> Stop
              </Button>
            ) : (
              <>
                {messages.length > 0 && (
                  <Button type="button" onClick={() => void chat.retry()} aria-label="Retry last answer">
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                )}
                <Button variant="primary" type="submit" disabled={!text.trim()} aria-label="Send">
                  <Send className="h-4 w-4" />
                </Button>
              </>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}


