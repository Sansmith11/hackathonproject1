import { useCallback, useMemo, useRef, useState } from 'react';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { apiStream } from '@/api/client';
import { useFocus, useLatestPositions } from '@/hooks/useFocus';
import { useScenarioStore, isBaseline } from '@/stores/scenarioStore';
import type { ChatContext, ChatFinal, ChatMessage } from '@/types/domain';

export interface Conversation {
  id: string;
  serverId?: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
}

interface ChatStore {
  conversations: Conversation[];
  activeId: string | null;
  newChat: () => string;
  select: (id: string) => void;
  patch: (id: string, fn: (c: Conversation) => Conversation) => void;
  remove: (id: string) => void;
}

const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

export const useChatStore = create<ChatStore>()(
  persist(
    (set) => ({
      conversations: [],
      activeId: null,
      newChat: () => {
        const c: Conversation = { id: uid(), title: 'New chat', messages: [], createdAt: new Date().toISOString() };
        set((s) => ({ conversations: [c, ...s.conversations], activeId: c.id }));
        return c.id;
      },
      select: (id) => set({ activeId: id }),
      patch: (id, fn) => set((s) => ({ conversations: s.conversations.map((c) => (c.id === id ? fn(c) : c)) })),
      remove: (id) =>
        set((s) => {
          const conversations = s.conversations.filter((c) => c.id !== id);
          return { conversations, activeId: s.activeId === id ? (conversations[0]?.id ?? null) : s.activeId };
        }),
    }),
    { name: 'tp-chat', version: 1, partialize: (s) => ({ conversations: s.conversations.slice(0, 20), activeId: s.activeId }) },
  ),
);

export const SUGGESTED_PROMPTS = [
  'Why is there a shortfall in EUR next week?',
  'What if we delay payments by 3 days?',
  "What's my surplus position in APAC?",
  'What action plan do you recommend?',
];

export interface ContextChip {
  key: 'entity' | 'currency' | 'date' | 'scenario';
  label: string;
}

export function useChat() {
  const store = useChatStore();
  const focus = useFocus();
  const { asOfDate } = useLatestPositions();
  const scenario = useScenarioStore((s) => s.params);
  const [removed, setRemoved] = useState<Set<ContextChip['key']>>(new Set());
  const [streaming, setStreaming] = useState(false);
  const abort = useRef<AbortController | null>(null);

  const chips = useMemo<ContextChip[]>(() => {
    const list: ContextChip[] = [];
    if (focus.entity) list.push({ key: 'entity', label: `Entity: ${focus.entity}` });
    if (focus.currency) list.push({ key: 'currency', label: `Currency: ${focus.currency}` });
    if (asOfDate) list.push({ key: 'date', label: `Date: ${asOfDate}` });
    if (!isBaseline(scenario)) list.push({ key: 'scenario', label: 'Active what-if scenario' });
    return list;
  }, [focus.entity, focus.currency, asOfDate, scenario]);

  const activeChips = chips.filter((c) => !removed.has(c.key));
  const context: ChatContext = {
    entityCode: removed.has('entity') ? null : focus.entity,
    currency: removed.has('currency') ? null : focus.currency,
    date: removed.has('date') ? undefined : asOfDate,
    scenario: removed.has('scenario') || isBaseline(scenario) ? null : scenario,
  };

  const active = store.conversations.find((c) => c.id === store.activeId) ?? null;

  const run = useCallback(
    async (convId: string, text: string, serverId?: string) => {
      const asstId = uid();
      store.patch(convId, (c) => ({
        ...c,
        messages: [...c.messages, { id: asstId, role: 'assistant', content: '', createdAt: new Date().toISOString() }],
      }));
      setStreaming(true);
      abort.current = new AbortController();
      let acc = '';
      try {
        const final = await apiStream<ChatFinal>(
          '/chat',
          { conversationId: serverId, message: text, context },
          (t) => {
            acc += t;
            store.patch(convId, (c) => ({
              ...c,
              messages: c.messages.map((m) => (m.id === asstId ? { ...m, content: acc } : m)),
            }));
          },
          abort.current.signal,
        );
        if (final) {
          store.patch(convId, (c) => ({
            ...c,
            serverId: final.conversationId,
            messages: c.messages.map((m) =>
              m.id === asstId ? { ...m, chart: final.chart, actionPlan: final.actionPlan, sources: final.sources } : m,
            ),
          }));
        }
      } catch (e) {
        if ((e as Error).name !== 'AbortError') {
          store.patch(convId, (c) => ({
            ...c,
            messages: c.messages.map((m) =>
              m.id === asstId ? { ...m, content: acc || `Sorry, I couldn't answer that: ${(e as Error).message}` } : m,
            ),
          }));
        }
      } finally {
        setStreaming(false);
        abort.current = null;
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [context.entityCode, context.currency, context.date, context.scenario],
  );

  const send = useCallback(
    async (text: string) => {
      const t = text.trim();
      if (!t || streaming) return;
      let id = useChatStore.getState().activeId;
      if (!id) id = store.newChat();
      const conv = useChatStore.getState().conversations.find((c) => c.id === id)!;
      store.patch(id, (c) => ({
        ...c,
        title: c.messages.length === 0 ? t.slice(0, 40) : c.title,
        messages: [...c.messages, { id: uid(), role: 'user', content: t, createdAt: new Date().toISOString() }],
      }));
      await run(id, t, conv.serverId);
    },
    [run, store, streaming],
  );

  const retry = useCallback(async () => {
    if (!active || streaming) return;
    const lastUser = [...active.messages].reverse().find((m) => m.role === 'user');
    if (!lastUser) return;
    store.patch(active.id, (c) => {
      const idx = c.messages.map((m) => m.id).lastIndexOf(lastUser.id);
      return { ...c, messages: c.messages.slice(0, idx + 1) };
    });
    await run(active.id, lastUser.content, active.serverId);
  }, [active, run, store, streaming]);

  const stop = useCallback(() => abort.current?.abort(), []);

  return {
    store,
    active,
    streaming,
    send,
    stop,
    retry,
    chips,
    activeChips,
    removeChip: (k: ContextChip['key']) => setRemoved((s) => new Set(s).add(k)),
    resetChips: () => setRemoved(new Set()),
  };
}
