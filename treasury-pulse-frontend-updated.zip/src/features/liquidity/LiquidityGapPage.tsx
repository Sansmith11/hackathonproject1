import { useMemo, useState } from 'react';
import { useBands, useGap } from '@/api/hooks';
import { LiquidityGapChart } from '@/components/charts';
import { MoneyCell, NoThresholdChip, SeverityChip } from '@/components/ui/display';
import { EmptyState, QueryBoundary, Widget } from '@/components/ui/feedback';
import { Badge, Card, CardHeader, PageHeader } from '@/components/ui/primitives';
import { Tooltip } from '@/components/ui/overlay';
import { useLatestPositions } from '@/hooks/useFocus';
import { useScopeFilter } from '@/hooks/useScopeFilter';
import { SEVERITY_META } from '@/lib/alerts';
import { cn } from '@/lib/cn';
import { formatDate, formatPct } from '@/lib/format';
import { summarizePairs } from '@/lib/portfolio';
import { useFilterStore } from '@/stores/filterStore';

const CELL: Record<string, string> = {
  OK: 'bg-ok/70',
  WARNING: 'bg-warn/80',
  CRITICAL: 'bg-crit/80',
  EMERGENCY: 'bg-crit',
};

export default function LiquidityGapPage() {
  const all = useGap({});
  const bands = useBands();
  const latest = useLatestPositions();
  const matches = useScopeFilter();
  const set = useFilterStore((s) => s.set);
  const [view, setView] = useState<'table' | 'heatmap'>('table');
  const [sel, setSel] = useState<string | null>(null);

  const pairs = useMemo(
    () =>
      summarizePairs(latest.data, all.data ?? [])
        .filter((p) => matches(p.entityCode, p.currency))
        .sort((a, b) => (a.worst?.gap ?? Infinity) - (b.worst?.gap ?? Infinity)),
    [latest.data, all.data, matches],
  );
  const selected = sel ?? (pairs.find((p) => p.worst)?.entityCode + '|' + pairs.find((p) => p.worst)?.currency);
  const [selE, selC] = (selected ?? '|').split('|');
  const selRows = (all.data ?? []).filter((g) => g.entityCode === selE && g.currency === selC);

  const heat = useMemo(() => {
    const m = new Map<string, typeof selRows>();
    for (const g of all.data ?? []) {
      if (!matches(g.entityCode, g.currency)) continue;
      const k = `${g.entityCode}|${g.currency}`;
      m.set(k, [...(m.get(k) ?? []), g]);
    }
    return [...m];
  }, [all.data, matches]);

  return (
    <div>
      <PageHeader
        title="Liquidity gap"
        description="Projected position minus threshold, 30-day horizon"
        actions={
          <div className="flex rounded-md border border-border">
            {(['table', 'heatmap'] as const).map((v) => (
              <button key={v} onClick={() => setView(v)} aria-pressed={view === v} className={cn('px-3 py-1.5 text-sm capitalize', view === v && 'bg-accent text-accent-foreground')}>
                {v}
              </button>
            ))}
          </div>
        }
      />
      <div className="space-y-4">
        <Card>
          <CardHeader title={view === 'table' ? 'Gap by entity and currency' : 'Severity heatmap'} description={view === 'table' ? 'Sorted by worst gap · click a row to chart it' : 'Rows = entity/currency, columns = next 30 days'} />
          <QueryBoundary query={all} isEmpty={(d) => d.length === 0} empty={<EmptyState title="No thresholds apply to the selected scope" />}>
            {() =>
              view === 'table' ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="text-left text-xs text-muted-foreground">
                      <tr>
                        <th className="px-4 py-2 font-medium">Entity</th>
                        <th className="px-2 py-2 font-medium">Ccy</th>
                        <th className="px-2 py-2 text-right font-medium">Threshold</th>
                        <th className="px-2 py-2 text-right font-medium">Lowest projected</th>
                        <th className="px-2 py-2 font-medium">On</th>
                        <th className="px-2 py-2 text-right font-medium">Gap</th>
                        <th className="px-2 py-2 text-right font-medium">Headroom</th>
                        <th className="px-4 py-2 font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pairs.map((p) => {
                        const key = `${p.entityCode}|${p.currency}`;
                        return (
                          <tr key={key} onClick={() => setSel(key)} className={cn('cursor-pointer border-t border-border hover:bg-muted/60', key === selected && 'bg-muted')}>
                            <td className="px-4 py-2 font-medium">{p.entityCode}</td>
                            <td className="px-2 py-2">{p.currency}</td>
                            <td className="px-2 py-2 text-right">{p.threshold === null ? <NoThresholdChip /> : <MoneyCell amount={p.threshold} currency={p.currency} compact />}</td>
                            <td className="px-2 py-2 text-right">{p.worst ? <MoneyCell amount={p.worst.projected} currency={p.currency} compact /> : '—'}</td>
                            <td className="px-2 py-2">{p.worst ? formatDate(p.worst.date, 'dd MMM') : '—'}</td>
                            <td className="px-2 py-2 text-right">{p.worst ? <MoneyCell amount={p.worst.gap} currency={p.currency} compact tone="auto" /> : '—'}</td>
                            <td className="num px-2 py-2 text-right">{p.worst ? formatPct(p.worst.headroomPct) : '—'}</td>
                            <td className="flex items-center gap-1.5 px-4 py-2">
                              {p.worst && <SeverityChip severity={p.severity} />}
                              {p.deployable > 0 && <Badge tone="ok">Deployable surplus</Badge>}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="overflow-x-auto p-4">
                  <div className="min-w-[760px]">
                    {heat.map(([key, rows]) => (
                      <div key={key} className="mb-1 flex items-center gap-2">
                        <button className="w-24 shrink-0 text-left text-xs font-medium hover:underline" onClick={() => setSel(key)}>
                          {key.replace('|', ' · ')}
                        </button>
                        <div className="flex flex-1 gap-0.5">
                          {rows.map((r) => (
                            <Tooltip key={r.date} content={`${formatDate(r.date, 'dd MMM')}: ${SEVERITY_META[r.severity].label} · gap ${Math.round(r.gap).toLocaleString()} · ${formatPct(r.headroomPct)}`}>
                              <div className={cn('h-6 flex-1 rounded-sm', CELL[r.severity])} aria-label={`${key} ${r.date} ${r.severity}`} />
                            </Tooltip>
                          ))}
                        </div>
                      </div>
                    ))}
                    <div className="mt-3 flex gap-4 pl-[104px] text-xs text-muted-foreground">
                      {(['OK', 'WARNING', 'CRITICAL', 'EMERGENCY'] as const).map((s) => (
                        <span key={s} className="flex items-center gap-1.5">
                          <span className={cn('h-3 w-3 rounded-sm', CELL[s])} /> {SEVERITY_META[s].label}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )
            }
          </QueryBoundary>
        </Card>

        <Widget
          title={`Projected position · ${selE} ${selC}`}
          description="Alert bands from the current threshold matrix"
          query={all}
          actions={
            selE && (
              <button className="text-xs text-accent underline" onClick={() => set({ entity: selE, currencies: [selC], region: null })}>
                Set as focus
              </button>
            )
          }
          isEmpty={() => selRows.length === 0}
          empty={<EmptyState title="Select a row with a threshold" />}
        >
          {() => <LiquidityGapChart rows={selRows} bands={bands.data} />}
        </Widget>
      </div>
    </div>
  );
}
