import { useMemo, useState } from 'react';
import {
  createColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  type SortingState,
  type VisibilityState,
} from './table';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Columns3, Download, Search } from 'lucide-react';
import Papa from 'papaparse';
import { useTransactions } from '@/api/hooks';
import { txnApi } from '@/api/endpoints/core';
import { MoneyCell } from '@/components/ui/display';
import { EmptyState, ErrorState } from '@/components/ui/feedback';
import { Dialog } from '@/components/ui/overlay';
import { Badge, Button, Card, Input, PageHeader, Select, Skeleton } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { downloadText } from '@/lib/csv';
import { formatDate, maskAccount } from '@/lib/format';
import { useFilterStore } from '@/stores/filterStore';
import type { Transaction } from '@/types/domain';
import { Link } from 'react-router-dom';

const CATEGORIES = ['CUSTOMER_RECEIPTS', 'INTEREST_INCOME', 'FX_SETTLEMENT', 'INTERCOMPANY', 'SUPPLIER_PAYMENT', 'OPEX', 'CAPEX', 'PAYROLL', 'TAX', 'LOAN_REPAYMENT'];
const PRODUCTS = ['WIRE', 'ACH', 'SEPA', 'FX_SPOT', 'LOAN', 'DEPOSIT', 'TRADE_FINANCE'];

const col = createColumnDef<Transaction>();
const columns = [
  col.accessor('transactionDate', { header: 'Date', cell: (c) => formatDate(c.getValue(), 'dd MMM yyyy') }),
  col.accessor('transactionId', { header: 'ID', cell: (c) => <span className="num text-xs">{c.getValue()}</span> }),
  col.accessor('entityCode', { header: 'Entity' }),
  col.accessor('currency', { header: 'Ccy' }),
  col.accessor('originalAmount', {
    header: 'Amount',
    cell: (c) => (
      <MoneyCell
        amount={c.getValue()}
        currency={c.row.original.currency}
        tone={c.row.original.direction === 'INFLOW' ? 'inflow' : 'outflow'}
        signed={false}
      />
    ),
  }),
  col.accessor('direction', {
    header: 'Direction',
    cell: (c) => <Badge tone={c.getValue() === 'INFLOW' ? 'ok' : 'crit'}>{c.getValue().toLowerCase()}</Badge>,
  }),
  col.accessor('category', { header: 'Category' }),
  col.accessor('productType', { header: 'Product' }),
  col.accessor('counterparty', { header: 'Counterparty' }),
  col.accessor('counterpartyRiskRating', { header: 'Rating' }),
  col.accessor('settlementStatus', { header: 'Status' }),
  col.accessor('accountNumber', { header: 'Account', cell: (c) => <span className="num">{maskAccount(c.getValue())}</span> }),
  col.accessor('paymentMethod', { header: 'Method' }),
];

export default function TransactionsPage() {
  const globalEntity = useFilterStore((s) => s.entity);
  const globalCcy = useFilterStore((s) => s.currencies);
  const globalRegion = useFilterStore((s) => s.region);
  const from = useFilterStore((s) => s.from);
  const to = useFilterStore((s) => s.to);

  const [direction, setDirection] = useState('');
  const [category, setCategory] = useState('');
  const [productType, setProductType] = useState('');
  const [settlementStatus, setStatus] = useState('');
  const [rating, setRating] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [sorting, setSorting] = useState<SortingState>([{ id: 'transactionDate', desc: true }]);
  const [visibility, setVisibility] = useState<VisibilityState>({ paymentMethod: false, accountNumber: false });
  const [showCols, setShowCols] = useState(false);
  const [detail, setDetail] = useState<Transaction | null>(null);

  const sort = sorting[0] ? `${sorting[0].id}:${sorting[0].desc ? 'desc' : 'asc'}` : 'transactionDate:desc';
  const query = {
    entity: globalEntity,
    currency: globalCcy.length === 1 ? globalCcy[0] : null,
    direction,
    category,
    productType,
    settlementStatus,
    rating,
    from,
    to,
    q,
    page,
    pageSize,
    sort,
  };
  const res = useTransactions(query);

  const table = useReactTable({
    data: res.data?.items ?? [],
    columns,
    state: { sorting, columnVisibility: visibility },
    onSortingChange: (u) => {
      setSorting(u);
      setPage(1);
    },
    onColumnVisibilityChange: setVisibility,
    manualSorting: true,
    manualPagination: true,
    enableSortingRemoval: false,
    getCoreRowModel: getCoreRowModel(),
  });

  const total = res.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const reset = <T,>(fn: (v: T) => void) => (v: T) => {
    fn(v);
    setPage(1);
  };
  const filtersActive = useMemo(
    () => [direction, category, productType, settlementStatus, rating, q].some(Boolean),
    [direction, category, productType, settlementStatus, rating, q],
  );

  const exportCsv = async () => {
    const rows: Transaction[] = [];
    for (let p = 1; p <= 10; p++) {
      const r = await txnApi.list({ ...query, page: p, pageSize: 500 });
      rows.push(...r.items);
      if (rows.length >= r.total) break;
    }
    downloadText('transactions.csv', Papa.unparse(rows.map((r) => ({ ...r, accountNumber: maskAccount(r.accountNumber) }))));
    toast(`Exported ${rows.length.toLocaleString()} rows${rows.length >= 5000 ? ' (capped at 5,000)' : ''}`, 'success');
  };

  void globalRegion;
  return (
    <div>
      <PageHeader
        title="Transactions"
        description={res.data ? `${total.toLocaleString()} transactions match` : 'Loading…'}
        actions={
          <>
            <Button onClick={() => setShowCols((s) => !s)}>
              <Columns3 className="h-4 w-4" /> Columns
            </Button>
            <Button onClick={() => void exportCsv()}>
              <Download className="h-4 w-4" /> Export CSV
            </Button>
          </>
        }
      />
      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-border p-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input className="w-56 pl-8" placeholder="Search id, counterparty…" value={q} onChange={(e) => reset(setQ)(e.target.value)} aria-label="Search transactions" />
          </div>
          <Select aria-label="Direction" value={direction} onChange={(e) => reset(setDirection)(e.target.value)}>
            <option value="">All directions</option>
            <option>INFLOW</option>
            <option>OUTFLOW</option>
          </Select>
          <Select aria-label="Category" value={category} onChange={(e) => reset(setCategory)(e.target.value)}>
            <option value="">All categories</option>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </Select>
          <Select aria-label="Product type" value={productType} onChange={(e) => reset(setProductType)(e.target.value)}>
            <option value="">All products</option>
            {PRODUCTS.map((c) => <option key={c}>{c}</option>)}
          </Select>
          <Select aria-label="Settlement status" value={settlementStatus} onChange={(e) => reset(setStatus)(e.target.value)}>
            <option value="">All statuses</option>
            <option>SETTLED</option>
            <option>PENDING</option>
          </Select>
          <Select aria-label="Counterparty rating" value={rating} onChange={(e) => reset(setRating)(e.target.value)}>
            <option value="">All ratings</option>
            {['A', 'B', 'C', 'D'].map((r) => <option key={r}>{r}</option>)}
          </Select>
          {filtersActive && (
            <button className="text-xs text-accent underline" onClick={() => { setDirection(''); setCategory(''); setProductType(''); setStatus(''); setRating(''); setQ(''); setPage(1); }}>
              Clear filters
            </button>
          )}
        </div>
        {showCols && (
          <div className="flex flex-wrap gap-3 border-b border-border bg-muted/40 px-3 py-2 text-xs">
            {table.getAllLeafColumns().map((c) => (
              <label key={c.id} className="flex items-center gap-1.5">
                <input type="checkbox" checked={c.getIsVisible()} onChange={c.getToggleVisibilityHandler()} />
                {String(c.columnDef.header)}
              </label>
            ))}
          </div>
        )}

        {res.isError ? (
          <ErrorState message={res.error.message} onRetry={() => void res.refetch()} />
        ) : res.isPending ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-8 w-full" />)}
          </div>
        ) : res.data.items.length === 0 ? (
          <EmptyState
            title="No transactions match"
            hint="Adjust filters, or upload a CSV to add transactions."
            action={<Link className="text-sm text-accent underline" to="/upload">Go to upload</Link>}
          />
        ) : (
          <div className={`overflow-x-auto ${res.isFetching ? 'opacity-70' : ''}`}>
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-foreground">
                {table.getHeaderGroups().map((hg) => (
                  <tr key={hg.id}>
                    {hg.headers.map((h) => {
                      const dir = h.column.getIsSorted();
                      return (
                        <th key={h.id} className={`px-3 py-2 font-medium ${h.id === 'originalAmount' ? 'text-right' : ''}`}>
                          <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={h.column.getToggleSortingHandler()}>
                            {flexRender(h.column.columnDef.header, h.getContext())}
                            {dir === 'asc' && <ArrowUp className="h-3 w-3" />}
                            {dir === 'desc' && <ArrowDown className="h-3 w-3" />}
                          </button>
                        </th>
                      );
                    })}
                  </tr>
                ))}
              </thead>
              <tbody>
                {table.getRowModel().rows.map((r) => (
                  <tr key={r.id} tabIndex={0} onClick={() => setDetail(r.original)} onKeyDown={(e) => e.key === 'Enter' && setDetail(r.original)} className="cursor-pointer border-t border-border hover:bg-muted/60">
                    {r.getVisibleCells().map((c) => (
                      <td key={c.id} className={`px-3 py-2 ${c.column.id === 'originalAmount' ? 'text-right' : ''}`}>
                        {flexRender(c.column.columnDef.cell, c.getContext())}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="flex items-center justify-between gap-3 border-t border-border px-3 py-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            Rows
            <Select aria-label="Page size" value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }} className="h-8">
              {[25, 50, 100].map((n) => <option key={n}>{n}</option>)}
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <span>
              Page {page} of {pages.toLocaleString()}
            </span>
            <Button size="sm" aria-label="Previous page" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button size="sm" aria-label="Next page" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)} side="right" title={detail?.transactionId ?? ''} description="Transaction detail">
        {detail && (
          <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
            {Object.entries(detail).map(([k, v]) => (
              <div key={k} className="contents">
                <dt className="text-muted-foreground">{k}</dt>
                <dd className="break-all text-right">{k === 'accountNumber' ? maskAccount(String(v)) : v === null ? '—' : String(v)}</dd>
              </div>
            ))}
          </dl>
        )}
      </Dialog>
    </div>
  );
}
