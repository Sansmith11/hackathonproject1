import { useQueryClient } from '@tanstack/react-query';
import { Download, FileText, Printer } from 'lucide-react';
import { useMemo, useState } from 'react';
import { reportsApi } from '@/api/endpoints/analytics';
import { useAlerts, useEntities, useGap, useReportHistory } from '@/api/hooks';
import { MoneyCell, SeverityChip } from '@/components/ui/display';
import { EmptyState, QueryBoundary } from '@/components/ui/feedback';
import { Badge, Button, Card, CardHeader, PageHeader, Select, Switch } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { useLatestPositions } from '@/hooks/useFocus';
import { downloadBlob } from '@/lib/csv';
import { formatBytes, formatDateTime, formatDate } from '@/lib/format';
import { summarizePairs } from '@/lib/portfolio';
import { useAuthStore } from '@/stores/authStore';
import type { ReportHistoryItem } from '@/types/domain';

type RType = 'SOD' | 'EOD';

function readPrefs(key: string): Record<RType, boolean> {
  try {
    return { SOD: true, EOD: true, ...JSON.parse(localStorage.getItem(key) ?? '{}') };
  } catch {
    return { SOD: true, EOD: true };
  }
}

function Preview({ type, entity }: { type: RType; entity: string }) {
  const latest = useLatestPositions();
  const gap = useGap({ entity: entity || null });
  const alerts = useAlerts({ status: 'OPEN' });
  const pairs = useMemo(
    () => summarizePairs(latest.data.filter((p) => !entity || p.entityCode === entity), gap.data ?? []),
    [latest.data, gap.data, entity],
  );
  const mine = (alerts.data ?? []).filter((a) => !entity || a.entityCode === entity);
  const sod = type === 'SOD';
  return (
    <div className="space-y-5 p-5 text-sm print:p-0" data-testid="report-preview">
      <div>
        <h2 className="text-lg font-semibold">{sod ? 'Start-of-day' : 'End-of-day'} liquidity report</h2>
        <p className="text-xs text-muted-foreground">
          {latest.asOfDate ? formatDate(latest.asOfDate) : ''} · Scope: {entity || 'all entities in scope'}
        </p>
      </div>
      <section>
        <h3 className="mb-1 font-semibold">{sod ? 'Opening position' : 'Position summary'}</h3>
        <table className="w-full text-xs">
          <tbody>
            {pairs.map((p) => (
              <tr key={p.entityCode + p.currency} className="border-t border-border">
                <td className="py-1 font-medium">{p.entityCode} {p.currency}</td>
                <td className="py-1 text-right"><MoneyCell amount={p.current} currency={p.currency} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <section>
        <h3 className="mb-1 font-semibold">{sod ? 'Forecast outlook (next 24–48h)' : 'Gap status'}</h3>
        <table className="w-full text-xs">
          <tbody>
            {pairs.filter((p) => p.worst).map((p) => (
              <tr key={p.entityCode + p.currency} className="border-t border-border">
                <td className="py-1 font-medium">{p.entityCode} {p.currency}</td>
                <td className="py-1 text-right"><MoneyCell amount={p.worst!.gap} currency={p.currency} compact tone="auto" /></td>
                <td className="py-1 text-right"><SeverityChip severity={p.severity} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <section>
        <h3 className="mb-1 font-semibold">{sod ? 'Overnight alerts' : 'Alerts triggered'}</h3>
        {mine.length === 0 ? (
          <p className="text-xs text-muted-foreground">None.</p>
        ) : (
          <ul className="space-y-1 text-xs">
            {mine.map((a) => (
              <li key={a.id} className="flex items-center gap-2">
                <SeverityChip severity={a.severity} /> {a.entityCode} {a.currency} · {formatDate(a.forDate, 'dd MMM')}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

export default function ReportsPage() {
  const user = useAuthStore((s) => s.user);
  const entities = useEntities();
  const history = useReportHistory();
  const qc = useQueryClient();
  const [type, setType] = useState<RType>('SOD');
  const [format, setFormat] = useState<'PDF' | 'CSV'>('PDF');
  const [entity, setEntity] = useState('');
  const [busy, setBusy] = useState(false);
  const prefKey = `tp-report-prefs-${user?.id ?? 'anon'}`;
  const [prefs, setPrefs] = useState(() => readPrefs(prefKey));

  const setPref = (t: RType, v: boolean) => {
    const next = { ...prefs, [t]: v };
    setPrefs(next);
    try {
      localStorage.setItem(prefKey, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const generate = async () => {
    setBusy(true);
    try {
      const { blob } = await reportsApi.generate({ type, format, entity: entity || null });
      downloadBlob(`${type}-${entity || 'all'}.${format.toLowerCase()}`, blob);
      toast(`${type} report generated`, 'success');
      void qc.invalidateQueries({ queryKey: ['reports', 'history'] });
    } finally {
      setBusy(false);
    }
  };

  const redownload = async (r: ReportHistoryItem) => {
    const { blob } = await reportsApi.download(r.id);
    downloadBlob(`${r.type}-${r.entityCode ?? 'all'}.${r.format.toLowerCase()}`, blob);
  };

  return (
    <div>
      <PageHeader title="Reports" description="Generate start-of-day and end-of-day liquidity reports" />
      <div className="grid gap-4 xl:grid-cols-[360px_1fr]">
        <div className="space-y-4">
          <Card>
            <CardHeader title="Generate now" />
            <div className="space-y-3 p-4">
              <div className="flex rounded-md border border-border">
                {(['SOD', 'EOD'] as const).map((t) => (
                  <button key={t} aria-pressed={type === t} onClick={() => setType(t)} className={`flex-1 px-3 py-1.5 text-sm ${type === t ? 'bg-accent text-accent-foreground' : ''}`}>
                    {t === 'SOD' ? 'Start of day' : 'End of day'}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <Select aria-label="Format" value={format} onChange={(e) => setFormat(e.target.value as 'PDF' | 'CSV')}>
                  <option>PDF</option>
                  <option>CSV</option>
                </Select>
                <Select aria-label="Entity scope" className="flex-1" value={entity} onChange={(e) => setEntity(e.target.value)}>
                  <option value="">All entities in scope</option>
                  {(entities.data ?? []).map((e) => <option key={e.code} value={e.code}>{e.code} · {e.city}</option>)}
                </Select>
              </div>
              <Button variant="primary" className="w-full" onClick={() => void generate()} disabled={busy}>
                <Download className="h-4 w-4" /> {busy ? 'Generating…' : 'Generate & download'}
              </Button>
              <Button className="w-full" onClick={() => window.print()}>
                <Printer className="h-4 w-4" /> Print preview
              </Button>
            </div>
          </Card>
          <Card>
            <CardHeader title="My subscriptions" description="Email delivery follows the Admin schedule" />
            <div className="space-y-3 p-4 text-sm">
              {(['SOD', 'EOD'] as const).map((t) => (
                <div key={t} className="flex items-center justify-between">
                  <span>{t === 'SOD' ? 'Start-of-day report' : 'End-of-day report'}</span>
                  <Switch checked={prefs[t]} onChange={(v) => setPref(t, v)} label={`Receive ${t}`} />
                </div>
              ))}
            </div>
          </Card>
        </div>
        <Card>
          <CardHeader title="Preview" description="Same data the generated file contains" />
          <Preview type={type} entity={entity} />
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader title="History" />
        <QueryBoundary query={history} isEmpty={(d) => d.length === 0} empty={<EmptyState title="No reports generated yet" hint="Generate one above and it will appear here." />}>
          {(rows) => (
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-foreground">
                <tr>{['Type', 'Format', 'Scope', 'Generated', 'By', 'Size', ''].map((h) => <th key={h} className="px-4 py-2 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-4 py-2"><Badge tone="accent">{r.type}</Badge></td>
                    <td className="px-4 py-2"><FileText className="mr-1 inline h-3.5 w-3.5" />{r.format}</td>
                    <td className="px-4 py-2">{r.entityCode ?? 'All'}</td>
                    <td className="px-4 py-2">{formatDateTime(r.generatedAt)}</td>
                    <td className="px-4 py-2">{r.generatedBy}</td>
                    <td className="px-4 py-2">{formatBytes(r.sizeBytes)}</td>
                    <td className="px-4 py-2 text-right"><Button size="sm" onClick={() => void redownload(r)}>Download</Button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </QueryBoundary>
      </Card>
    </div>
  );
}
