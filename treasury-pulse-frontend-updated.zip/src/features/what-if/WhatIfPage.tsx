import { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MessageSquare, RotateCcw, Save, Trash2 } from 'lucide-react';
import { useForecast, useGap, useScenario, useTransactions } from '@/api/hooks';
import { ScenarioCompareChart } from '@/components/charts';
import { PairPicker } from '@/components/layout/PairPicker';
import { MoneyCell } from '@/components/ui/display';
import { EmptyState, ErrorState } from '@/components/ui/feedback';
import { Badge, Button, Card, CardHeader, Input, Label, PageHeader, Select, Skeleton } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { useFocus } from '@/hooks/useFocus';
import { cn } from '@/lib/cn';
import { formatDate } from '@/lib/format';
import { isBaseline, paramsToSearch, searchToParams, useScenarioStore } from '@/stores/scenarioStore';
import { useAuthStore } from '@/stores/authStore';
import { useUiStore } from '@/stores/uiStore';
import type { RiskRating, ScenarioParams } from '@/types/domain';

const FX = [-15, -10, -5, 0, 5, 10, 15];
const RATE: ScenarioParams['rateShockBps'][] = [-200, -100, -50, 0, 50, 100, 200];

function useDebounced<T>(value: T, ms: number): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

function Segmented<T extends string | number>({ options, value, onChange, label, fmt }: { options: T[]; value: T; onChange: (v: T) => void; label: string; fmt?: (v: T) => string }) {
  return (
    <div role="group" aria-label={label} className="inline-flex flex-wrap overflow-hidden rounded-md border border-border">
      {options.map((o) => (
        <button key={String(o)} type="button" aria-pressed={o === value} onClick={() => onChange(o)} className={cn('num px-2 py-1 text-xs', o === value ? 'bg-accent text-accent-foreground' : 'hover:bg-muted')}>
          {fmt ? fmt(o) : String(o)}
        </button>
      ))}
    </div>
  );
}

export default function WhatIfPage() {
  const { params, setParams, replace, reset } = useScenarioStore();
  const [urlParams, setUrlParams] = useSearchParams();
  const hydrated = useRef(false);
  const focus = useFocus();
  const user = useAuthStore((s) => s.user);
  const openChat = useUiStore((s) => s.openChat);
  const [cp, setCp] = useState('');
  const [cpRating, setCpRating] = useState<RiskRating>('D');
  const [name, setName] = useState('');
  const saveKey = `tp-scenarios-${user?.id ?? 'anon'}`;
  const [saved, setSaved] = useState<{ name: string; params: ScenarioParams }[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(saveKey) ?? '[]');
    } catch {
      return [];
    }
  });

  // URL ⇄ store
  useEffect(() => {
    if (!hydrated.current) {
      hydrated.current = true;
      const fromUrl = searchToParams(urlParams);
      if (!isBaseline(fromUrl)) replace(fromUrl);
      return;
    }
    setUrlParams(
      (prev) => {
        const next = new URLSearchParams(prev);
        for (const k of ['delay', 'capex', 'rate', 'fx', 'dg']) next.delete(k);
        paramsToSearch(params).forEach((v, k) => next.set(k, v));
        return next;
      },
      { replace: true },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const debounced = useDebounced(params, 400);
  const scenario = useScenario(debounced, focus.entity, focus.currency, !!user);
  const forecast = useForecast(focus.entity, focus.currency);
  const gap = useGap({ entity: focus.entity, currency: focus.currency });
  const txns = useTransactions({ entity: focus.entity, pageSize: 100, page: 1 });
  const threshold = gap.data?.[0]?.threshold ?? null;

  const counterparties = useMemo(() => {
    const m = new Map<string, RiskRating>();
    for (const t of txns.data?.items ?? []) m.set(t.counterparty, t.counterpartyRiskRating);
    return [...m].sort();
  }, [txns.data]);
  const capexItems = (forecast.data?.drivers ?? []).filter((d) => /capex/i.test(d.label));

  const save = () => {
    if (!name.trim()) return;
    const next = [...saved.filter((s) => s.name !== name.trim()), { name: name.trim(), params }];
    setSaved(next);
    try {
      localStorage.setItem(saveKey, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
    setName('');
    toast('Scenario saved', 'success');
  };
  const removeSaved = (n: string) => {
    const next = saved.filter((s) => s.name !== n);
    setSaved(next);
    try {
      localStorage.setItem(saveKey, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const res = scenario.data;
  const ccy = focus.currency ?? '';
  const delta = (a: number, b: number) => b - a;

  return (
    <div>
      <PageHeader
        title="What-if analysis"
        description={`Stress the 30-day forecast for ${focus.entity ?? '—'} · ${ccy}`}
        actions={<PairPicker />}
      />
      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        <Card className="h-fit">
          <CardHeader
            title="Scenario controls"
            actions={
              <Button size="sm" onClick={reset} disabled={isBaseline(params)}>
                <RotateCcw className="h-3.5 w-3.5" /> Reset to baseline
              </Button>
            }
          />
          <div className="space-y-5 p-4">
            <div>
              <Label>
                Receivables delay: <span className="num text-foreground">+{params.paymentDelayDays} days</span>
              </Label>
              <input type="range" min={0} max={5} step={1} value={params.paymentDelayDays} aria-label="Payment delay days" className="w-full accent-[hsl(var(--accent))]" onChange={(e) => setParams({ paymentDelayDays: Number(e.target.value) as ScenarioParams['paymentDelayDays'] })} />
              <p className="text-xs text-muted-foreground">Expected customer payments arrive this many days late.</p>
            </div>
            <div>
              <Label>
                Capex postponement: <span className="num text-foreground">{params.capexShiftDays} days</span>
              </Label>
              <input type="range" min={0} max={30} step={1} value={params.capexShiftDays} aria-label="Capex postponement days" className="w-full accent-[hsl(var(--accent))]" onChange={(e) => setParams({ capexShiftDays: Number(e.target.value) })} />
              {capexItems.length > 0 ? (
                <ul className="mt-1 space-y-0.5 text-xs text-muted-foreground">
                  {capexItems.map((c) => (
                    <li key={c.label} className="flex justify-between">
                      <span>{c.label} · {formatDate(c.date, 'dd MMM')}</span>
                      <MoneyCell amount={c.amount} currency={ccy} compact />
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-muted-foreground">No scheduled capex for this position.</p>
              )}
            </div>
            <div>
              <Label>FX shock per currency (%)</Label>
              <div className="space-y-2">
                {focus.currencies.map((c) => (
                  <div key={c} className="flex items-center gap-2">
                    <span className="num w-9 text-xs font-medium">{c}</span>
                    <Segmented label={`${c} FX shock`} options={FX} value={params.fxShockPct[c] ?? 0} fmt={(v) => (v > 0 ? `+${v}` : String(v))} onChange={(v) => setParams({ fxShockPct: { ...params.fxShockPct, [c]: v } })} />
                  </div>
                ))}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">Valuation impact applies to {ccy}.</p>
            </div>
            <div>
              <Label>Interest-rate shock (bps)</Label>
              <Segmented label="Rate shock" options={RATE} value={params.rateShockBps} fmt={(v) => (v > 0 ? `+${v}` : String(v))} onChange={(v) => setParams({ rateShockBps: v })} />
            </div>
            <div>
              <Label>Counterparty rating shift</Label>
              <div className="flex gap-2">
                <Select aria-label="Counterparty" className="min-w-0 flex-1" value={cp} onChange={(e) => setCp(e.target.value)}>
                  <option value="">Choose…</option>
                  {counterparties.map(([n, r]) => <option key={n} value={n}>{n} ({r})</option>)}
                </Select>
                <Select aria-label="New rating" value={cpRating} onChange={(e) => setCpRating(e.target.value as RiskRating)}>
                  {['A', 'B', 'C', 'D'].map((r) => <option key={r}>{r}</option>)}
                </Select>
                <Button disabled={!cp} onClick={() => { setParams({ ratingDowngrades: { ...params.ratingDowngrades, [cp]: cpRating } }); setCp(''); }}>Add</Button>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {Object.entries(params.ratingDowngrades).map(([n, r]) => (
                  <Badge key={n} tone="warn" className="gap-1">
                    {n} → {r}
                    <button aria-label={`Remove ${n}`} onClick={() => { const { [n]: _drop, ...rest } = params.ratingDowngrades; void _drop; setParams({ ratingDowngrades: rest }); }}>×</button>
                  </Badge>
                ))}
              </div>
            </div>
            <div className="border-t border-border pt-4">
              <Label>Saved scenarios</Label>
              <div className="flex gap-2">
                <Input placeholder="Name this scenario" value={name} onChange={(e) => setName(e.target.value)} />
                <Button onClick={save} disabled={!name.trim()} aria-label="Save scenario"><Save className="h-4 w-4" /></Button>
              </div>
              <ul className="mt-2 space-y-1">
                {saved.map((s) => (
                  <li key={s.name} className="flex items-center justify-between text-sm">
                    <button className="text-accent underline" onClick={() => replace(s.params)}>{s.name}</button>
                    <button aria-label={`Delete ${s.name}`} onClick={() => removeSaved(s.name)}><Trash2 className="h-3.5 w-3.5" /></button>
                  </li>
                ))}
                {saved.length === 0 && <li className="text-xs text-muted-foreground">None yet.</li>}
              </ul>
            </div>
          </div>
        </Card>

        <div className="min-w-0 space-y-4">
          {scenario.isError ? (
            <Card><ErrorState message={scenario.error.message} onRetry={() => void scenario.refetch()} /></Card>
          ) : !focus.ready ? (
            <Card><EmptyState title="Choose an entity and currency" /></Card>
          ) : (
            <>
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5" data-testid="impact-cards">
                {[
                  { label: 'Min gap Δ', v: res ? delta(res.impact.minGapBaseline, res.impact.minGapScenario) : null },
                  { label: 'Funding cost Δ', v: res ? res.impact.overdraftCostDelta : null, invert: true },
                  { label: 'FX gain / loss', v: res ? res.impact.fxGainLoss : null },
                  { label: 'Interest Δ', v: res ? res.impact.interestDelta : null },
                  { label: 'Surplus Δ', v: res ? res.impact.deployableSurplusDelta : null },
                ].map((c) => (
                  <Card key={c.label} className="p-3">
                    <div className="text-xs text-muted-foreground">{c.label}</div>
                    {c.v === null ? (
                      <Skeleton className="mt-1 h-6 w-20" />
                    ) : (
                      <MoneyCell amount={c.v} currency={ccy} compact signed className={cn('text-lg', c.v !== 0 && ((c.invert ? c.v > 0 : c.v < 0) ? 'text-crit' : 'text-ok'))} />
                    )}
                  </Card>
                ))}
              </div>
              <Card>
                <CardHeader
                  title="Baseline vs scenario"
                  description={res ? `Lowest gap ${Math.round(res.impact.minGapBaseline).toLocaleString()} → ${Math.round(res.impact.minGapScenario).toLocaleString()} ${ccy}` : undefined}
                  actions={
                    <Button size="sm" onClick={() => openChat(`What if receipts are delayed by ${params.paymentDelayDays} days for ${focus.entity} ${ccy}? What should we do?`)}>
                      <MessageSquare className="h-3.5 w-3.5" /> Ask the assistant
                    </Button>
                  }
                />
                <div className="p-4">
                  <ScenarioCompareChart baseline={res?.baseline} scenario={res?.scenario} currency={ccy} threshold={threshold} loading={scenario.isPending} />
                </div>
              </Card>
              <Card>
                <CardHeader title="Day-by-day comparison" />
                <div className="max-h-80 overflow-auto">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-surface text-left text-xs text-muted-foreground">
                      <tr>
                        <th className="px-4 py-2 font-medium">Date</th>
                        <th className="px-2 py-2 text-right font-medium">Baseline</th>
                        <th className="px-2 py-2 text-right font-medium">Scenario</th>
                        <th className="px-4 py-2 text-right font-medium">Delta</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(res?.baseline ?? []).map((b, i) => {
                        const s = res!.scenario[i];
                        const d = s.projected - b.projected;
                        return (
                          <tr key={b.date} className="border-t border-border">
                            <td className="px-4 py-1.5">{formatDate(b.date, 'EEE dd MMM')}</td>
                            <td className="px-2 py-1.5 text-right"><MoneyCell amount={b.projected} currency={ccy} compact /></td>
                            <td className="px-2 py-1.5 text-right"><MoneyCell amount={s.projected} currency={ccy} compact /></td>
                            <td className="px-4 py-1.5 text-right"><MoneyCell amount={d} currency={ccy} compact signed tone={d < 0 ? 'outflow' : d > 0 ? 'inflow' : undefined} /></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
