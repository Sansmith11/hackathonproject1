import { useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, Download, FileSpreadsheet, UploadCloud } from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import { uploadsApi } from '@/api/endpoints/core';
import { useUploads } from '@/api/hooks';
import { Badge, Button, Card, CardHeader, PageHeader, Select } from '@/components/ui/primitives';
import { EmptyState, QueryBoundary } from '@/components/ui/feedback';
import { toast } from '@/components/ui/toast';
import { autoMapColumns, downloadText, issuesToCsv, parseFile, UPLOAD_FIELDS, validateRows, type ColumnMapping, type ParsedFile, type UploadFieldKey } from '@/lib/csv';
import { cn } from '@/lib/cn';
import { formatDateTime } from '@/lib/format';
import type { UploadResult } from '@/types/domain';

const STEPS = ['Select file', 'Map columns', 'Validate', 'Submit'];

export default function UploadPage() {
  const [step, setStep] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [parsed, setParsed] = useState<ParsedFile | null>(null);
  const [mapping, setMapping] = useState<ColumnMapping>({});
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<UploadResult | null>(null);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const history = useUploads();
  const qc = useQueryClient();

  const report = useMemo(() => (parsed ? validateRows(parsed.rows, mapping) : null), [parsed, mapping]);

  const load = async (f: File) => {
    setBusy(true);
    try {
      const p = await parseFile(f);
      if (p.rows.length === 0) {
        toast('That file has no data rows', 'error');
        return;
      }
      setFile(f);
      setParsed(p);
      setMapping(autoMapColumns(p.headers));
      setStep(1);
    } catch (e) {
      toast(`Could not read file: ${(e as Error).message}`, 'error');
    } finally {
      setBusy(false);
    }
  };

  const submit = async () => {
    if (!file || !report) return;
    setBusy(true);
    setProgress(10);
    const timer = setInterval(() => setProgress((p) => Math.min(90, p + 15)), 150);
    try {
      const res = await uploadsApi.submit(
        file,
        report.valid,
        report.rejected,
        report.issues.slice(0, 200),
      );
      setProgress(100);
      setResult(res);
      void qc.invalidateQueries({ queryKey: ['uploads'] });
      void qc.invalidateQueries({ queryKey: ['transactions'] });
      toast('Upload complete', 'success');
    } finally {
      clearInterval(timer);
      setBusy(false);
    }
  };

  const restart = () => {
    setStep(0);
    setFile(null);
    setParsed(null);
    setResult(null);
    setProgress(0);
  };

  return (
    <div>
      <PageHeader title="Upload transactions" description="CSV or Excel, validated in your browser before anything is sent" />
      <ol className="mb-4 flex flex-wrap gap-2" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s} className={cn('flex items-center gap-2 rounded-full border border-border px-3 py-1 text-xs', i === step && 'border-accent bg-accent/10 text-accent', i < step && 'text-muted-foreground')}>
            <span className="num font-semibold">{i + 1}</span> {s}
          </li>
        ))}
      </ol>

      <Card className="mb-6">
        {step === 0 && (
          <div className="p-6">
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files[0];
                if (f) void load(f);
              }}
              className="flex flex-col items-center gap-3 rounded-lg border-2 border-dashed border-border px-6 py-12 text-center"
            >
              <UploadCloud className="h-10 w-10 text-muted-foreground" />
              <p className="font-medium">Drop a CSV or XLSX file here</p>
              <input
                ref={input}
                type="file"
                accept=".csv,.xlsx,.xls"
                className="sr-only"
                aria-label="Choose file"
                data-testid="file-input"
                onChange={(e) => e.target.files?.[0] && void load(e.target.files[0])}
              />
              <Button variant="primary" onClick={() => input.current?.click()} disabled={busy}>
                <FileSpreadsheet className="h-4 w-4" /> Choose file
              </Button>
              <a className="text-xs text-accent underline" href="/sample-transactions.csv" download>
                Download sample CSV
              </a>
            </div>
          </div>
        )}

        {step === 1 && parsed && (
          <div className="p-4">
            <p className="mb-3 text-sm">
              <strong>{file?.name}</strong> · {parsed.rows.length.toLocaleString()} rows · map your columns to the data dictionary.
            </p>
            <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {UPLOAD_FIELDS.map((f) => (
                <div key={f.key}>
                  <label className="mb-1 block text-xs font-medium text-muted-foreground">
                    {f.label} {f.required && <span className="text-crit">*</span>}
                  </label>
                  <Select
                    className="w-full"
                    value={mapping[f.key as UploadFieldKey] ?? ''}
                    onChange={(e) => setMapping((m) => ({ ...m, [f.key]: e.target.value || undefined }))}
                  >
                    <option value="">— not mapped —</option>
                    {parsed.headers.map((h) => <option key={h}>{h}</option>)}
                  </Select>
                </div>
              ))}
            </div>
            <h3 className="mb-2 text-sm font-semibold">Preview (first 50 rows)</h3>
            <div className="max-h-72 overflow-auto rounded-md border border-border">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-muted text-left">
                  <tr>{parsed.headers.map((h) => <th key={h} className="whitespace-nowrap px-2 py-1.5 font-medium">{h}</th>)}</tr>
                </thead>
                <tbody>
                  {parsed.rows.slice(0, 50).map((r, i) => (
                    <tr key={i} className="border-t border-border">
                      {parsed.headers.map((h) => <td key={h} className="whitespace-nowrap px-2 py-1">{r[h]}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex justify-between">
              <Button onClick={restart}>Back</Button>
              <Button variant="primary" onClick={() => setStep(2)}>Validate</Button>
            </div>
          </div>
        )}

        {step === 2 && report && (
          <div className="p-4">
            {report.missingColumns.length > 0 ? (
              <div role="alert" className="mb-4 rounded-md border border-crit/40 bg-crit/10 p-3 text-sm text-crit">
                Missing required columns: <strong>{report.missingColumns.join(', ')}</strong>. Go back and map them.
              </div>
            ) : (
              <div className="mb-4 grid gap-3 sm:grid-cols-3">
                <Card className="p-3"><div className="text-xs text-muted-foreground">Rows</div><div className="num text-xl">{report.total.toLocaleString()}</div></Card>
                <Card className="p-3"><div className="text-xs text-muted-foreground">Valid</div><div className="num text-xl text-ok">{report.valid.toLocaleString()}</div></Card>
                <Card className="p-3"><div className="text-xs text-muted-foreground">Rejected</div><div className={cn('num text-xl', report.rejected && 'text-crit')}>{report.rejected.toLocaleString()}</div></Card>
              </div>
            )}
            {report.issues.length > 0 && (
              <>
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="text-sm font-semibold">Issues</h3>
                  <Button size="sm" onClick={() => downloadText('upload-errors.csv', issuesToCsv(report.issues))}>
                    <Download className="h-3.5 w-3.5" /> Error CSV
                  </Button>
                </div>
                <div className="max-h-56 overflow-auto rounded-md border border-border text-xs">
                  <table className="w-full">
                    <tbody>
                      {report.issues.slice(0, 100).map((i, idx) => (
                        <tr key={idx} className="border-t border-border first:border-0">
                          <td className="num px-2 py-1">Row {i.row}</td>
                          <td className="px-2 py-1 font-medium">{i.field}</td>
                          <td className="px-2 py-1 text-muted-foreground">{i.message}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
            <div className="mt-4 flex justify-between">
              <Button onClick={() => setStep(1)}>Back</Button>
              <Button variant="primary" disabled={report.missingColumns.length > 0 || report.valid === 0} onClick={() => setStep(3)}>
                Continue
              </Button>
            </div>
          </div>
        )}

        {step === 3 && report && (
          <div className="p-6 text-center">
            {!result ? (
              <>
                <p className="mb-4 text-sm">
                  Ready to submit <strong>{report.valid.toLocaleString()}</strong> valid rows
                  {report.rejected > 0 && <> ({report.rejected} rejected rows will be skipped)</>}.
                </p>
                {busy && (
                  <div className="mx-auto mb-4 h-2 max-w-sm overflow-hidden rounded-full bg-muted" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
                    <div className="h-full bg-accent transition-all" style={{ width: `${progress}%` }} />
                  </div>
                )}
                <div className="flex justify-center gap-2">
                  <Button onClick={() => setStep(2)} disabled={busy}>Back</Button>
                  <Button variant="primary" onClick={() => void submit()} disabled={busy}>
                    {busy ? 'Uploading…' : 'Submit upload'}
                  </Button>
                </div>
              </>
            ) : (
              <div data-testid="upload-success">
                <CheckCircle2 className="mx-auto h-10 w-10 text-ok" />
                <h2 className="mt-2 text-lg font-semibold">Upload complete</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  {result.rowsParsed.toLocaleString()} rows parsed · {result.rowsRejected.toLocaleString()} rejected · id {result.uploadId}
                </p>
                <Button className="mt-4" onClick={restart}>Upload another file</Button>
              </div>
            )}
          </div>
        )}
      </Card>

      <Card>
        <CardHeader title="Upload history" />
        <QueryBoundary query={history} isEmpty={(d) => d.length === 0} empty={<EmptyState title="No uploads yet" hint="Drop a CSV above to get started." />}>
          {(rows) => (
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-muted-foreground">
                <tr>
                  {['File', 'Uploaded', 'By', 'Parsed', 'Rejected'].map((h) => <th key={h} className="px-4 py-2 font-medium">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {rows.map((u) => (
                  <tr key={u.uploadId} className="border-t border-border">
                    <td className="px-4 py-2">{u.fileName}</td>
                    <td className="px-4 py-2">{formatDateTime(u.uploadedAt)}</td>
                    <td className="px-4 py-2">{u.uploadedBy}</td>
                    <td className="num px-4 py-2">{u.rowsParsed.toLocaleString()}</td>
                    <td className="px-4 py-2">{u.rowsRejected ? <Badge tone="warn">{u.rowsRejected}</Badge> : 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </QueryBoundary>
      </Card>
    </div>
  );
}
