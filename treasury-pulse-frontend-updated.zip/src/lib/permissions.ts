import type { Region, Role, User } from '@/types/domain';

export type Action =
  | 'view'
  | 'region_view'
  | 'upload'
  | 'what_if'
  | 'reports'
  | 'ack_alerts'
  | 'chat'
  | 'admin_thresholds'
  | 'admin_schedules'
  | 'admin_users';

const MATRIX: Record<Action, Role[]> = {
  view: ['VIEWER', 'ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  region_view: ['TREASURY_MANAGER', 'ADMIN'],
  upload: ['ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  what_if: ['ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  reports: ['ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  ack_alerts: ['ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  chat: ['VIEWER', 'ANALYST', 'TREASURY_MANAGER', 'ADMIN'],
  admin_thresholds: ['ADMIN'],
  admin_schedules: ['ADMIN'],
  admin_users: ['ADMIN'],
};

export interface Scope {
  entityCode?: string;
  region?: Region;
}

/** Does the user's data-isolation scope include this entity/region? */
export function inScope(
  user: User,
  scope: Scope | undefined,
  entityRegion?: (code: string) => Region | undefined,
): boolean {
  if (user.role === 'ADMIN') return true;
  if (!scope) return true;
  if (scope.entityCode) {
    if (user.entityCodes.includes(scope.entityCode)) return true;
    const r = entityRegion?.(scope.entityCode);
    return !!r && user.role === 'TREASURY_MANAGER' && user.regions.includes(r);
  }
  if (scope.region) return user.role === 'TREASURY_MANAGER' && user.regions.includes(scope.region);
  return true;
}

export function can(
  user: User | null | undefined,
  action: Action,
  scope?: Scope,
  entityRegion?: (code: string) => Region | undefined,
): boolean {
  if (!user) return false;
  if (!MATRIX[action].includes(user.role)) return false;
  return inScope(user, scope, entityRegion);
}

export function whyDenied(action: Action): string {
  const roles = MATRIX[action].map((r) => r.replace('_', ' ').toLowerCase()).join(', ');
  return `Requires one of these roles: ${roles}.`;
}

export const ROLE_LABEL: Record<Role, string> = {
  VIEWER: 'Viewer',
  ANALYST: 'Analyst',
  TREASURY_MANAGER: 'Treasury Manager',
  ADMIN: 'Admin',
};
