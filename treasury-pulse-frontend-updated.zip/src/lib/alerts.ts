import type { Severity } from '@/types/domain';

export interface SeverityBands {
  /** headroom % below which severity is CRITICAL (default 5) */
  critical: number;
  /** headroom % below which severity is WARNING (default 10) */
  warning: number;
}

export const DEFAULT_BANDS: SeverityBands = { critical: 5, warning: 10 };

export function classifySeverity(
  projected: number,
  threshold: number,
  bands: SeverityBands = DEFAULT_BANDS,
): Severity {
  if (projected < threshold || projected < 0) return 'EMERGENCY';
  const headroomPct = threshold === 0 ? 100 : ((projected - threshold) / threshold) * 100;
  if (headroomPct < bands.critical) return 'CRITICAL';
  if (headroomPct < bands.warning) return 'WARNING';
  return 'OK';
}

export const SEVERITY_RANK: Record<Severity, number> = {
  OK: 0,
  WARNING: 1,
  CRITICAL: 2,
  EMERGENCY: 3,
};

export function worstSeverity(list: Severity[]): Severity {
  return list.reduce<Severity>((w, s) => (SEVERITY_RANK[s] > SEVERITY_RANK[w] ? s : w), 'OK');
}

export const SEVERITY_META: Record<
  Severity,
  { label: string; band: 'ok' | 'warn' | 'crit'; cssVar: string; hex: string }
> = {
  OK: { label: 'OK', band: 'ok', cssVar: 'var(--band-ok)', hex: '#16a34a' },
  WARNING: { label: 'Warning', band: 'warn', cssVar: 'var(--band-warn)', hex: '#d97706' },
  CRITICAL: { label: 'Critical', band: 'crit', cssVar: 'var(--band-crit)', hex: '#dc2626' },
  EMERGENCY: { label: 'Emergency', band: 'crit', cssVar: 'var(--band-crit)', hex: '#b91c1c' },
};
