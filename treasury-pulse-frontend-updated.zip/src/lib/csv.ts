import Papa from 'papaparse';
import * as XLSX from 'xlsx';

/** Target fields of the data dictionary that an upload can populate. */
export const UPLOAD_FIELDS = [
  { key: 'transactionId', label: 'Transaction ID', required: true },
  { key: 'transactionDate', label: 'Transaction date', required: true },
  { key: 'entityCode', label: 'Entity code', required: true },
  { key: 'currency', label: 'Currency', required: true },
  { key: 'originalAmount', label: 'Amount', required: true },
  { key: 'direction', label: 'Direction', required: true },
  { key: 'category', label: 'Category', required: false },
  { key: 'productType', label: 'Product type', required: false },
  { key: 'counterparty', label: 'Counterparty', required: false },
  { key: 'settlementStatus', label: 'Settlement status', required: false },
  { key: 'counterpartyRiskRating', label: 'Counterparty rating', required: false },
  { key: 'dueDate', label: 'Due date', required: false },
] as const;

export type UploadFieldKey = (typeof UPLOAD_FIELDS)[number]['key'];
export type ColumnMapping = Partial<Record<UploadFieldKey, string>>;

const KNOWN_CURRENCIES = new Set([
  'EUR', 'USD', 'GBP', 'JPY', 'SGD', 'HKD', 'CNY', 'INR', 'AED', 'CHF', 'CAD', 'AUD',
]);

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

const ALIASES: Record<UploadFieldKey, string[]> = {
  transactionId: ['transactionid', 'txnid', 'id', 'reference'],
  transactionDate: ['transactiondate', 'date', 'txndate', 'valuedate', 'bookingdate'],
  entityCode: ['entitycode', 'entity', 'legalentity'],
  currency: ['currency', 'ccy', 'currencycode'],
  originalAmount: ['originalamount', 'amount', 'amt', 'value'],
  direction: ['direction', 'type', 'flow', 'drcr'],
  category: ['category', 'cat'],
  productType: ['producttype', 'product'],
  counterparty: ['counterparty', 'cpty', 'payee', 'payer'],
  settlementStatus: ['settlementstatus', 'status'],
  counterpartyRiskRating: ['counterpartyriskrating', 'rating', 'riskrating'],
  dueDate: ['duedate', 'due'],
};

export function autoMapColumns(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {};
  const used = new Set<string>();
  for (const f of UPLOAD_FIELDS) {
    const hit = headers.find((h) => !used.has(h) && ALIASES[f.key].includes(norm(h)));
    if (hit) {
      mapping[f.key] = hit;
      used.add(hit);
    }
  }
  return mapping;
}

export interface ParsedFile {
  headers: string[];
  rows: Record<string, string>[];
}

export async function parseFile(file: File): Promise<ParsedFile> {
  if (/\.xlsx?$/i.test(file.name)) {
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: false });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, string>>(sheet, { raw: false, defval: '' });
    return { headers: rows.length ? Object.keys(rows[0]) : [], rows };
  }
  return new Promise((resolve, reject) => {
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (r) => resolve({ headers: r.meta.fields ?? [], rows: r.data }),
      error: reject,
    });
  });
}

export interface ValidationIssue {
  row: number; // 1-based data row
  field: string;
  message: string;
}

export interface ValidationReport {
  total: number;
  valid: number;
  rejected: number;
  missingColumns: string[];
  issues: ValidationIssue[];
}

const isDate = (v: string) => /^\d{4}-\d{2}-\d{2}/.test(v) && !Number.isNaN(Date.parse(v));

export function validateRows(
  rows: Record<string, string>[],
  mapping: ColumnMapping,
): ValidationReport {
  const missingColumns = UPLOAD_FIELDS.filter((f) => f.required && !mapping[f.key]).map(
    (f) => f.label,
  );
  const issues: ValidationIssue[] = [];
  const bad = new Set<number>();
  if (missingColumns.length === 0) {
    rows.forEach((r, i) => {
      const get = (k: UploadFieldKey) => (r[mapping[k] ?? ''] ?? '').toString().trim();
      const add = (field: string, message: string) => {
        issues.push({ row: i + 1, field, message });
        bad.add(i);
      };
      if (!get('transactionId')) add('transactionId', 'Missing transaction ID');
      if (!isDate(get('transactionDate'))) add('transactionDate', 'Invalid date (expected YYYY-MM-DD)');
      if (!get('entityCode')) add('entityCode', 'Missing entity code');
      if (!KNOWN_CURRENCIES.has(get('currency').toUpperCase()))
        add('currency', `Unknown currency "${get('currency')}"`);
      const amt = get('originalAmount');
      if (amt === '' || Number.isNaN(Number(amt.replace(/,/g, ''))))
        add('originalAmount', `Non-numeric amount "${amt}"`);
      if (!['INFLOW', 'OUTFLOW'].includes(get('direction').toUpperCase()))
        add('direction', 'Direction must be INFLOW or OUTFLOW');
    });
  }
  return {
    total: rows.length,
    valid: missingColumns.length ? 0 : rows.length - bad.size,
    rejected: missingColumns.length ? rows.length : bad.size,
    missingColumns,
    issues,
  };
}

export function issuesToCsv(issues: ValidationIssue[]): string {
  return Papa.unparse(issues.map((i) => ({ row: i.row, field: i.field, message: i.message })));
}

export function downloadText(filename: string, text: string, mime = 'text/csv'): void {
  downloadBlob(filename, new Blob([text], { type: mime }));
}

export function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
