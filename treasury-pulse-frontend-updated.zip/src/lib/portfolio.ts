import type { DailyPosition, GapRow, Severity } from '@/types/domain';
import { worstSeverity } from './alerts';
import { deployableSurplus } from './gap';

/** units of reporting currency per 1 unit of `currency` */
export function toReporting(amount: number, currency: string, rates: Record<string, number> | undefined): number {
  if (!rates) return amount;
  return amount * (rates[currency] ?? 1);
}

export interface PairSummary {
  entityCode: string;
  currency: string;
  current: number;
  threshold: number | null;
  worst: GapRow | null;
  severity: Severity;
  deployable: number;
  series: number[];
}

export function summarizePairs(latest: DailyPosition[], gaps: GapRow[]): PairSummary[] {
  const byPair = new Map<string, DailyPosition[]>();
  for (const p of latest) {
    const k = `${p.entityCode}|${p.currency}`;
    byPair.set(k, [...(byPair.get(k) ?? []), p]);
  }
  const gapBy = new Map<string, GapRow[]>();
  for (const g of gaps) {
    const k = `${g.entityCode}|${g.currency}`;
    gapBy.set(k, [...(gapBy.get(k) ?? []), g]);
  }
  return [...byPair].map(([k, rows]) => {
    const sorted = [...rows].sort((a, b) => (a.date < b.date ? -1 : 1));
    const gs = gapBy.get(k) ?? [];
    const worst = gs.length ? gs.reduce((a, r) => (r.gap < a.gap ? r : a), gs[0]) : null;
    const minProjected = gs.length ? Math.min(...gs.map((g) => g.projected)) : 0;
    return {
      entityCode: sorted[0].entityCode,
      currency: sorted[0].currency,
      current: sorted[sorted.length - 1].closingBalance,
      threshold: worst?.threshold ?? null,
      worst,
      severity: worstSeverity(gs.map((g) => g.severity)),
      deployable: worst ? deployableSurplus(minProjected, worst.threshold) : 0,
      series: sorted.map((r) => r.closingBalance),
    };
  });
}
