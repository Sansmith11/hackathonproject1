import type { Region, Threshold } from '@/types/domain';

/** P = B_prev + (In - Out) */
export function projectedBalance(prevBalance: number, inflows: number, outflows: number): number {
  return prevBalance + (inflows - outflows);
}

/** G = P - T */
export function gapAmount(projected: number, threshold: number): number {
  return projected - threshold;
}

export function headroomPct(projected: number, threshold: number): number {
  if (threshold === 0) return 100;
  return ((projected - threshold) / threshold) * 100;
}

/** Surplus: projected > threshold + 20% */
export function isSurplus(projected: number, threshold: number): boolean {
  return projected > threshold * 1.2;
}

export function deployableSurplus(projected: number, threshold: number): number {
  return Math.max(0, projected - threshold * 1.2);
}

export interface ResolvedThreshold {
  value: number;
  source: 'ENTITY' | 'REGION' | 'CURRENCY';
  rule: Threshold;
}

/**
 * Resolution order: ENTITY+CURRENCY -> REGION+CURRENCY -> CURRENCY default.
 * PERCENT mode = percent of the 30-day average closing balance.
 */
export function resolveThreshold(
  thresholds: Threshold[],
  entityCode: string,
  region: Region,
  currency: string,
  avgClosing30d: number,
): ResolvedThreshold | null {
  const pick =
    thresholds.find((t) => t.scope === 'ENTITY' && t.entityCode === entityCode && t.currency === currency) ??
    thresholds.find((t) => t.scope === 'REGION' && t.region === region && t.currency === currency) ??
    thresholds.find((t) => t.scope === 'CURRENCY' && t.currency === currency);
  if (!pick) return null;
  const value = pick.mode === 'PERCENT' ? (pick.value / 100) * avgClosing30d : pick.value;
  return { value, source: pick.scope, rule: pick };
}

export const DEFAULT_CURRENCY_THRESHOLDS: Record<string, number> = {
  EUR: 50_000,
  USD: 60_000,
  JPY: 5_000_000,
  GBP: 40_000,
};
