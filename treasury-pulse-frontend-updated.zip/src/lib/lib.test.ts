import { describe, expect, it } from 'vitest';
import { classifySeverity } from './alerts';
import { deployableSurplus, gapAmount, headroomPct, isSurplus, projectedBalance, resolveThreshold } from './gap';
import { can } from './permissions';
import { autoMapColumns, validateRows } from './csv';
import { formatMoney } from './format';
import type { Role, Threshold, User } from '@/types/domain';

describe('gap', () => {
  it('computes P, G, headroom and surplus', () => {
    expect(projectedBalance(100, 30, 20)).toBe(110);
    expect(gapAmount(110, 100)).toBe(10);
    expect(headroomPct(110, 100)).toBeCloseTo(10);
    expect(isSurplus(121, 100)).toBe(true);
    expect(isSurplus(120, 100)).toBe(false);
    expect(deployableSurplus(150, 100)).toBe(30);
  });

  it('resolves thresholds ENTITY > REGION > CURRENCY', () => {
    const th: Threshold[] = [
      { id: '1', scope: 'CURRENCY', currency: 'EUR', mode: 'ABSOLUTE', value: 50_000 },
      { id: '2', scope: 'REGION', region: 'EMEA', currency: 'EUR', mode: 'ABSOLUTE', value: 70_000 },
      { id: '3', scope: 'ENTITY', entityCode: 'PARI', currency: 'EUR', mode: 'PERCENT', value: 10 },
    ];
    expect(resolveThreshold(th, 'PARI', 'EMEA', 'EUR', 1_000_000)?.value).toBe(100_000);
    expect(resolveThreshold(th, 'FRAN', 'EMEA', 'EUR', 1)?.value).toBe(70_000);
    expect(resolveThreshold(th, 'NEWY', 'NAMER', 'EUR', 1)?.value).toBe(50_000);
    expect(resolveThreshold(th, 'PARI', 'EMEA', 'CHF', 1)).toBeNull();
  });
});

describe('severity', () => {
  it('classifies by headroom', () => {
    expect(classifySeverity(90, 100)).toBe('EMERGENCY');
    expect(classifySeverity(-5, -10)).toBe('EMERGENCY');
    expect(classifySeverity(100, 100)).toBe('CRITICAL');
    expect(classifySeverity(104.9, 100)).toBe('CRITICAL');
    expect(classifySeverity(105, 100)).toBe('WARNING');
    expect(classifySeverity(109.9, 100)).toBe('WARNING');
    expect(classifySeverity(110, 100)).toBe('OK');
  });
});

describe('permissions matrix', () => {
  const mk = (role: Role): User => ({ id: 'x', name: 'x', email: 'x', role, entityCodes: ['PARI'], regions: ['EMEA'] });
  it('enforces capabilities', () => {
    expect(can(mk('VIEWER'), 'view')).toBe(true);
    expect(can(mk('VIEWER'), 'upload')).toBe(false);
    expect(can(mk('VIEWER'), 'chat')).toBe(true);
    expect(can(mk('ANALYST'), 'what_if')).toBe(true);
    expect(can(mk('ANALYST'), 'region_view')).toBe(false);
    expect(can(mk('TREASURY_MANAGER'), 'region_view')).toBe(true);
    expect(can(mk('TREASURY_MANAGER'), 'admin_users')).toBe(false);
    expect(can(mk('ADMIN'), 'admin_thresholds')).toBe(true);
    expect(can(mk('ADMIN'), 'view', { entityCode: 'TOKY' })).toBe(true);
  });
  it('enforces entity scope', () => {
    expect(can(mk('ANALYST'), 'view', { entityCode: 'PARI' })).toBe(true);
    expect(can(mk('ANALYST'), 'view', { entityCode: 'TOKY' })).toBe(false);
  });
});

describe('csv helpers', () => {
  it('auto-maps headers and validates rows', () => {
    const m = autoMapColumns(['Txn ID', 'Date', 'Entity', 'CCY', 'Amount', 'Direction']);
    expect(m.transactionId).toBe('Txn ID');
    expect(m.originalAmount).toBe('Amount');
    const rep = validateRows(
      [
        { 'Txn ID': 'a', Date: '2026-01-01', Entity: 'PARI', CCY: 'EUR', Amount: '10', Direction: 'INFLOW' },
        { 'Txn ID': 'b', Date: 'nope', Entity: 'PARI', CCY: 'XXX', Amount: 'abc', Direction: 'IN' },
      ],
      m,
    );
    expect(rep.valid).toBe(1);
    expect(rep.rejected).toBe(1);
    expect(rep.issues.length).toBe(4);
  });
});

describe('format', () => {
  it('formats money with code', () => {
    expect(formatMoney(1234.5, 'EUR')).toContain('EUR');
    expect(formatMoney(5_000_000, 'JPY')).not.toContain('.');
  });
});
