import { format, parseISO } from 'date-fns';

export function formatMoney(amount: number, currency: string, opts?: { compact?: boolean }): string {
  const zeroDecimal = currency === 'JPY';
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency,
      currencyDisplay: 'code',
      notation: opts?.compact ? 'compact' : 'standard',
      maximumFractionDigits: opts?.compact ? 1 : zeroDecimal ? 0 : 2,
      minimumFractionDigits: opts?.compact ? 0 : zeroDecimal ? 0 : 2,
    })
      .format(amount)
      .replace(/\p{Zs}/gu, ' ');
  } catch {
    return `${currency} ${amount.toFixed(2)}`;
  }
}

export function formatNumber(n: number, digits = 0): string {
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(n);
}

export function formatCompact(n: number): string {
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(
    n,
  );
}

export function formatPct(n: number, digits = 1): string {
  return `${n.toFixed(digits)}%`;
}

export function formatDate(iso: string, pattern = 'dd MMM yyyy'): string {
  try {
    return format(parseISO(iso), pattern);
  } catch {
    return iso;
  }
}

export function formatDateTime(iso: string): string {
  return formatDate(iso, 'dd MMM yyyy, HH:mm');
}

export function maskAccount(acc: string): string {
  return `****${acc.slice(-4)}`;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

