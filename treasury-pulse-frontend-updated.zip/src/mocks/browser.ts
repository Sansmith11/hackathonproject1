import { getResponse } from 'msw';
import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

export const worker = setupWorker(...handlers);

const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api';

/** Routes API calls through the MSW handlers by wrapping window.fetch (no service worker needed). */
function installFetchShim(): void {
  const realFetch = window.fetch.bind(window);
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const req = new Request(input, init);
    const url = new URL(req.url, window.location.origin);
    if (url.origin === window.location.origin && url.pathname.startsWith(BASE)) {
      const res = await getResponse(handlers, req);
      if (res) return res;
    }
    return realFetch(input, init);
  };
}

export async function startMocks(): Promise<void> {
  if ('serviceWorker' in navigator) {
    try {
      await worker.start({ onUnhandledRequest: 'bypass', quiet: true });
      return;
    } catch {
      /* fall through to the fetch shim */
    }
  }
  installFetchShim();
}
