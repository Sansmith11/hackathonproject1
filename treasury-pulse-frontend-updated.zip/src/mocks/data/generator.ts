import { addDays, format, getDay, parseISO } from 'date-fns';
import { DEFAULT_CURRENCY_THRESHOLDS } from '@/lib/gap';
import type {
  DailyPosition,
  Direction,
  Entity,
  RiskRating,
  Transaction,
} from '@/types/domain';

/** The demo "today". Fixed so the seeded story (shortfalls etc.) is stable. */
export const TODAY = '2026-10-10';

export const FX_TO_USD: Record<string, number> = {
  USD: 1,
  EUR: 1.08,
  GBP: 1.27,
  JPY: 0.0067,
  SGD: 0.74,
  HKD: 0.128,
  CNY: 0.138,
  INR: 0.012,
  AED: 0.272,
  CHF: 1.13,
  CAD: 0.73,
};

export const ENTITIES: Entity[] = [
  { code: 'PARI', name: 'BNPPARIBAS_PARIS', region: 'EMEA', country: 'France', city: 'Paris', baseCurrency: 'EUR' },
  { code: 'LOND', name: 'BNPPARIBAS_LONDON', region: 'EMEA', country: 'United Kingdom', city: 'London', baseCurrency: 'GBP' },
  { code: 'FRAN', name: 'BNPPARIBAS_FRANKFURT', region: 'EMEA', country: 'Germany', city: 'Frankfurt', baseCurrency: 'EUR' },
  { code: 'SING', name: 'BNPPARIBAS_SINGAPORE', region: 'APAC', country: 'Singapore', city: 'Singapore', baseCurrency: 'SGD' },
  { code: 'TOKY', name: 'BNPPARIBAS_TOKYO', region: 'APAC', country: 'Japan', city: 'Tokyo', baseCurrency: 'JPY' },
  { code: 'MUMB', name: 'BNPPARIBAS_MUMBAI', region: 'APAC', country: 'India', city: 'Mumbai', baseCurrency: 'INR' },
  { code: 'NEWY', name: 'BNPPARIBAS_NEWYORK', region: 'NAMER', country: 'United States', city: 'New York', baseCurrency: 'USD' },
  { code: 'TORO', name: 'BNPPARIBAS_TORONTO', region: 'NAMER', country: 'Canada', city: 'Toronto', baseCurrency: 'CAD' },
];

const ENTITY_CCYS: Record<string, string[]> = {
  PARI: ['EUR', 'USD', 'GBP'],
  LOND: ['GBP', 'EUR', 'USD'],
  FRAN: ['EUR', 'USD', 'CHF'],
  SING: ['SGD', 'USD', 'HKD'],
  TOKY: ['JPY', 'USD', 'CNY'],
  MUMB: ['INR', 'USD', 'AED'],
  NEWY: ['USD', 'EUR', 'CAD'],
  TORO: ['CAD', 'USD', 'GBP'],
};

export const CURRENCIES = Object.keys(FX_TO_USD);

export function pairKey(entityCode: string, currency: string): string {
  return `${entityCode}|${currency}`;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export interface Pair {
  entityCode: string;
  currency: string;
  /** Scale unit in currency units; flows are generated relative to it. */
  unit: number;
}

export interface Dataset {
  entities: Entity[];
  pairs: Pair[];
  transactions: Transaction[];
  positions: Map<string, DailyPosition[]>;
  counterparties: { name: string; rating: RiskRating }[];
  dates: string[];
}

let cache: Dataset | null = null;

const CATEGORIES_IN = ['CUSTOMER_RECEIPTS', 'INTEREST_INCOME', 'FX_SETTLEMENT', 'INTERCOMPANY'];
const CATEGORIES_OUT = ['SUPPLIER_PAYMENT', 'OPEX', 'CAPEX', 'INTERCOMPANY', 'FX_SETTLEMENT'];
const PRODUCTS = ['WIRE', 'ACH', 'SEPA', 'FX_SPOT', 'LOAN', 'DEPOSIT', 'TRADE_FINANCE'];
const METHODS = ['SWIFT', 'SEPA', 'RTGS', 'ACH', 'BOOK_TRANSFER'];
const DEPARTMENTS = ['TREASURY', 'PROCUREMENT', 'HR', 'TAX', 'OPERATIONS', 'SALES'];
const ACCOUNT_TYPES = ['OPERATING', 'COLLECTION', 'PAYROLL', 'TAX'];

export function getDataset(): Dataset {
  if (cache) return cache;
  const rng = mulberry32(20261010);
  const gauss = () => {
    const u = Math.max(rng(), 1e-9);
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng());
  };
  const pick = <T,>(arr: T[]): T => arr[Math.floor(rng() * arr.length)];

  const counterparties = Array.from({ length: 48 }, (_, i) => {
    const r = rng();
    const rating: RiskRating = r < 0.4 ? 'A' : r < 0.7 ? 'B' : r < 0.9 ? 'C' : 'D';
    return { name: `Counterparty ${String(i + 1).padStart(3, '0')}`, rating };
  });

  const dates: string[] = [];
  const today = parseISO(TODAY);
  for (let i = -365; i <= 0; i++) dates.push(format(addDays(today, i), 'yyyy-MM-dd'));
  const maturity = format(addDays(today, 365 * 2), 'yyyy-MM-dd');

  const pairs: Pair[] = [];
  const transactions: Transaction[] = [];
  const positions = new Map<string, DailyPosition[]>();
  let txnSeq = 1;
  const SURPLUS_PAIRS = new Set([pairKey('NEWY', 'USD'), pairKey('TOKY', 'JPY'), pairKey('SING', 'SGD')]);

  for (const entity of ENTITIES) {
    for (const currency of ENTITY_CCYS[entity.code]) {
      const threshold = DEFAULT_CURRENCY_THRESHOLDS[currency];
      const unit = threshold ?? 50_000 / FX_TO_USD[currency];
      pairs.push({ entityCode: entity.code, currency, unit });
      const accountNumber = String(Math.floor(rng() * 9e11) + 1e11);
      const daily: { inflows: number; outflows: number }[] = [];

      for (const date of dates) {
        const dt = parseISO(date);
        const dow = getDay(dt);
        const dom = dt.getDate();
        const month = dt.getMonth();
        let inflows = 0;
        let outflows = 0;

        const push = (
          direction: Direction,
          amount: number,
          category: string,
          opts: Partial<Transaction> = {},
        ) => {
          const cp = pick(counterparties);
          const crossBorder = currency !== entity.baseCurrency;
          const amt = Math.round(amount * 100) / 100;
          const recent = date >= format(addDays(today, -2), 'yyyy-MM-dd');
          transactions.push({
            transactionId: `TXN${String(txnSeq++).padStart(7, '0')}`,
            transactionDate: date,
            dueDate: format(addDays(dt, 2 + Math.floor(rng() * 10)), 'yyyy-MM-dd'),
            entityCode: entity.code,
            region: entity.region,
            country: entity.country,
            city: entity.city,
            accountType: pick(ACCOUNT_TYPES),
            accountNumber,
            currency,
            originalAmount: amt,
            direction,
            productType: pick(PRODUCTS),
            category,
            frequency: 'ONE_OFF',
            isRecurring: false,
            paymentMethod: pick(METHODS),
            counterparty: cp.name,
            settlementStatus: recent && rng() < 0.5 ? 'PENDING' : 'SETTLED',
            department: pick(DEPARTMENTS),
            counterpartyRiskRating: cp.rating,
            originCurrency: direction === 'INFLOW' && crossBorder ? entity.baseCurrency : currency,
            destinationCurrency: direction === 'OUTFLOW' && crossBorder ? entity.baseCurrency : currency,
            isCrossBorder: crossBorder,
            fxRate: FX_TO_USD[currency],
            maturityDate: null,
            ...opts,
          });
          if (direction === 'INFLOW') inflows += amt;
          else outflows += amt;
        };

        const n = 4 + Math.floor(rng() * 4);
        for (let k = 0; k < n; k++) {
          const amt = unit * Math.min(0.5, Math.max(0.003, 0.04 * Math.exp(0.9 * gauss())));
          const dir: Direction = rng() < 0.5 ? 'INFLOW' : 'OUTFLOW';
          push(dir, amt, dir === 'INFLOW' ? pick(CATEGORIES_IN) : pick(CATEGORIES_OUT));
        }
        const rec = { frequency: 'MONTHLY', isRecurring: true };
        if (dom === 25) push('OUTFLOW', unit * 0.35, 'PAYROLL', { ...rec, department: 'HR', accountType: 'PAYROLL' });
        if (dom === 15 && month % 3 === 0)
          push('OUTFLOW', unit * 0.5, 'TAX', { frequency: 'QUARTERLY', isRecurring: true, department: 'TAX', accountType: 'TAX' });
        if (dow === 5)
          push('OUTFLOW', unit * 0.2, 'SUPPLIER_PAYMENT', { frequency: 'WEEKLY', isRecurring: true, department: 'PROCUREMENT' });
        if (dow === 1)
          push('INFLOW', unit * 0.28, 'CUSTOMER_RECEIPTS', { frequency: 'WEEKLY', isRecurring: true, accountType: 'COLLECTION' });
        if (dom === 28)
          push('INFLOW', unit * 0.5, 'CUSTOMER_RECEIPTS', { ...rec, accountType: 'COLLECTION' });
        if (dom === 5)
          push('OUTFLOW', unit * 0.4, 'LOAN_REPAYMENT', { ...rec, productType: 'LOAN', maturityDate: maturity, department: 'TREASURY' });
        daily.push({ inflows, outflows });
      }

      // Choose the opening balance so the 12-month minimum sits comfortably above threshold.
      let cum = 0;
      let minCum = 0;
      for (const d of daily) {
        cum += d.inflows - d.outflows;
        minCum = Math.min(minCum, cum);
      }
      const keepMin = SURPLUS_PAIRS.has(pairKey(entity.code, currency)) ? 3.6 : 1.9;
      let balance = Math.max(0, keepMin * (threshold ?? unit) - minCum);
      const rows: DailyPosition[] = [];
      dates.forEach((date, i) => {
        const opening = balance;
        balance = opening + daily[i].inflows - daily[i].outflows;
        rows.push({
          date,
          entityCode: entity.code,
          currency,
          openingBalance: round2(opening),
          inflows: round2(daily[i].inflows),
          outflows: round2(daily[i].outflows),
          closingBalance: round2(balance),
        });
      });
      positions.set(pairKey(entity.code, currency), rows);
    }
  }

  transactions.sort((a, b) =>
    a.transactionDate === b.transactionDate
      ? a.transactionId < b.transactionId
        ? 1
        : -1
      : a.transactionDate < b.transactionDate
        ? 1
        : -1,
  );

  cache = { entities: ENTITIES, pairs, transactions, positions, counterparties, dates };
  return cache;
}

export const round2 = (n: number): number => Math.round(n * 100) / 100;

export function getEntity(code: string): Entity | undefined {
  return ENTITIES.find((e) => e.code === code);
}
