import { formatMoney } from '@/lib/format';
import { allGapRows, liveAlerts } from './forecast';
import { TODAY, getDataset, pairKey } from './generator';

export interface ReportRow {
  section: string;
  entity: string;
  currency: string;
  a: string;
  b: string;
  c: string;
}

export function reportLines(type: 'SOD' | 'EOD', allowed: Set<string>, entity?: string | null): string[] {
  const ds = getDataset();
  const pairs = ds.pairs.filter((p) => allowed.has(p.entityCode) && (!entity || p.entityCode === entity));
  const lines: string[] = [];
  lines.push(`Treasury Pulse - ${type === 'SOD' ? 'Start-of-Day' : 'End-of-Day'} Liquidity Report`);
  lines.push(`As of ${TODAY}   Scope: ${entity ?? 'all entities in scope'}`);
  lines.push('');
  lines.push(type === 'SOD' ? 'OPENING POSITIONS' : 'POSITION SUMMARY');
  for (const p of pairs) {
    const rows = ds.positions.get(pairKey(p.entityCode, p.currency))!;
    const last = rows[rows.length - 1];
    lines.push(
      `  ${p.entityCode} ${p.currency}  ${type === 'SOD' ? 'opening' : 'closing'} ${formatMoney(
        type === 'SOD' ? last.openingBalance : last.closingBalance,
        p.currency,
      )}   in ${formatMoney(last.inflows, p.currency)}  out ${formatMoney(last.outflows, p.currency)}`,
    );
  }
  lines.push('');
  lines.push(type === 'SOD' ? 'FORECAST OUTLOOK (NEXT 48H)' : 'GAP STATUS');
  const gaps = allGapRows(new Set(pairs.map((p) => p.entityCode)));
  const byPair = new Map<string, typeof gaps>();
  for (const g of gaps) {
    const k = pairKey(g.entityCode, g.currency);
    byPair.set(k, [...(byPair.get(k) ?? []), g]);
  }
  for (const [k, rows] of byPair) {
    const [e, c] = k.split('|');
    if (entity && e !== entity) continue;
    const slice = type === 'SOD' ? rows.slice(0, 2) : rows;
    const worst = slice.reduce((a, r) => (r.gap < a.gap ? r : a), slice[0]);
    lines.push(`  ${e} ${c}  min projected ${formatMoney(worst.projected, c)} on ${worst.date}  gap ${formatMoney(worst.gap, c)}  [${worst.severity}]`);
  }
  lines.push('');
  lines.push(type === 'SOD' ? 'OVERNIGHT ALERTS' : 'ALERTS TRIGGERED');
  const alerts = liveAlerts(new Set(pairs.map((p) => p.entityCode))).filter((a) => !entity || a.entityCode === entity);
  if (alerts.length === 0) lines.push('  None');
  for (const a of alerts) {
    lines.push(`  [${a.severity}] ${a.entityCode} ${a.currency} for ${a.forDate}: gap ${formatMoney(a.gap, a.currency)} (${a.status})`);
  }
  return lines;
}

export function reportCsv(lines: string[]): string {
  return ['line', ...lines.map((l) => `"${l.replace(/"/g, '""')}"`)].join('\n');
}

/** Minimal single-font text PDF writer (no external deps). */
export function textToPdf(lines: string[]): Uint8Array {
  const perPage = 48;
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += perPage) pages.push(lines.slice(i, i + perPage));
  if (pages.length === 0) pages.push(['']);
  const esc = (s: string) => s.replace(/[^\x20-\x7e]/g, '?').replace(/([\\()])/g, '\\$1');

  const objs: string[] = [];
  const pageIds = pages.map((_, i) => 4 + i * 2);
  objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
  objs[2] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${pages.length} >>`;
  objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>';
  pages.forEach((pl, i) => {
    const pid = 4 + i * 2;
    const cid = pid + 1;
    const stream =
      'BT /F1 9 Tf 12 TL 40 800 Td\n' + pl.map((l) => `(${esc(l)}) Tj T*`).join('\n') + '\nET';
    objs[pid] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents ${cid} 0 R >>`;
    objs[cid] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  });

  let out = '%PDF-1.4\n';
  const offsets: number[] = [];
  for (let i = 1; i < objs.length; i++) {
    offsets[i] = out.length;
    out += `${i} 0 obj\n${objs[i]}\nendobj\n`;
  }
  const xref = out.length;
  out += `xref\n0 ${objs.length}\n0000000000 65535 f \n`;
  for (let i = 1; i < objs.length; i++) out += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new TextEncoder().encode(out);
}
