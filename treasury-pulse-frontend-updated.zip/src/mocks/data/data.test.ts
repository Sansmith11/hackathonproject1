import { describe, expect, it } from 'vitest';
import { getDataset } from './generator';
import { buildForecast, gapRowsFor, liveAlerts, runScenario } from './forecast';
import {
  alertSchema,
  dailyPositionSchema,
  entitySchema,
  forecastSchema,
  gapRowSchema,
  scenarioResultSchema,
  transactionSchema,
} from '@/types/schemas';

describe('synthetic dataset', () => {
  const ds = getDataset();
  const all = new Set(ds.entities.map((e) => e.code));

  it('has the expected shape', () => {
    expect(ds.entities).toHaveLength(8);
    expect(ds.transactions.length).toBeGreaterThan(40_000);
    expect(ds.transactions.length).toBeLessThan(65_000);
    expect(new Set(ds.pairs.map((p) => p.currency)).size).toBeGreaterThanOrEqual(10);
  });

  it('validates against the schemas', () => {
    ds.entities.forEach((e) => entitySchema.parse(e));
    ds.transactions.slice(0, 200).forEach((t) => transactionSchema.parse(t));
    ds.positions.get('PARI|EUR')!.slice(-5).forEach((p) => dailyPositionSchema.parse(p));
    forecastSchema.parse(buildForecast('PARI', 'EUR'));
    gapRowsFor('PARI', 'EUR').forEach((g) => gapRowSchema.parse(g));
  });

  it('is deterministic', () => {
    expect(ds.transactions[0].transactionId).toBe(getDataset().transactions[0].transactionId);
  });

  it('seeds the EUR/Paris shortfall on day 3', () => {
    const rows = gapRowsFor('PARI', 'EUR');
    expect(rows[2].severity).toBe('EMERGENCY');
    const alerts = liveAlerts(all);
    alerts.forEach((a) => alertSchema.parse(a));
    const sevs = alerts.map((a) => `${a.entityCode}${a.currency}:${a.severity}`);
    expect(sevs).toContain('PARIEUR:EMERGENCY');
    expect(sevs).toContain('SINGUSD:CRITICAL');
    expect(sevs).toContain('LONDGBP:WARNING');
    expect(sevs).toContain('FRANEUR:EMERGENCY');
    // keep the demo calm: only the seeded story, no accidental breaches
    expect(alerts.length).toBeLessThanOrEqual(6);
  });

  it('what-if payment delay changes the gap', () => {
    const r = runScenario('PARI', 'EUR', {
      paymentDelayDays: 3,
      capexShiftDays: 0,
      fxShockPct: {},
      rateShockBps: 0,
      ratingDowngrades: {},
    });
    expect(r).not.toBeNull();
    scenarioResultSchema.parse(r);
    expect(r!.impact.minGapScenario).toBeLessThan(r!.impact.minGapBaseline);
  });
});
