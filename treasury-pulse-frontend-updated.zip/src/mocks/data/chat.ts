import { formatMoney } from '@/lib/format';
import type { ChartSpec, ChatContext, ChatFinal, Recommendation } from '@/types/domain';
import { buildForecast, gapRowsFor, liveAlerts, recommendationsFor, runScenario, thresholdFor } from './forecast';
import { ENTITIES, FX_TO_USD, getDataset } from './generator';

export interface ChatAnswer {
  text: string;
  final: Omit<ChatFinal, 'conversationId'>;
}

function worstRow(entity: string, ccy: string) {
  const rows = gapRowsFor(entity, ccy);
  return rows.length ? rows.reduce((a, r) => (r.gap < a.gap ? r : a), rows[0]) : null;
}

export function answer(message: string, ctx: ChatContext | undefined, allowed: Set<string>): ChatAnswer {
  const q = message.toLowerCase();
  const entity = ctx?.entityCode && allowed.has(ctx.entityCode) ? ctx.entityCode : null;

  // 1. Why is there a shortfall?
  if (/(why|shortfall|explain|short)/.test(q) && !q.includes('what if')) {
    const alerts = liveAlerts(allowed).filter((a) => a.severity !== 'WARNING' || !!entity);
    const target =
      alerts.find((a) => a.entityCode === entity && (!ctx?.currency || a.currency === ctx.currency)) ??
      alerts.sort((a, b) => a.gap - b.gap)[0];
    if (!target) {
      return { text: 'There are no projected shortfalls in the 30-day horizon for the entities you can access.', final: { sources: [{ label: 'Liquidity gap table', ref: '/liquidity' }] } };
    }
    const f = buildForecast(target.entityCode, target.currency)!;
    const drivers = (f.drivers ?? []).filter((d) => d.direction === 'OUTFLOW');
    const total = drivers.reduce((a, d) => a + d.amount, 0);
    const chart: ChartSpec = {
      kind: 'line',
      title: `${target.entityCode} ${target.currency} projected position vs threshold`,
      xKey: 'date',
      series: [{ key: 'projected', label: 'Projected' }, { key: 'threshold', label: 'Threshold' }],
      data: f.points.slice(0, 20).map((p) => ({ date: p.date.slice(5), projected: p.projected, threshold: target.threshold })),
    };
    return {
      text:
        `**${target.entityCode} ${target.currency}** is projected to fall to **${formatMoney(target.projected, target.currency)}** on ${target.forDate}, ` +
        `${formatMoney(Math.abs(target.gap), target.currency)} ${target.gap < 0 ? 'below' : 'above'} the ${formatMoney(target.threshold, target.currency)} threshold (${target.severity.toLowerCase()}).\n\n` +
        (drivers.length
          ? `The drop is driven by ${drivers.length} scheduled outflow${drivers.length > 1 ? 's' : ''} totalling ${formatMoney(total, target.currency)}:\n` +
            drivers.map((d) => `- ${d.label}: ${formatMoney(d.amount, target.currency)}`).join('\n')
          : 'Seasonal outflows (payroll, supplier runs) outweigh expected receipts in that window.') +
        '\n\nReceipts are expected to recover the position about five days later.',
      final: {
        chart,
        sources: [
          { label: `Forecast ${target.entityCode}/${target.currency}`, ref: `/forecast?entity=${target.entityCode}&currency=${target.currency}` },
          { label: 'Alert ' + target.id, ref: '/alerts' },
        ],
      },
    };
  }

  // 2. What if we delay payments?
  if (/what if|delay|scenario/.test(q)) {
    const e = entity ?? 'PARI';
    const c = ctx?.currency ?? ENTITIES.find((x) => x.code === e)!.baseCurrency;
    const days = Number(/(\d)\s*day/.exec(q)?.[1] ?? ctx?.scenario?.paymentDelayDays ?? 3) as 0 | 1 | 2 | 3 | 4 | 5;
    const r = runScenario(e, c, { paymentDelayDays: Math.min(5, days) as 0 | 1 | 2 | 3 | 4 | 5, capexShiftDays: ctx?.scenario?.capexShiftDays ?? 0, fxShockPct: {}, rateShockBps: 0, ratingDowngrades: {} });
    if (r) {
      return {
        text:
          `If receipts slip by **${days} days** for ${e} ${c}, the lowest gap vs threshold moves from **${formatMoney(r.impact.minGapBaseline, c)}** to **${formatMoney(r.impact.minGapScenario, c)}**. ` +
          `Estimated extra funding cost: ${formatMoney(r.impact.overdraftCostDelta, c)}. Open the What-If page to test mitigations such as postponing capex.`,
        final: {
          chart: {
            kind: 'line',
            title: `${e} ${c}: baseline vs ${days}-day delay`,
            xKey: 'date',
            series: [{ key: 'baseline', label: 'Baseline' }, { key: 'scenario', label: 'Scenario' }],
            data: r.baseline.slice(0, 20).map((p, i) => ({ date: p.date.slice(5), baseline: p.projected, scenario: r.scenario[i].projected })),
          },
          sources: [{ label: 'Scenario engine', ref: '/what-if' }],
        },
      };
    }
  }

  // 3. Surplus
  if (/surplus|deploy|invest/.test(q) && !/action plan|recommend/.test(q)) {
    const regionMatch = /apac|emea|namer/.exec(q)?.[0]?.toUpperCase();
    const { surplus } = recommendationsFor(allowed);
    const rows = surplus.filter((s) => !regionMatch || ENTITIES.find((e) => e.code === s.entityCode)?.region === regionMatch);
    if (rows.length === 0) return { text: 'No deployable surplus (projected balance above threshold +20%) was found in scope.', final: {} };
    const toUsd = (s: { deployable: number; currency: string }) => s.deployable * (FX_TO_USD[s.currency] ?? 1);
    const total = rows.reduce((a, s) => a + toUsd(s), 0);
    return {
      text: `Deployable surplus${regionMatch ? ' in ' + regionMatch : ''} is about **${formatMoney(total, 'USD', { compact: true })}** (USD equivalent) across ${rows.length} entity/currency positions. Largest: ${rows[0].entityCode} ${rows[0].currency} at ${formatMoney(rows[0].deployable, rows[0].currency, { compact: true })}.`,
      final: {
        chart: {
          kind: 'bar',
          title: 'Deployable surplus by position (USD eq.)',
          xKey: 'position',
          series: [{ key: 'usd', label: 'USD equivalent' }],
          data: rows.slice(0, 8).map((s) => ({ position: `${s.entityCode} ${s.currency}`, usd: Math.round(toUsd(s)) })),
        },
        sources: [{ label: 'Recommendations — surplus table', ref: '/recommendations' }],
      },
    };
  }

  // 4. Action plan / default
  const { recommendations } = recommendationsFor(allowed, entity);
  const top: Recommendation[] = recommendations.slice(0, 4);
  return {
    text: top.length
      ? `Here is the prioritised action plan. The top item is **${top[0].title}** with an expected impact of ${formatMoney(top[0].expectedImpact, top[0].currency, { compact: true })}.`
      : 'No actions are needed right now — all in-scope positions are above their thresholds.',
    final: {
      actionPlan: top,
      sources: [
        { label: 'Recommendation engine', ref: '/recommendations' },
        ...(entity && thresholdFor(entity, ctx?.currency ?? '') ? [{ label: 'Thresholds', ref: '/admin/thresholds' }] : []),
      ],
    },
  };
}

export function datasetStats() {
  const ds = getDataset();
  return { transactions: ds.transactions.length, entities: ds.entities.length };
}

export { worstRow };
