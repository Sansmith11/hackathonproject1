import { addDays, format, getDay, parseISO } from 'date-fns';
import { classifySeverity, SEVERITY_RANK, type SeverityBands } from '@/lib/alerts';
import {
  deployableSurplus,
  gapAmount,
  headroomPct,
  isSurplus,
  resolveThreshold,
} from '@/lib/gap';
import type {
  Alert,
  Forecast,
  ForecastDriver,
  ForecastPoint,
  GapRow,
  Recommendation,
  RiskRating,
  ScenarioParams,
  ScenarioResult,
  Severity,
  SurplusRow,
  Threshold,
  Transaction,
} from '@/types/domain';
import {
  FX_TO_USD,
  TODAY,
  getDataset,
  getEntity,
  hashString,
  mulberry32,
  pairKey,
  round2,
} from './generator';
import { store } from './store';

export interface ForecastInternal {
  entityCode: string;
  currency: string;
  prevBalance: number;
  dates: string[];
  inflow: number[];
  outflow: number[];
  /** Capex-style outflows that can be postponed (already included in outflow). */
  capex: number[];
  sd: number;
  lowRatedShare: number;
  model: 'PROPHET' | 'SARIMA';
  drivers: ForecastDriver[];
}

interface Injection {
  entityCode: string;
  currency: string;
  day: number;
  targetMult: number;
  capexShare: number;
  labels: string[];
  /** target applies to the lowest point of the horizon rather than to `day` itself */
  minBased?: boolean;
}

/** Deliberate future shortfalls so alerts and the assistant have a story to tell. */
const INJECTIONS: Injection[] = [
  { entityCode: 'PARI', currency: 'EUR', day: 3, targetMult: 0.82, capexShare: 0.3, labels: ['Loan repayment — Facility A', 'Loan repayment — Facility B', 'Loan repayment — Facility C'] },
  { entityCode: 'SING', currency: 'USD', day: 9, targetMult: 1.03, capexShare: 0, minBased: true, labels: ['Syndicated loan instalment', 'Supplier settlement run'] },
  { entityCode: 'LOND', currency: 'GBP', day: 14, targetMult: 1.07, capexShare: 0.4, labels: ['Term loan repayment', 'Capex: office fit-out'] },
  { entityCode: 'FRAN', currency: 'EUR', day: 21, targetMult: 0.97, capexShare: 0, labels: ['Bond coupon payment', 'Quarterly VAT settlement'] },
];

const internalCache = new Map<string, ForecastInternal>();
const txnIndex = new Map<string, Transaction[]>();

function txnsFor(key: string): Transaction[] {
  if (txnIndex.size === 0) {
    for (const t of getDataset().transactions) {
      const k = pairKey(t.entityCode, t.currency);
      const arr = txnIndex.get(k);
      if (arr) arr.push(t);
      else txnIndex.set(k, [t]);
    }
  }
  return txnIndex.get(key) ?? [];
}

export function getInternal(entityCode: string, currency: string): ForecastInternal | null {
  const key = pairKey(entityCode, currency);
  const hit = internalCache.get(key);
  if (hit) return hit;
  const ds = getDataset();
  const rows = ds.positions.get(key);
  if (!rows) return null;

  const last = rows[rows.length - 1];
  const recent = rows.slice(-56);
  const wdIn = new Array(7).fill(0);
  const wdOut = new Array(7).fill(0);
  const cnt = new Array(7).fill(0);
  for (const r of recent) {
    const d = getDay(parseISO(r.date));
    wdIn[d] += r.inflows;
    wdOut[d] += r.outflows;
    cnt[d]++;
  }
  for (let d = 0; d < 7; d++) {
    wdIn[d] /= cnt[d] || 1;
    wdOut[d] /= cnt[d] || 1;
  }
  const k = wdOut.reduce((a, b) => a + b, 0) / (wdIn.reduce((a, b) => a + b, 0) || 1);

  const nets = rows.slice(-90).map((r) => {
    const d = getDay(parseISO(r.date));
    return r.inflows - r.outflows - (wdIn[d] * k - wdOut[d]);
  });
  const mean = nets.reduce((a, b) => a + b, 0) / nets.length;
  const sd = Math.sqrt(nets.reduce((a, b) => a + (b - mean) ** 2, 0) / nets.length);

  const t90 = txnsFor(key).filter((t) => t.transactionDate >= rows[rows.length - 90].date);
  const total = t90.reduce((a, t) => a + t.originalAmount, 0) || 1;
  const low = t90
    .filter((t) => t.counterpartyRiskRating === 'C' || t.counterpartyRiskRating === 'D')
    .reduce((a, t) => a + t.originalAmount, 0);

  const today = parseISO(TODAY);
  const dates: string[] = [];
  const inflow: number[] = [];
  const outflow: number[] = [];
  const capex: number[] = [];
  for (let d = 1; d <= 30; d++) {
    const dt = addDays(today, d);
    dates.push(format(dt, 'yyyy-MM-dd'));
    const dow = getDay(dt);
    inflow.push(wdIn[dow] * k);
    outflow.push(wdOut[dow]);
    capex.push(0);
  }

  const drivers: ForecastDriver[] = [];
  const inj = INJECTIONS.find((i) => i.entityCode === entityCode && i.currency === currency);
  if (inj) {
    const threshold = ds.pairs.find((p) => p.entityCode === entityCode && p.currency === currency);
    const T = threshold ? defaultThreshold(currency) ?? threshold.unit : 0;
    let bal = last.closingBalance;
    for (let d = 0; d < inj.day - 1; d++) bal += inflow[d] - outflow[d];
    const idx = inj.day - 1;
    let needed = Math.max(0, bal + inflow[idx] - outflow[idx] - inj.targetMult * T);
    if (inj.minBased) {
      // Solve for the shock size whose lowest point over the horizon sits at the target.
      const recIdx = Math.min(29, idx + 5);
      const path0: number[] = [];
      let b0 = last.closingBalance;
      for (let d = 0; d < 30; d++) {
        b0 += inflow[d] - outflow[d];
        path0.push(b0);
      }
      const lowest = (x: number) =>
        Math.min(...path0.map((v, d) => v - (d >= idx ? x : 0) + (d >= recIdx ? 0.9 * x : 0)));
      let lo = 0;
      let hi = Math.max(...path0);
      for (let n = 0; n < 50; n++) {
        const mid = (lo + hi) / 2;
        if (lowest(mid) > inj.targetMult * T) lo = mid;
        else hi = mid;
      }
      needed = lo;
    }
    const capexAmt = needed * inj.capexShare;
    const loanAmt = needed - capexAmt;
    if (capexAmt > 0) {
      outflow[idx] += capexAmt;
      capex[idx] += capexAmt;
      drivers.push({ date: dates[idx], label: 'Capex: data-centre refresh', amount: round2(capexAmt), direction: 'OUTFLOW' });
    }
    const loanLabels = inj.labels.filter((l) => !(inj.capexShare > 0 && l.startsWith('Capex')));
    const shares = loanLabels.length === 3 ? [0.4, 0.35, 0.25] : loanLabels.length === 2 ? [0.6, 0.4] : [1];
    loanLabels.forEach((label, i) => {
      const amt = loanAmt * shares[i];
      outflow[idx] += amt;
      drivers.push({ date: dates[idx], label, amount: round2(amt), direction: 'OUTFLOW' });
    });
    const recoverIdx = Math.min(29, idx + 5);
    const recovery = needed * 0.9;
    inflow[recoverIdx] += recovery;
    drivers.push({ date: dates[recoverIdx], label: 'Expected customer receipts (recovery)', amount: round2(recovery), direction: 'INFLOW' });
  }

  const out: ForecastInternal = {
    entityCode,
    currency,
    prevBalance: last.closingBalance,
    dates,
    inflow,
    outflow,
    capex,
    sd,
    lowRatedShare: low / total,
    model: hashString(key) % 3 === 0 ? 'SARIMA' : 'PROPHET',
    drivers,
  };
  internalCache.set(key, out);
  return out;
}

function defaultThreshold(currency: string): number | undefined {
  return { EUR: 50_000, USD: 60_000, JPY: 5_000_000, GBP: 40_000 }[currency];
}

function balances(i: ForecastInternal, inflow = i.inflow, outflow = i.outflow): number[] {
  const out: number[] = [];
  let b = i.prevBalance;
  for (let d = 0; d < inflow.length; d++) {
    b += inflow[d] - outflow[d];
    out.push(b);
  }
  return out;
}

function toPoints(i: ForecastInternal, bal: number[]): ForecastPoint[] {
  const widen = 1 + 0.6 * i.lowRatedShare;
  return bal.map((b, d) => {
    const sd = i.sd * Math.sqrt(d + 1) * widen;
    return {
      date: i.dates[d],
      projected: round2(b),
      lower80: round2(b - 1.2816 * sd),
      upper80: round2(b + 1.2816 * sd),
      lower95: round2(b - 1.96 * sd),
      upper95: round2(b + 1.96 * sd),
    };
  });
}

export function buildForecast(entityCode: string, currency: string): Forecast | null {
  const i = getInternal(entityCode, currency);
  if (!i) return null;
  return {
    entityCode,
    currency,
    model: i.model,
    generatedAt: `${TODAY}T06:00:00Z`,
    horizonDays: 30,
    points: toPoints(i, balances(i)),
    drivers: i.drivers,
    lowRatedShare: round2(i.lowRatedShare),
  };
}

/* ---------- thresholds & gap ---------- */

export function avgClosing30(entityCode: string, currency: string): number {
  const rows = getDataset().positions.get(pairKey(entityCode, currency)) ?? [];
  const s = rows.slice(-30);
  return s.reduce((a, r) => a + r.closingBalance, 0) / (s.length || 1);
}

export function thresholdFor(
  entityCode: string,
  currency: string,
  thresholds: Threshold[] = store.thresholds,
): { value: number; source: string } | null {
  const e = getEntity(entityCode);
  if (!e) return null;
  const r = resolveThreshold(thresholds, entityCode, e.region, currency, avgClosing30(entityCode, currency));
  return r ? { value: r.value, source: r.source } : null;
}

export function gapRowsFor(
  entityCode: string,
  currency: string,
  bands: SeverityBands = store.bands,
): GapRow[] {
  const f = buildForecast(entityCode, currency);
  const t = thresholdFor(entityCode, currency);
  if (!f || !t) return [];
  return f.points.map((p) => {
    const gap = gapAmount(p.projected, t.value);
    return {
      date: p.date,
      entityCode,
      currency,
      projected: p.projected,
      threshold: round2(t.value),
      gap: round2(gap),
      headroomPct: round2(headroomPct(p.projected, t.value)),
      severity: classifySeverity(p.projected, t.value, bands),
      isSurplus: isSurplus(p.projected, t.value),
    };
  });
}

export function allGapRows(allowed: Set<string>): GapRow[] {
  return getDataset()
    .pairs.filter((p) => allowed.has(p.entityCode))
    .flatMap((p) => gapRowsFor(p.entityCode, p.currency));
}

/* ---------- alerts ---------- */

export function liveAlerts(allowed: Set<string>): Alert[] {
  const out: Alert[] = [];
  for (const p of getDataset().pairs) {
    if (!allowed.has(p.entityCode)) continue;
    const rows = gapRowsFor(p.entityCode, p.currency);
    let worst: GapRow | null = null;
    for (const r of rows) {
      if (r.severity === 'OK') continue;
      if (
        !worst ||
        SEVERITY_RANK[r.severity] > SEVERITY_RANK[worst.severity] ||
        (r.severity === worst.severity && r.gap < worst.gap)
      )
        worst = r;
    }
    if (!worst) continue;
    const id = `ALR-${p.entityCode}-${p.currency}-${worst.date}`;
    const st = store.alertState.get(id);
    out.push({
      id,
      createdAt: `${TODAY}T06:00:00Z`,
      entityCode: p.entityCode,
      currency: p.currency,
      severity: worst.severity as Exclude<Severity, 'OK'>,
      gap: worst.gap,
      projected: worst.projected,
      threshold: worst.threshold,
      forDate: worst.date,
      status: st?.status ?? 'OPEN',
      resolvedAt: st?.resolvedAt,
      note: st?.note,
    });
  }
  return out;
}

export function historicalAlerts(): Alert[] {
  const rng = mulberry32(777);
  const pairs = getDataset().pairs.filter((p) => defaultThreshold(p.currency));
  const sev: Exclude<Severity, 'OK'>[] = ['WARNING', 'CRITICAL', 'EMERGENCY', 'WARNING', 'CRITICAL'];
  const today = parseISO(TODAY);
  return Array.from({ length: 14 }, (_, i) => {
    const p = pairs[Math.floor(rng() * pairs.length)];
    const created = addDays(today, -(5 + Math.floor(rng() * 80)));
    const T = defaultThreshold(p.currency) ?? p.unit;
    const s = sev[i % sev.length];
    const projected = s === 'EMERGENCY' ? T * 0.9 : s === 'CRITICAL' ? T * 1.03 : T * 1.08;
    const resolved = addDays(created, 1 + Math.floor(rng() * 3));
    return {
      id: `ALR-H${String(i + 1).padStart(3, '0')}`,
      createdAt: format(created, "yyyy-MM-dd'T'08:00:00'Z'"),
      entityCode: p.entityCode,
      currency: p.currency,
      severity: s,
      gap: round2(projected - T),
      projected: round2(projected),
      threshold: T,
      forDate: format(addDays(created, 2), 'yyyy-MM-dd'),
      status: 'RESOLVED' as const,
      resolvedAt: format(resolved, "yyyy-MM-dd'T'16:30:00'Z'"),
      note: ['Intercompany funding arranged', 'Receipts arrived earlier than expected', 'Payment run rescheduled'][i % 3],
    };
  });
}

/* ---------- scenarios ---------- */

const RATING_ORDER: RiskRating[] = ['A', 'B', 'C', 'D'];

export function runScenario(
  entityCode: string,
  currency: string,
  params: ScenarioParams,
  bands: SeverityBands = store.bands,
): ScenarioResult | null {
  const i = getInternal(entityCode, currency);
  if (!i) return null;
  const n = i.inflow.length;
  const D = params.paymentDelayDays;

  // Receivables slip by D days (stress). Receipts from before today land at day 0 in the base case.
  let inflow = i.inflow.map((_, d) => (d - D >= 0 ? i.inflow[d - D] : 0));
  // Counterparty downgrades haircut expected receipts (1.5% per notch, capped).
  const cps = getDataset().counterparties;
  let haircut = 0;
  for (const [name, newRating] of Object.entries(params.ratingDowngrades)) {
    const cur = cps.find((c) => c.name === name)?.rating ?? 'A';
    const steps = RATING_ORDER.indexOf(newRating) - RATING_ORDER.indexOf(cur);
    if (steps > 0) haircut += steps * 0.015;
  }
  haircut = Math.min(0.4, haircut);
  inflow = inflow.map((v) => v * (1 - haircut));

  // Capex postponed by S days (relief).
  const S = Math.round(params.capexShiftDays);
  const outflow = [...i.outflow];
  if (S > 0) {
    for (let d = 0; d < n; d++) {
      if (i.capex[d] > 0) {
        outflow[d] -= i.capex[d];
        if (d + S < n) outflow[d + S] += i.capex[d];
      }
    }
  }

  const base = balances(i);
  const scen = balances(i, inflow, outflow);
  const baseline = toPoints(i, base);
  const scenarioPts = baseline.map((b, d) => {
    const diff = scen[d] - base[d];
    return {
      ...b,
      projected: round2(scen[d]),
      lower80: round2(b.lower80 + diff),
      upper80: round2(b.upper80 + diff),
      lower95: round2(b.lower95 + diff),
      upper95: round2(b.upper95 + diff),
    };
  });

  const T = thresholdFor(entityCode, currency)?.value ?? 0;
  void bands;
  const minBase = Math.min(...base);
  const minScen = Math.min(...scen);
  const fundingCost = (arr: number[]) =>
    arr.reduce((a, b) => a + Math.max(0, T - b) * (0.05 / 365), 0);
  const shock = params.fxShockPct[currency] ?? 0;
  const lastBal = scen[n - 1];
  const avgBal = scen.reduce((a, b) => a + b, 0) / n;

  return {
    baseline,
    scenario: scenarioPts,
    impact: {
      minGapBaseline: round2(minBase - T),
      minGapScenario: round2(minScen - T),
      overdraftCostDelta: round2(fundingCost(scen) - fundingCost(base)),
      fxGainLoss: round2(lastBal * (shock / 100) * (FX_TO_USD[currency] ?? 1)),
      interestDelta: round2(avgBal * (params.rateShockBps / 10000) * (30 / 365)),
      deployableSurplusDelta: round2(
        deployableSurplus(minScen, T) - deployableSurplus(minBase, T),
      ),
    },
  };
}

/* ---------- recommendations ---------- */

export function recommendationsFor(allowed: Set<string>, entity?: string | null) {
  const ds = getDataset();
  const recs: Recommendation[] = [];
  const surplus: SurplusRow[] = [];
  let seq = 1;
  const pairs = ds.pairs.filter(
    (p) => allowed.has(p.entityCode) && (!entity || p.entityCode === entity),
  );
  for (const p of ds.pairs.filter((x) => allowed.has(x.entityCode))) {
    const t = thresholdFor(p.entityCode, p.currency);
    if (!t) continue;
    const f = buildForecast(p.entityCode, p.currency);
    if (!f) continue;
    const minP = Math.min(...f.points.map((x) => x.projected));
    const dep = deployableSurplus(minP, t.value);
    if (dep > 0 && (!entity || p.entityCode === entity)) {
      surplus.push({
        entityCode: p.entityCode,
        currency: p.currency,
        minProjected: round2(minP),
        threshold: round2(t.value),
        deployable: round2(dep),
      });
    }
  }
  for (const p of pairs) {
    const t = thresholdFor(p.entityCode, p.currency);
    if (!t) continue;
    const rows = gapRowsFor(p.entityCode, p.currency);
    const worst = rows.reduce((a, r) => (r.gap < a.gap ? r : a), rows[0]);
    if (!worst) continue;
    const mk = (r: Omit<Recommendation, 'id'>) => recs.push({ id: `rec-${seq++}`, ...r });
    if (worst.severity !== 'OK') {
      const g = Math.abs(Math.min(worst.gap, 0)) || t.value * 0.05;
      const urgency = worst.severity === 'EMERGENCY' ? 1 : worst.severity === 'CRITICAL' ? 0.85 : 0.7;
      const base = (impact: number, w: number) =>
        Math.round(Math.min(99, 40 + 50 * urgency * Math.min(1, impact / (t.value * 0.5)) * w));
      const prio = (s: number): 1 | 2 | 3 => (s >= 75 ? 1 : s >= 60 ? 2 : 3);
      const s1 = base(g * 1.1, 1);
      mk({ action: 'ACCELERATE_COLLECTIONS', title: `Accelerate collections for ${p.entityCode} ${p.currency}`, rationale: `Projected ${worst.severity.toLowerCase()} on ${worst.date}. Chasing the top receivables 3–5 days earlier closes ~110% of the gap.`, entityCode: p.entityCode, currency: p.currency, expectedImpact: round2(g * 1.1), score: s1, priority: prio(s1) });
      const s2 = base(g * 0.8, 0.9);
      mk({ action: 'DELAY_PAYMENTS', title: `Delay non-urgent payments for ${p.entityCode} ${p.currency}`, rationale: 'Defer discretionary supplier and capex payments past the low-point date without penalty.', entityCode: p.entityCode, currency: p.currency, expectedImpact: round2(g * 0.8), score: s2, priority: prio(s2) });
      const donor = surplus.find((s) => s.currency === p.currency && s.entityCode !== p.entityCode);
      if (donor) {
        const amt = Math.min(donor.deployable, g * 1.2);
        const s3 = base(amt, 1.05);
        mk({ action: 'INTERCOMPANY_TRANSFER', title: `Transfer ${p.currency} from ${donor.entityCode} to ${p.entityCode}`, rationale: `${donor.entityCode} holds deployable ${p.currency} surplus above its buffer.`, entityCode: p.entityCode, currency: p.currency, expectedImpact: round2(amt), score: s3, priority: prio(s3) });
      } else {
        const s4 = base(g, 0.8);
        mk({ action: 'CASH_POOLING', title: `Pool ${p.currency} balances into ${p.entityCode}`, rationale: 'No same-currency surplus donor; use the regional cash pool to cover the low point.', entityCode: p.entityCode, currency: p.currency, expectedImpact: round2(g), score: s4, priority: prio(s4) });
      }
    }
  }
  for (const s of surplus) {
    const sc = Math.round(Math.min(90, 45 + 30 * Math.min(1, s.deployable / (s.threshold * 2))));
    recs.push({
      id: `rec-${seq++}`,
      action: 'INVEST_SURPLUS',
      title: `Invest ${s.currency} surplus at ${s.entityCode}`,
      rationale: `${s.deployable.toFixed(0)} ${s.currency} stays above threshold +20% for the full 30-day horizon.`,
      entityCode: s.entityCode,
      currency: s.currency,
      expectedImpact: round2(s.deployable),
      score: sc,
      priority: sc >= 75 ? 1 : sc >= 60 ? 2 : 3,
    });
  }
  recs.sort((a, b) => b.score - a.score);
  return { recommendations: recs, surplus: surplus.sort((a, b) => b.deployable - a.deployable) };
}
