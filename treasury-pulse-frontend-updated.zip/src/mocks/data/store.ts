import { DEFAULT_CURRENCY_THRESHOLDS } from '@/lib/gap';
import { DEFAULT_BANDS, type SeverityBands } from '@/lib/alerts';
import type {
  AlertStatus,
  ReportHistoryItem,
  ReportSchedule,
  Threshold,
  UploadHistoryItem,
  User,
} from '@/types/domain';

interface AlertState {
  status: AlertStatus;
  resolvedAt?: string;
  note?: string;
}

interface MockStore {
  thresholds: Threshold[];
  bands: SeverityBands;
  alertState: Map<string, AlertState>;
  users: User[];
  schedules: ReportSchedule[];
  reports: ReportHistoryItem[];
  uploads: UploadHistoryItem[];
  seq: number;
}

function seed(): MockStore {
  return {
    thresholds: Object.entries(DEFAULT_CURRENCY_THRESHOLDS).map(([currency, value]) => ({
      id: `thr-${currency}`,
      scope: 'CURRENCY' as const,
      currency,
      mode: 'ABSOLUTE' as const,
      value,
    })),
    bands: { ...DEFAULT_BANDS },
    alertState: new Map(),
    users: [
      { id: 'u-viewer', name: 'Vera Viewer', email: 'viewer@demo', role: 'VIEWER', entityCodes: ['PARI', 'FRAN'], regions: [] },
      { id: 'u-analyst', name: 'Anaïs Analyst', email: 'analyst.paris@demo', role: 'ANALYST', entityCodes: ['PARI', 'LOND', 'FRAN'], regions: ['EMEA'] },
      { id: 'u-manager', name: 'Mei Manager', email: 'manager.apac@demo', role: 'TREASURY_MANAGER', entityCodes: ['SING', 'TOKY', 'MUMB'], regions: ['APAC'] },
      { id: 'u-admin', name: 'Adam Admin', email: 'admin@demo', role: 'ADMIN', entityCodes: [], regions: ['APAC', 'EMEA', 'NAMER'] },
    ],
    schedules: [
      { id: 'sch-sod', type: 'SOD', enabled: true, cron: '0 7 * * 1-5', timezone: 'Europe/Paris', formats: ['PDF', 'CSV'], recipients: ['treasury@demo.example'] },
      { id: 'sch-eod', type: 'EOD', enabled: true, cron: '0 18 * * 1-5', timezone: 'Europe/Paris', formats: ['PDF'], recipients: ['treasury@demo.example'] },
    ],
    reports: [],
    uploads: [
      { uploadId: 'upl-0000', fileName: 'transactions_2026-09.csv', uploadedAt: '2026-10-01T09:12:00Z', uploadedBy: 'analyst.paris@demo', rowsParsed: 4210, rowsRejected: 3 },
    ],
    seq: 1,
  };
}

export let store: MockStore = seed();

export function resetStore(): void {
  store = seed();
}

export function nextId(prefix: string): string {
  return `${prefix}-${String(store.seq++).padStart(4, '0')}`;
}

