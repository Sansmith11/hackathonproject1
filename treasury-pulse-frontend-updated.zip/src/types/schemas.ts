import { z } from 'zod';
import type {
  Alert,
  BenchmarksResponse,
  ChartSpec,
  ChatFinal,
  DailyPosition,
  Entity,
  Forecast,
  FxRates,
  GapRow,
  IntradayBucket,
  PositionSummary,
  Recommendation,
  RecommendationsResponse,
  ReportHistoryItem,
  ReportSchedule,
  ScenarioResult,
  Threshold,
  Transaction,
  TransactionPage,
  UploadHistoryItem,
  UploadResult,
  User,
} from './domain';

export const roleSchema = z.enum(['VIEWER', 'ANALYST', 'TREASURY_MANAGER', 'ADMIN']);
export const regionSchema = z.enum(['APAC', 'EMEA', 'NAMER']);
export const directionSchema = z.enum(['INFLOW', 'OUTFLOW']);
export const ratingSchema = z.enum(['A', 'B', 'C', 'D']);
export const severitySchema = z.enum(['OK', 'WARNING', 'CRITICAL', 'EMERGENCY']);
export const alertStatusSchema = z.enum(['OPEN', 'ACKNOWLEDGED', 'RESOLVED']);

export const entitySchema = z.object({
  code: z.string(),
  name: z.string(),
  region: regionSchema,
  country: z.string(),
  city: z.string(),
  baseCurrency: z.string(),
}) satisfies z.ZodType<Entity>;

export const transactionSchema = z.object({
  transactionId: z.string(),
  transactionDate: z.string(),
  dueDate: z.string().nullable(),
  entityCode: z.string(),
  region: regionSchema,
  country: z.string(),
  city: z.string(),
  accountType: z.string(),
  accountNumber: z.string(),
  currency: z.string(),
  originalAmount: z.number(),
  direction: directionSchema,
  productType: z.string(),
  category: z.string(),
  frequency: z.string(),
  isRecurring: z.boolean(),
  paymentMethod: z.string(),
  counterparty: z.string(),
  settlementStatus: z.string(),
  department: z.string(),
  counterpartyRiskRating: ratingSchema,
  originCurrency: z.string(),
  destinationCurrency: z.string(),
  isCrossBorder: z.boolean(),
  fxRate: z.number(),
  maturityDate: z.string().nullable(),
}) satisfies z.ZodType<Transaction>;

export const transactionPageSchema = z.object({
  items: z.array(transactionSchema),
  total: z.number(),
  page: z.number(),
  pageSize: z.number(),
}) satisfies z.ZodType<TransactionPage>;

export const dailyPositionSchema = z.object({
  date: z.string(),
  entityCode: z.string(),
  currency: z.string(),
  openingBalance: z.number(),
  inflows: z.number(),
  outflows: z.number(),
  closingBalance: z.number(),
}) satisfies z.ZodType<DailyPosition>;

export const forecastPointSchema = z.object({
  date: z.string(),
  projected: z.number(),
  lower80: z.number(),
  upper80: z.number(),
  lower95: z.number(),
  upper95: z.number(),
  actual: z.number().optional(),
});

export const forecastSchema = z.object({
  entityCode: z.string(),
  currency: z.string(),
  model: z.enum(['PROPHET', 'SARIMA']),
  generatedAt: z.string(),
  horizonDays: z.literal(30),
  points: z.array(forecastPointSchema),
  drivers: z
    .array(
      z.object({
        date: z.string(),
        label: z.string(),
        amount: z.number(),
        direction: directionSchema,
      }),
    )
    .optional(),
  lowRatedShare: z.number().optional(),
}) satisfies z.ZodType<Forecast>;

export const thresholdSchema = z.object({
  id: z.string(),
  scope: z.enum(['CURRENCY', 'ENTITY', 'REGION']),
  entityCode: z.string().optional(),
  region: regionSchema.optional(),
  currency: z.string(),
  mode: z.enum(['ABSOLUTE', 'PERCENT']),
  value: z.number(),
}) satisfies z.ZodType<Threshold>;

export const gapRowSchema = z.object({
  date: z.string(),
  entityCode: z.string(),
  currency: z.string(),
  projected: z.number(),
  threshold: z.number(),
  gap: z.number(),
  headroomPct: z.number(),
  severity: severitySchema,
  isSurplus: z.boolean(),
}) satisfies z.ZodType<GapRow>;

export const alertSchema = z.object({
  id: z.string(),
  createdAt: z.string(),
  entityCode: z.string(),
  currency: z.string(),
  severity: z.enum(['WARNING', 'CRITICAL', 'EMERGENCY']),
  gap: z.number(),
  projected: z.number(),
  threshold: z.number(),
  forDate: z.string(),
  status: alertStatusSchema,
  resolvedAt: z.string().optional(),
  note: z.string().optional(),
}) satisfies z.ZodType<Alert>;

export const scenarioParamsSchema = z.object({
  paymentDelayDays: z.union([
    z.literal(0),
    z.literal(1),
    z.literal(2),
    z.literal(3),
    z.literal(4),
    z.literal(5),
  ]),
  capexShiftDays: z.number().min(0).max(30),
  fxShockPct: z.record(z.string(), z.number()),
  rateShockBps: z.union([
    z.literal(-200),
    z.literal(-100),
    z.literal(-50),
    z.literal(0),
    z.literal(50),
    z.literal(100),
    z.literal(200),
  ]),
  ratingDowngrades: z.record(z.string(), ratingSchema),
});

export const scenarioResultSchema = z.object({
  baseline: z.array(forecastPointSchema),
  scenario: z.array(forecastPointSchema),
  impact: z.object({
    minGapBaseline: z.number(),
    minGapScenario: z.number(),
    overdraftCostDelta: z.number(),
    fxGainLoss: z.number(),
    interestDelta: z.number(),
    deployableSurplusDelta: z.number(),
  }),
}) satisfies z.ZodType<ScenarioResult>;

export const recommendationSchema = z.object({
  id: z.string(),
  action: z.enum([
    'ACCELERATE_COLLECTIONS',
    'DELAY_PAYMENTS',
    'INVEST_SURPLUS',
    'INTERCOMPANY_TRANSFER',
    'CASH_POOLING',
  ]),
  title: z.string(),
  rationale: z.string(),
  entityCode: z.string(),
  currency: z.string(),
  expectedImpact: z.number(),
  score: z.number(),
  priority: z.union([z.literal(1), z.literal(2), z.literal(3)]),
}) satisfies z.ZodType<Recommendation>;

export const recommendationsResponseSchema = z.object({
  recommendations: z.array(recommendationSchema),
  surplus: z.array(
    z.object({
      entityCode: z.string(),
      currency: z.string(),
      minProjected: z.number(),
      threshold: z.number(),
      deployable: z.number(),
    }),
  ),
}) satisfies z.ZodType<RecommendationsResponse>;

export const reportScheduleSchema = z.object({
  id: z.string(),
  type: z.enum(['SOD', 'EOD']),
  enabled: z.boolean(),
  cron: z.string(),
  timezone: z.string(),
  formats: z.array(z.enum(['PDF', 'CSV'])),
  recipients: z.array(z.string()),
}) satisfies z.ZodType<ReportSchedule>;

export const reportHistorySchema = z.object({
  id: z.string(),
  type: z.enum(['SOD', 'EOD']),
  format: z.enum(['PDF', 'CSV']),
  entityCode: z.string().nullable(),
  generatedAt: z.string(),
  generatedBy: z.string(),
  sizeBytes: z.number(),
}) satisfies z.ZodType<ReportHistoryItem>;

export const userSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string(),
  role: roleSchema,
  entityCodes: z.array(z.string()),
  regions: z.array(regionSchema),
}) satisfies z.ZodType<User>;

export const loginResponseSchema = z.object({ token: z.string(), user: userSchema });

export const chartSpecSchema = z.object({
  kind: z.enum(['line', 'bar', 'area', 'donut']),
  title: z.string(),
  xKey: z.string(),
  series: z.array(z.object({ key: z.string(), label: z.string() })),
  data: z.array(z.record(z.string(), z.union([z.string(), z.number()]))),
}) satisfies z.ZodType<ChartSpec>;

export const chatFinalSchema = z.object({
  conversationId: z.string(),
  chart: chartSpecSchema.optional(),
  actionPlan: z.array(recommendationSchema).optional(),
  sources: z.array(z.object({ label: z.string(), ref: z.string() })).optional(),
}) satisfies z.ZodType<ChatFinal>;

export const positionSummarySchema = z.object({
  asOf: z.string(),
  reportingCcy: z.string(),
  totalCash: z.number(),
  byCurrency: z.array(z.object({ currency: z.string(), amount: z.number(), share: z.number() })),
  byRegion: z.array(
    z.object({
      region: regionSchema,
      amount: z.number(),
      openAlerts: z.number(),
      entities: z.number(),
    }),
  ),
  openAlerts: z.object({ EMERGENCY: z.number(), CRITICAL: z.number(), WARNING: z.number() }),
  entitiesInShortfall: z.number(),
  deployableSurplus: z.number(),
  minGap30d: z.number(),
}) satisfies z.ZodType<PositionSummary>;

export const intradaySchema = z.object({
  hour: z.number(),
  inflows: z.number(),
  outflows: z.number(),
}) satisfies z.ZodType<IntradayBucket>;

export const fxRatesSchema = z.object({
  date: z.string(),
  base: z.string(),
  rates: z.record(z.string(), z.number()),
}) satisfies z.ZodType<FxRates>;

export const uploadResultSchema = z.object({
  uploadId: z.string(),
  rowsParsed: z.number(),
  rowsRejected: z.number(),
  errors: z.array(z.object({ row: z.number(), field: z.string(), message: z.string() })),
}) satisfies z.ZodType<UploadResult>;

export const uploadHistorySchema = z.object({
  uploadId: z.string(),
  fileName: z.string(),
  uploadedAt: z.string(),
  uploadedBy: z.string(),
  rowsParsed: z.number(),
  rowsRejected: z.number(),
}) satisfies z.ZodType<UploadHistoryItem>;

export const benchmarksSchema = z.object({
  mape: z.number(),
  rmse: z.number(),
  perEntity: z.array(z.object({ entityCode: z.string(), mape: z.number(), rmse: z.number() })),
  backtest: z.array(z.object({ date: z.string(), actual: z.number(), forecast: z.number() })),
  timings: z.object({
    dashboardLoadMs: z.number(),
    forecastMs: z.number(),
    chatMs: z.number(),
    parse10k: z.number(),
    parse50k: z.number(),
    parse100k: z.number(),
  }),
}) satisfies z.ZodType<BenchmarksResponse>;

export const apiErrorSchema = z.object({
  error: z.object({ code: z.string(), message: z.string(), details: z.unknown().optional() }),
});
