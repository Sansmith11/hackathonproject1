export type Role = 'VIEWER' | 'ANALYST' | 'TREASURY_MANAGER' | 'ADMIN';
export type Region = 'APAC' | 'EMEA' | 'NAMER';
export type Direction = 'INFLOW' | 'OUTFLOW';
export type RiskRating = 'A' | 'B' | 'C' | 'D';
export type Severity = 'OK' | 'WARNING' | 'CRITICAL' | 'EMERGENCY';
export type AlertStatus = 'OPEN' | 'ACKNOWLEDGED' | 'RESOLVED';

export interface Entity {
  code: string;
  name: string;
  region: Region;
  country: string;
  city: string;
  baseCurrency: string;
}

export interface Transaction {
  transactionId: string;
  transactionDate: string;
  dueDate: string | null;
  entityCode: string;
  region: Region;
  country: string;
  city: string;
  accountType: string;
  accountNumber: string;
  currency: string;
  originalAmount: number;
  direction: Direction;
  productType: string;
  category: string;
  frequency: string;
  isRecurring: boolean;
  paymentMethod: string;
  counterparty: string;
  settlementStatus: string;
  department: string;
  counterpartyRiskRating: RiskRating;
  originCurrency: string;
  destinationCurrency: string;
  isCrossBorder: boolean;
  fxRate: number;
  maturityDate: string | null;
}

export interface TransactionPage {
  items: Transaction[];
  total: number;
  page: number;
  pageSize: number;
}

export interface DailyPosition {
  date: string;
  entityCode: string;
  currency: string;
  openingBalance: number;
  inflows: number;
  outflows: number;
  closingBalance: number;
}

export interface ForecastPoint {
  date: string;
  projected: number;
  lower80: number;
  upper80: number;
  lower95: number;
  upper95: number;
  actual?: number;
}

export interface ForecastDriver {
  date: string;
  label: string;
  amount: number;
  direction: Direction;
}

export interface Forecast {
  entityCode: string;
  currency: string;
  model: 'PROPHET' | 'SARIMA';
  generatedAt: string;
  horizonDays: 30;
  points: ForecastPoint[];
  drivers?: ForecastDriver[];
  /** Share of forecast flows from C/D-rated counterparties (drives band width). */
  lowRatedShare?: number;
}

export interface Threshold {
  id: string;
  scope: 'CURRENCY' | 'ENTITY' | 'REGION';
  entityCode?: string;
  region?: Region;
  currency: string;
  mode: 'ABSOLUTE' | 'PERCENT';
  value: number;
}

export interface GapRow {
  date: string;
  entityCode: string;
  currency: string;
  projected: number;
  threshold: number;
  gap: number;
  headroomPct: number;
  severity: Severity;
  isSurplus: boolean;
}

export interface Alert {
  id: string;
  createdAt: string;
  entityCode: string;
  currency: string;
  severity: Exclude<Severity, 'OK'>;
  gap: number;
  projected: number;
  threshold: number;
  forDate: string;
  status: AlertStatus;
  resolvedAt?: string;
  note?: string;
}

export interface ScenarioParams {
  paymentDelayDays: 0 | 1 | 2 | 3 | 4 | 5;
  capexShiftDays: number;
  fxShockPct: Record<string, number>;
  rateShockBps: -200 | -100 | -50 | 0 | 50 | 100 | 200;
  ratingDowngrades: Record<string, RiskRating>;
}

export interface ScenarioResult {
  baseline: ForecastPoint[];
  scenario: ForecastPoint[];
  impact: {
    minGapBaseline: number;
    minGapScenario: number;
    overdraftCostDelta: number;
    fxGainLoss: number;
    interestDelta: number;
    deployableSurplusDelta: number;
  };
}

export type RecommendationAction =
  | 'ACCELERATE_COLLECTIONS'
  | 'DELAY_PAYMENTS'
  | 'INVEST_SURPLUS'
  | 'INTERCOMPANY_TRANSFER'
  | 'CASH_POOLING';

export interface Recommendation {
  id: string;
  action: RecommendationAction;
  title: string;
  rationale: string;
  entityCode: string;
  currency: string;
  expectedImpact: number;
  score: number;
  priority: 1 | 2 | 3;
}

export interface SurplusRow {
  entityCode: string;
  currency: string;
  minProjected: number;
  threshold: number;
  deployable: number;
}

export interface RecommendationsResponse {
  recommendations: Recommendation[];
  surplus: SurplusRow[];
}

export interface ReportSchedule {
  id: string;
  type: 'SOD' | 'EOD';
  enabled: boolean;
  cron: string;
  timezone: string;
  formats: ('PDF' | 'CSV')[];
  recipients: string[];
}

export interface ReportHistoryItem {
  id: string;
  type: 'SOD' | 'EOD';
  format: 'PDF' | 'CSV';
  entityCode: string | null;
  generatedAt: string;
  generatedBy: string;
  sizeBytes: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  entityCodes: string[];
  regions: Region[];
}

export interface ChartSpec {
  kind: 'line' | 'bar' | 'area' | 'donut';
  title: string;
  xKey: string;
  series: { key: string; label: string }[];
  data: Record<string, string | number>[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
  chart?: ChartSpec;
  actionPlan?: Recommendation[];
  sources?: { label: string; ref: string }[];
}

export interface ChatContext {
  entityCode?: string | null;
  currency?: string | null;
  date?: string;
  scenario?: Partial<ScenarioParams> | null;
}

export interface ChatFinal {
  conversationId: string;
  chart?: ChartSpec;
  actionPlan?: Recommendation[];
  sources?: { label: string; ref: string }[];
}

export interface PositionSummary {
  asOf: string;
  reportingCcy: string;
  totalCash: number;
  byCurrency: { currency: string; amount: number; share: number }[];
  byRegion: { region: Region; amount: number; openAlerts: number; entities: number }[];
  openAlerts: { EMERGENCY: number; CRITICAL: number; WARNING: number };
  entitiesInShortfall: number;
  deployableSurplus: number;
  minGap30d: number;
}

export interface IntradayBucket {
  hour: number;
  inflows: number;
  outflows: number;
}

export interface FxRates {
  date: string;
  /** units of reporting currency per 1 unit of currency */
  base: string;
  rates: Record<string, number>;
}

export interface UploadResult {
  uploadId: string;
  rowsParsed: number;
  rowsRejected: number;
  errors: { row: number; field: string; message: string }[];
}

export interface UploadHistoryItem {
  uploadId: string;
  fileName: string;
  uploadedAt: string;
  uploadedBy: string;
  rowsParsed: number;
  rowsRejected: number;
}

export interface BenchmarksResponse {
  mape: number;
  rmse: number;
  perEntity: { entityCode: string; mape: number; rmse: number }[];
  backtest: { date: string; actual: number; forecast: number }[];
  timings: {
    dashboardLoadMs: number;
    forecastMs: number;
    chatMs: number;
    parse10k: number;
    parse50k: number;
    parse100k: number;
  };
}

export interface ApiErrorBody {
  error: { code: string; message: string; details?: unknown };
}
