import type { ZodType } from 'zod';
import { useAuthStore } from '@/stores/authStore';
import { apiErrorSchema } from '@/types/schemas';
import { toast } from '@/components/ui/toast';

const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api';

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

type Query = Record<string, string | number | boolean | null | undefined | string[]>;

function buildUrl(path: string, query?: Query): string {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(query ?? {})) {
    if (v === null || v === undefined || v === '') continue;
    qs.set(k, Array.isArray(v) ? v.join(',') : String(v));
  }
  const s = qs.toString();
  return `${BASE}${path}${s ? `?${s}` : ''}`;
}

function headers(json: boolean): HeadersInit {
  const h: Record<string, string> = {};
  const token = useAuthStore.getState().token;
  if (token) h['X-Session-Token'] = token;
  if (json) h['Content-Type'] = 'application/json';
  return h;
}

async function fail(res: Response): Promise<never> {
  let err = new ApiError(res.status, 'HTTP_ERROR', `Request failed (${res.status})`);
  try {
    const parsed = apiErrorSchema.parse(await res.json());
    err = new ApiError(res.status, parsed.error.code, parsed.error.message, parsed.error.details);
  } catch {
    /* keep generic */
  }
  if (res.status === 401) {
    if (useAuthStore.getState().token) toast('Session expired — please sign in again', 'error');
    useAuthStore.getState().logout();
  } else if (res.status === 403) {
    toast(err.message, 'error');
  }
  throw err;
}

export interface RequestOpts<T> {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  query?: Query;
  body?: unknown;
  form?: FormData;
  schema?: ZodType<T>;
  signal?: AbortSignal;
}

export async function api<T>(path: string, opts: RequestOpts<T> = {}): Promise<T> {
  const res = await fetch(buildUrl(path, opts.query), {
    method: opts.method ?? (opts.body || opts.form ? 'POST' : 'GET'),
    headers: headers(!!opts.body),
    body: opts.form ?? (opts.body ? JSON.stringify(opts.body) : undefined),
    signal: opts.signal,
  });
  if (!res.ok) return fail(res);
  const data: unknown = await res.json();
  return opts.schema ? opts.schema.parse(data) : (data as T);
}

export async function apiBlob(
  path: string,
  opts: { method?: 'GET' | 'POST'; body?: unknown; query?: Query } = {},
): Promise<{ blob: Blob; reportId: string | null }> {
  const res = await fetch(buildUrl(path, opts.query), {
    method: opts.method ?? (opts.body ? 'POST' : 'GET'),
    headers: headers(!!opts.body),
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) return fail(res);
  return { blob: await res.blob(), reportId: res.headers.get('X-Report-Id') };
}

/** Streams an SSE-style response; calls onToken per token and resolves with the final chunk. */
export async function apiStream<F>(
  path: string,
  body: unknown,
  onToken: (t: string) => void,
  signal?: AbortSignal,
): Promise<F | null> {
  const res = await fetch(buildUrl(path), {
    method: 'POST',
    headers: headers(true),
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok) return fail(res);
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = '';
  let final: F | null = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const parts = buf.split('\n\n');
    buf = parts.pop() ?? '';
    for (const p of parts) {
      if (!p.startsWith('data: ')) continue;
      const msg = JSON.parse(p.slice(6)) as { type: string; text?: string };
      if (msg.type === 'token' && msg.text) onToken(msg.text);
      else if (msg.type === 'final') final = msg as unknown as F;
    }
  }
  return final;
}
