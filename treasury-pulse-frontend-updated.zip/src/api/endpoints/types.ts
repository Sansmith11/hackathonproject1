export type { IntradayBucket } from '@/types/domain';
export type ReportingCcyArg = 'USD' | 'EUR' | string;
