import { z } from 'zod';
import { api, apiBlob } from '../client';
import {
  alertSchema,
  benchmarksSchema,
  forecastSchema,
  gapRowSchema,
  recommendationsResponseSchema,
  reportHistorySchema,
  reportScheduleSchema,
  scenarioResultSchema,
  thresholdSchema,
} from '@/types/schemas';
import type { AlertStatus, ReportSchedule, ScenarioParams, Threshold } from '@/types/domain';
import type { SeverityBands } from '@/lib/alerts';

export const forecastApi = {
  get: (entity: string, currency: string) =>
    api('/forecast', { query: { entity, currency }, schema: forecastSchema }),
  gap: (q: { entity?: string | null; currency?: string | null; horizon?: number }) =>
    api('/liquidity-gap', { query: q, schema: z.array(gapRowSchema) }),
  runScenario: (p: ScenarioParams & { entity: string; currency: string }) =>
    api('/scenarios/run', { method: 'POST', body: p, schema: scenarioResultSchema }),
  recommendations: (entity: string | null) =>
    api('/recommendations', { query: { entity }, schema: recommendationsResponseSchema }),
  benchmarks: () => api('/benchmarks', { schema: benchmarksSchema }),
};

export const alertsApi = {
  list: (q: { status?: string | null; severity?: string | null; from?: string | null; to?: string | null }) =>
    api('/alerts', { query: q, schema: z.array(alertSchema) }),
  patch: (id: string, body: { status: AlertStatus; note?: string }) =>
    api(`/alerts/${id}`, { method: 'PATCH', body, schema: alertSchema }),
};

export const thresholdsApi = {
  list: () => api('/thresholds', { schema: z.array(thresholdSchema) }),
  create: (t: Omit<Threshold, 'id'>) => api('/thresholds', { method: 'POST', body: t, schema: thresholdSchema }),
  update: (t: Threshold) => api(`/thresholds/${t.id}`, { method: 'PUT', body: t, schema: thresholdSchema }),
  remove: (id: string) => api(`/thresholds/${id}`, { method: 'DELETE' }),
  bands: () =>
    api('/thresholds/bands', { schema: z.object({ critical: z.number(), warning: z.number() }) }),
  setBands: (b: SeverityBands) =>
    api('/thresholds/bands', {
      method: 'PUT',
      body: b,
      schema: z.object({ critical: z.number(), warning: z.number() }),
    }),
};

export const reportsApi = {
  generate: (body: { type: 'SOD' | 'EOD'; format: 'PDF' | 'CSV'; entity?: string | null }) =>
    apiBlob('/reports/generate', { method: 'POST', body }),
  download: (id: string) => apiBlob(`/reports/${id}/download`),
  history: () => api('/reports/history', { schema: z.array(reportHistorySchema) }),
  schedules: () => api('/reports/schedules', { schema: z.array(reportScheduleSchema) }),
  saveSchedules: (s: ReportSchedule[]) =>
    api('/reports/schedules', { method: 'PUT', body: s, schema: z.array(reportScheduleSchema) }),
};
