import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { AlertStatus, ReportSchedule, ScenarioParams, Threshold, User } from '@/types/domain';
import type { SeverityBands } from '@/lib/alerts';
import { useAuthStore } from '@/stores/authStore';
import { qk } from './queryKeys';
import {
  positionsApi,
  referenceApi,
  txnApi,
  uploadsApi,
  usersApi,
  type TxnQuery,
} from './endpoints/core';
import { alertsApi, forecastApi, reportsApi, thresholdsApi } from './endpoints/analytics';

const useAuthed = () => !!useAuthStore((s) => s.token);

export const useEntities = () =>
  useQuery({ queryKey: qk.entities, queryFn: referenceApi.entities, enabled: useAuthed(), staleTime: 5 * 60_000 });

export const useFxRates = (base: string) =>
  useQuery({ queryKey: qk.fx(base), queryFn: () => referenceApi.fx(base), enabled: useAuthed() });

export const useTransactions = (q: TxnQuery) =>
  useQuery({ queryKey: qk.transactions(q), queryFn: () => txnApi.list(q), placeholderData: keepPreviousData });

export const useDailyPositions = (q: { entity?: string | null; currency?: string | null; from?: string; to?: string }) =>
  useQuery({ queryKey: qk.daily(q), queryFn: () => positionsApi.daily(q) });

export const usePositionSummary = (rep: string) =>
  useQuery({ queryKey: qk.summary(rep), queryFn: () => positionsApi.summary(rep) });

export const useIntraday = (q: { entity?: string | null; currency?: string | null; date?: string }) =>
  useQuery({ queryKey: qk.intraday(q), queryFn: () => positionsApi.intraday(q) });

export const useForecast = (entity: string | null | undefined, currency: string | null | undefined) =>
  useQuery({
    queryKey: qk.forecast(entity ?? '', currency ?? ''),
    queryFn: () => forecastApi.get(entity!, currency!),
    enabled: !!entity && !!currency,
  });

export const useGap = (q: { entity?: string | null; currency?: string | null; horizon?: number }) =>
  useQuery({ queryKey: qk.gap(q), queryFn: () => forecastApi.gap(q) });

export const useThresholds = () => useQuery({ queryKey: qk.thresholds, queryFn: thresholdsApi.list });
export const useBands = () => useQuery({ queryKey: qk.bands, queryFn: thresholdsApi.bands });

/** Everything derived from thresholds must refresh after a change. */
function invalidateDerived(qc: ReturnType<typeof useQueryClient>) {
  for (const key of ['thresholds', 'gap', 'alerts', 'positions', 'recommendations', 'scenario', 'forecast']) {
    void qc.invalidateQueries({ queryKey: [key] });
  }
}

export function useThresholdMutations() {
  const qc = useQueryClient();
  const done = () => invalidateDerived(qc);
  return {
    create: useMutation({ mutationFn: (t: Omit<Threshold, 'id'>) => thresholdsApi.create(t), onSuccess: done }),
    update: useMutation({ mutationFn: (t: Threshold) => thresholdsApi.update(t), onSuccess: done }),
    remove: useMutation({ mutationFn: (id: string) => thresholdsApi.remove(id), onSuccess: done }),
    setBands: useMutation({ mutationFn: (b: SeverityBands) => thresholdsApi.setBands(b), onSuccess: done }),
  };
}

export const useAlerts = (q: { status?: string | null; severity?: string | null; from?: string | null; to?: string | null } = {}, refetchMs?: number) =>
  useQuery({
    queryKey: qk.alerts(q),
    queryFn: () => alertsApi.list(q),
    enabled: useAuthed(),
    refetchInterval: refetchMs,
  });

export function useAlertMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (v: { id: string; status: AlertStatus; note?: string }) =>
      alertsApi.patch(v.id, { status: v.status, note: v.note }),
    onMutate: async (v) => {
      await qc.cancelQueries({ queryKey: qk.alertsRoot });
      const snaps = qc.getQueriesData<import('@/types/domain').Alert[]>({ queryKey: qk.alertsRoot });
      for (const [key, data] of snaps) {
        if (!data) continue;
        qc.setQueryData(
          key,
          data.map((a) => (a.id === v.id ? { ...a, status: v.status, note: v.note ?? a.note } : a)),
        );
      }
      return { snaps };
    },
    onError: (_e, _v, ctx) => ctx?.snaps.forEach(([k, d]) => qc.setQueryData(k, d)),
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: qk.alertsRoot });
      void qc.invalidateQueries({ queryKey: ['positions'] });
    },
  });
}

export const useScenario = (params: ScenarioParams, entity: string | null, currency: string | null, enabled = true) =>
  useQuery({
    queryKey: qk.scenario({ params, entity, currency }),
    queryFn: () => forecastApi.runScenario({ ...params, entity: entity!, currency: currency! }),
    enabled: enabled && !!entity && !!currency,
    placeholderData: keepPreviousData,
  });

export const useRecommendations = (entity: string | null) =>
  useQuery({ queryKey: qk.recommendations(entity), queryFn: () => forecastApi.recommendations(entity) });

export const useReportHistory = () => useQuery({ queryKey: qk.reportHistory, queryFn: reportsApi.history });
export const useSchedules = () => useQuery({ queryKey: qk.schedules, queryFn: reportsApi.schedules });

export function useSaveSchedules() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (s: ReportSchedule[]) => reportsApi.saveSchedules(s),
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.schedules }),
  });
}

export const useUsers = () => useQuery({ queryKey: qk.users, queryFn: usersApi.list });

export function useUserMutations() {
  const qc = useQueryClient();
  const done = () => qc.invalidateQueries({ queryKey: qk.users });
  return {
    create: useMutation({ mutationFn: (u: Omit<User, 'id'>) => usersApi.create(u), onSuccess: done }),
    update: useMutation({ mutationFn: (u: User) => usersApi.update(u), onSuccess: done }),
  };
}

export const useUploads = () => useQuery({ queryKey: qk.uploads, queryFn: uploadsApi.list });
export const useBenchmarks = () => useQuery({ queryKey: qk.benchmarks, queryFn: forecastApi.benchmarks });
