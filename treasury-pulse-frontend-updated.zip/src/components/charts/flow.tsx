import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, Tooltip, XAxis, YAxis } from 'recharts';
import type { ChartSpec, IntradayBucket } from '@/types/domain';
import { formatMoney, formatPct } from '@/lib/format';
import { axisTick, ChartFrame, COLORS, compactTick, MoneyTooltip, SERIES_COLORS } from './common';

export function InflowOutflowAreaChart({
  buckets,
  currency,
  loading,
}: {
  buckets?: IntradayBucket[];
  currency: string;
  loading?: boolean;
}) {
  const data = (buckets ?? []).map((b) => ({ ...b, label: `${String(b.hour).padStart(2, '0')}:00` }));
  return (
    <ChartFrame
      title={`Hourly inflows and outflows in ${currency}`}
      description="Stacked hourly cash movements"
      loading={loading}
      empty={!loading && data.length === 0}
      height={260}
    >
      <AreaChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="label" tick={axisTick} interval={2} />
        <YAxis tick={axisTick} tickFormatter={compactTick} width={52} />
        <Tooltip content={<MoneyTooltip currency={currency} />} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" stackId="f" dataKey="inflows" name="Inflows" stroke={COLORS.ok} fill={COLORS.ok} fillOpacity={0.35} isAnimationActive={false} />
        <Area type="monotone" stackId="f" dataKey="outflows" name="Outflows" stroke={COLORS.crit} fill={COLORS.crit} fillOpacity={0.3} isAnimationActive={false} />
      </AreaChart>
    </ChartFrame>
  );
}

export function CurrencyDonut({
  data,
  reportingCcy,
  onSelect,
  selected,
  loading,
}: {
  data?: { currency: string; amount: number; share: number }[];
  reportingCcy: string;
  onSelect?: (currency: string) => void;
  selected?: string | null;
  loading?: boolean;
}) {
  const rows = data ?? [];
  return (
    <ChartFrame
      title={`Cash position by currency in ${reportingCcy}`}
      description="Share of total cash by currency"
      loading={loading}
      empty={!loading && rows.length === 0}
      height={260}
    >
      <PieChart>
        <Pie
          data={rows}
          dataKey="amount"
          nameKey="currency"
          innerRadius={55}
          outerRadius={95}
          paddingAngle={1}
          isAnimationActive={false}
          label={(e: unknown) => {
            const d = e as { currency: string; share: number };
            return d.share > 0.04 ? `${d.currency} ${formatPct(d.share * 100, 0)}` : '';
          }}
          labelLine={false}
          onClick={(e: unknown) => {
            const c = (e as { currency?: string }).currency;
            if (c) onSelect?.(c);
          }}
          cursor="pointer"
        >
          {rows.map((r, i) => (
            <Cell
              key={r.currency}
              fill={SERIES_COLORS[i % SERIES_COLORS.length]}
              fillOpacity={selected && selected !== r.currency ? 0.35 : 1}
              stroke={COLORS.surface}
            />
          ))}
        </Pie>
        <Tooltip formatter={(v) => formatMoney(Number(v), reportingCcy)} />
      </PieChart>
    </ChartFrame>
  );
}

export function Sparkline({ values, width = 90, height = 26 }: { values: number[]; width?: number; height?: number }) {
  if (values.length < 2) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const pts = values.map((v, i) => `${(i / (values.length - 1)) * width},${height - 2 - ((v - min) / span) * (height - 4)}`).join(' ');
  const up = values[values.length - 1] >= values[0];
  return (
    <svg width={width} height={height} role="img" aria-label={up ? 'Trending up' : 'Trending down'}>
      <polyline points={pts} fill="none" stroke={up ? COLORS.ok : COLORS.crit} strokeWidth={1.5} />
    </svg>
  );
}

export function ChatChart({ spec }: { spec: ChartSpec }) {
  const colors = SERIES_COLORS;
  if (spec.kind === 'donut') {
    const key = spec.series[0].key;
    return (
      <ChartFrame title={spec.title} height={220}>
        <PieChart>
          <Pie data={spec.data} dataKey={key} nameKey={spec.xKey} innerRadius={45} outerRadius={80} isAnimationActive={false}>
            {spec.data.map((_, i) => (
              <Cell key={i} fill={colors[i % colors.length]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ChartFrame>
    );
  }
  const common = (
    <>
      <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
      <XAxis dataKey={spec.xKey} tick={axisTick} minTickGap={20} />
      <YAxis tick={axisTick} tickFormatter={compactTick} width={52} />
      <Tooltip />
      <Legend wrapperStyle={{ fontSize: 12 }} />
    </>
  );
  return (
    <div>
      <div className="mb-1 text-xs font-medium">{spec.title}</div>
      <ChartFrame title={spec.title} height={220}>
        {spec.kind === 'bar' ? (
          <BarChart data={spec.data}>
            {common}
            {spec.series.map((s, i) => (
              <Bar key={s.key} dataKey={s.key} name={s.label} fill={colors[i % colors.length]} isAnimationActive={false} />
            ))}
          </BarChart>
        ) : spec.kind === 'area' ? (
          <AreaChart data={spec.data}>
            {common}
            {spec.series.map((s, i) => (
              <Area key={s.key} dataKey={s.key} name={s.label} stroke={colors[i % colors.length]} fill={colors[i % colors.length]} fillOpacity={0.25} isAnimationActive={false} />
            ))}
          </AreaChart>
        ) : (
          <LineChart data={spec.data}>
            {common}
            {spec.series.map((s, i) => (
              <Line key={s.key} dataKey={s.key} name={s.label} stroke={colors[i % colors.length]} dot={false} strokeWidth={2} isAnimationActive={false} />
            ))}
          </LineChart>
        )}
      </ChartFrame>
    </div>
  );
}
