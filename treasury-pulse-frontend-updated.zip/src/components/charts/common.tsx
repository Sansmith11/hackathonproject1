import type { ReactNode } from 'react';
import { ResponsiveContainer } from 'recharts';
import { formatCompact, formatDate, formatMoney } from '@/lib/format';
import { EmptyState } from '@/components/ui/feedback';
import { Skeleton } from '@/components/ui/primitives';

export const COLORS = {
  accent: 'hsl(var(--accent))',
  ok: 'hsl(var(--band-ok))',
  warn: 'hsl(var(--band-warn))',
  crit: 'hsl(var(--band-crit))',
  muted: 'hsl(var(--muted-foreground))',
  grid: 'hsl(var(--border))',
  surface: 'hsl(var(--surface))',
};

export const SERIES_COLORS = ['hsl(var(--accent))', 'hsl(var(--band-warn))', 'hsl(var(--band-ok))', '#8b5cf6', '#14b8a6', '#ec4899'];

export function ChartFrame({
  title,
  description,
  height = 280,
  loading,
  empty,
  children,
}: {
  title: string;
  description?: string;
  height?: number;
  loading?: boolean;
  empty?: boolean;
  children: ReactNode;
}) {
  if (loading)
    return (
      <div style={{ height }} className="w-full">
        <Skeleton className="h-full w-full" />
      </div>
    );
  if (empty) return <EmptyState title="No data to chart yet" hint="Adjust the filters or upload transactions." />;
  return (
    <div role="img" aria-label={`${title}. ${description ?? ''}`} style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        {children as React.ReactElement}
      </ResponsiveContainer>
    </div>
  );
}

export const axisTick = { fontSize: 11, fill: COLORS.muted };
export const compactTick = (v: number) => formatCompact(v);
export const dateTick = (d: string) => formatDate(d, 'dd MMM');

interface TipEntry {
  name?: string | number;
  value?: number | string | [number, number];
  color?: string;
  dataKey?: string | number;
}

export function MoneyTooltip({
  active,
  payload,
  label,
  currency,
  hide = [],
}: {
  active?: boolean;
  payload?: TipEntry[];
  label?: string | number;
  currency: string;
  hide?: string[];
}) {
  if (!active || !payload?.length) return null;
  const rows = payload.filter((p) => p.value !== undefined && !hide.includes(String(p.dataKey)));
  return (
    <div className="rounded-md border border-border bg-surface px-3 py-2 text-xs shadow-md">
      <div className="mb-1 font-medium">{typeof label === 'string' && /^\d{4}-/.test(label) ? formatDate(label) : label}</div>
      {rows.map((p) => (
        <div key={String(p.dataKey)} className="flex items-center justify-between gap-4">
          <span className="flex items-center gap-1.5 text-muted-foreground">
            <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
            {p.name}
          </span>
          <span className="num">
            {Array.isArray(p.value)
              ? `${formatMoney(p.value[0], currency, { compact: true })} – ${formatMoney(p.value[1], currency, { compact: true })}`
              : formatMoney(Number(p.value), currency)}
          </span>
        </div>
      ))}
    </div>
  );
}
