import { useMemo } from 'react';
import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  LineChart,
  ReferenceArea,
  ReferenceLine,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { DailyPosition, Forecast, ForecastPoint, GapRow } from '@/types/domain';
import { DEFAULT_BANDS, SEVERITY_META, type SeverityBands } from '@/lib/alerts';
import { formatDate } from '@/lib/format';
import { axisTick, ChartFrame, COLORS, compactTick, dateTick, MoneyTooltip } from './common';

export function CashPositionChart({
  rows,
  currency,
  days = 90,
  loading,
}: {
  rows: DailyPosition[] | undefined;
  currency: string;
  days?: number;
  loading?: boolean;
}) {
  const data = useMemo(() => (rows ?? []).slice(-days), [rows, days]);
  return (
    <ChartFrame
      title={`Daily closing cash position in ${currency}`}
      description={`Last ${days} days`}
      loading={loading}
      empty={!loading && data.length === 0}
    >
      <LineChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="date" tick={axisTick} tickFormatter={dateTick} minTickGap={40} />
        <YAxis tick={axisTick} tickFormatter={compactTick} width={56} domain={['auto', 'auto']} />
        <Tooltip content={<MoneyTooltip currency={currency} />} />
        <Line type="monotone" dataKey="closingBalance" name="Closing balance" stroke={COLORS.accent} strokeWidth={2} dot={false} />
      </LineChart>
    </ChartFrame>
  );
}

export function ForecastChart({
  history,
  forecast,
  threshold,
  show80 = true,
  show95 = true,
  historyDays = 30,
  height = 300,
  loading,
}: {
  history?: DailyPosition[];
  forecast?: Forecast;
  threshold?: number | null;
  show80?: boolean;
  show95?: boolean;
  historyDays?: number;
  height?: number;
  loading?: boolean;
}) {
  const { data, today } = useMemo(() => {
    const hist = (history ?? []).slice(-historyDays);
    const today = hist.at(-1)?.date;
    const rows: Record<string, unknown>[] = hist.map((h) => ({ date: h.date, actual: h.closingBalance }));
    if (today && rows.length) rows[rows.length - 1].projected = hist.at(-1)!.closingBalance;
    for (const p of forecast?.points ?? []) {
      rows.push({
        date: p.date,
        projected: p.projected,
        ci80: [p.lower80, p.upper80],
        ci95: [p.lower95, p.upper95],
      });
    }
    return { data: rows, today };
  }, [history, forecast, historyDays]);

  const currency = forecast?.currency ?? history?.[0]?.currency ?? '';
  return (
    <ChartFrame
      title={`Cash forecast for ${forecast?.entityCode ?? ''} ${currency}`}
      description="Actual and projected balance with 80% and 95% confidence bands"
      loading={loading}
      empty={!loading && data.length === 0}
      height={height}
    >
      <ComposedChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="date" tick={axisTick} tickFormatter={dateTick} minTickGap={36} />
        <YAxis tick={axisTick} tickFormatter={compactTick} width={56} domain={['auto', 'auto']} />
        <Tooltip content={<MoneyTooltip currency={currency} />} />
        {show95 && <Area dataKey="ci95" name="95% CI" stroke="none" fill={COLORS.accent} fillOpacity={0.12} isAnimationActive={false} />}
        {show80 && <Area dataKey="ci80" name="80% CI" stroke="none" fill={COLORS.accent} fillOpacity={0.22} isAnimationActive={false} />}
        {threshold != null && (
          <ReferenceLine y={threshold} stroke={COLORS.crit} strokeDasharray="4 4" label={{ value: 'Threshold', fontSize: 11, fill: COLORS.crit, position: 'insideTopLeft' }} />
        )}
        {today && <ReferenceLine x={today} stroke={COLORS.muted} label={{ value: 'Today', fontSize: 11, fill: COLORS.muted, position: 'top' }} />}
        <Line dataKey="actual" name="Actual" stroke={COLORS.accent} strokeWidth={2} dot={false} connectNulls isAnimationActive={false} />
        <Line dataKey="projected" name="Projected" stroke={COLORS.accent} strokeWidth={2} strokeDasharray="6 4" dot={false} connectNulls isAnimationActive={false} />
      </ComposedChart>
    </ChartFrame>
  );
}

export function LiquidityGapChart({
  rows,
  bands = DEFAULT_BANDS,
  height = 300,
  loading,
}: {
  rows: GapRow[] | undefined;
  bands?: SeverityBands;
  height?: number;
  loading?: boolean;
}) {
  const data = useMemo(() => rows ?? [], [rows]);
  const currency = data[0]?.currency ?? '';
  const threshold = data[0]?.threshold ?? 0;
  const { lo, hi } = useMemo(() => {
    const vals = data.map((r) => r.projected).concat(threshold);
    const mn = Math.min(0, ...vals);
    const mx = Math.max(...vals, threshold * (1 + bands.warning / 100) * 1.05);
    return { lo: mn < 0 ? mn * 1.1 : 0, hi: mx };
  }, [data, threshold, bands.warning]);
  const warnTop = threshold * (1 + bands.warning / 100);
  const critTop = threshold * (1 + bands.critical / 100);

  return (
    <ChartFrame
      title={`Projected liquidity vs threshold for ${data[0]?.entityCode ?? ''} ${currency}`}
      description="Alert bands: green at least 10% above threshold, amber 5 to 10%, red below 5% or negative"
      loading={loading}
      empty={!loading && data.length === 0}
      height={height}
    >
      <ComposedChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="date" tick={axisTick} tickFormatter={dateTick} minTickGap={30} />
        <YAxis tick={axisTick} tickFormatter={compactTick} width={56} domain={[lo, hi]} allowDataOverflow />
        <ReferenceArea y1={warnTop} y2={hi} fill={COLORS.ok} fillOpacity={0.1} ifOverflow="hidden" />
        <ReferenceArea y1={critTop} y2={warnTop} fill={COLORS.warn} fillOpacity={0.14} ifOverflow="hidden" />
        <ReferenceArea y1={lo} y2={critTop} fill={COLORS.crit} fillOpacity={0.1} ifOverflow="hidden" />
        <ReferenceLine y={threshold} stroke={COLORS.crit} strokeDasharray="4 4" label={{ value: 'Threshold', fontSize: 11, fill: COLORS.crit, position: 'insideTopLeft' }} />
        <Tooltip content={<MoneyTooltip currency={currency} />} />
        <Line
          dataKey="projected"
          name="Projected"
          stroke={COLORS.accent}
          strokeWidth={2}
          isAnimationActive={false}
          dot={(p: { cx?: number; cy?: number; payload?: GapRow; index?: number }) => {
            const sev = p.payload?.severity;
            if (!sev || sev === 'OK' || p.cx === undefined || p.cy === undefined)
              return <g key={p.index} />;
            return <circle key={p.index} cx={p.cx} cy={p.cy} r={5} fill={SEVERITY_META[sev].hex} stroke="#fff" strokeWidth={1.5} />;
          }}
        />
      </ComposedChart>
    </ChartFrame>
  );
}

export function ScenarioCompareChart({
  baseline,
  scenario,
  currency,
  threshold,
  height = 320,
  loading,
}: {
  baseline?: ForecastPoint[];
  scenario?: ForecastPoint[];
  currency: string;
  threshold?: number | null;
  height?: number;
  loading?: boolean;
}) {
  const data = useMemo(
    () =>
      (baseline ?? []).map((b, i) => ({
        date: b.date,
        baseline: b.projected,
        scenario: scenario?.[i]?.projected ?? b.projected,
        delta: (scenario?.[i]?.projected ?? b.projected) - b.projected,
      })),
    [baseline, scenario],
  );
  return (
    <ChartFrame
      title={`Baseline vs scenario projected balance in ${currency}`}
      description="Overlay of baseline and scenario with daily delta bars"
      loading={loading}
      empty={!loading && data.length === 0}
      height={height}
    >
      <ComposedChart data={data} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
        <CartesianGrid stroke={COLORS.grid} strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="date" tick={axisTick} tickFormatter={dateTick} minTickGap={30} />
        <YAxis yAxisId="bal" tick={axisTick} tickFormatter={compactTick} width={56} domain={['auto', 'auto']} />
        <YAxis yAxisId="delta" orientation="right" tick={axisTick} tickFormatter={compactTick} width={48} />
        <Tooltip content={<MoneyTooltip currency={currency} />} />
        {threshold != null && <ReferenceLine yAxisId="bal" y={threshold} stroke={COLORS.crit} strokeDasharray="4 4" />}
        <Bar yAxisId="delta" dataKey="delta" name="Delta" fill={COLORS.warn} fillOpacity={0.5} isAnimationActive={false} />
        <Line yAxisId="bal" dataKey="baseline" name="Baseline" stroke={COLORS.muted} strokeWidth={2} dot={false} isAnimationActive={false} />
        <Line yAxisId="bal" dataKey="scenario" name="Scenario" stroke={COLORS.accent} strokeWidth={2.5} dot={false} isAnimationActive={false} />
      </ComposedChart>
    </ChartFrame>
  );
}

export { formatDate };

