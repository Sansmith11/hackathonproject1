import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { can, type Action } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import { Forbidden403 } from '@/components/ui/feedback';

export function RoleGuard({ action }: { action?: Action }) {
  const user = useAuthStore((s) => s.user);
  const loc = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname + loc.search }} />;
  if (action && !can(user, action)) return <Forbidden403 />;
  return <Outlet />;
}
