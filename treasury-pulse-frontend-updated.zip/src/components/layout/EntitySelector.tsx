import { Building2, ChevronDown, Globe2 } from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useEntities } from '@/api/hooks';
import { useLatestPositions } from '@/hooks/useFocus';
import { cn } from '@/lib/cn';
import { can } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import { useFilterStore } from '@/stores/filterStore';
import type { Region } from '@/types/domain';

/** Hierarchical Region → Entity tree plus currency multi-select, scoped to the user. */
export function EntitySelector() {
  const user = useAuthStore((s) => s.user);
  const entities = useEntities();
  const latest = useLatestPositions();
  const { region, entity, currencies, set } = useFilterStore();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const tree = useMemo(() => {
    const m = new Map<Region, { code: string; city: string }[]>();
    for (const e of entities.data ?? []) m.set(e.region, [...(m.get(e.region) ?? []), { code: e.code, city: e.city }]);
    return [...m];
  }, [entities.data]);

  const available = useMemo(() => {
    const pool = latest.data.filter((p) => (entity ? p.entityCode === entity : region ? entities.data?.find((e) => e.code === p.entityCode)?.region === region : true));
    return [...new Set(pool.map((p) => p.currency))].sort();
  }, [latest.data, entity, region, entities.data]);

  const regionView = can(user, 'region_view');
  const label = entity
    ? `${entity}`
    : region
      ? `${region} (all entities)`
      : 'All in scope';

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        className="flex h-9 items-center gap-2 rounded-md border border-border bg-surface px-3 text-sm hover:bg-muted"
      >
        <Building2 className="h-4 w-4 text-muted-foreground" />
        <span className="font-medium">{label}</span>
        {currencies.length > 0 && <span className="num text-xs text-muted-foreground">{currencies.join(', ')}</span>}
        <ChevronDown className="h-4 w-4 text-muted-foreground" />
      </button>
      {open && (
        <div className="absolute left-0 top-11 z-50 w-80 rounded-lg border border-border bg-surface p-3 shadow-xl">
          <button
            className={cn('mb-2 flex w-full items-center gap-2 rounded px-2 py-1.5 text-left hover:bg-muted', !entity && !region && 'bg-muted')}
            onClick={() => set({ region: null, entity: null, currencies: [] })}
          >
            <Globe2 className="h-4 w-4" /> All in scope
          </button>
          {tree.map(([r, list]) => (
            <div key={r} className="mb-2">
              <button
                disabled={!regionView}
                title={regionView ? undefined : 'Region-level view requires Treasury Manager or Admin'}
                onClick={() => {
                  set({ region: r, entity: null, currencies: [] });
                  setOpen(false);
                }}
                className={cn(
                  'w-full rounded px-2 py-1 text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground',
                  regionView && 'hover:bg-muted',
                  region === r && !entity && 'bg-muted text-foreground',
                )}
              >
                {r}
              </button>
              <ul>
                {list.map((e) => (
                  <li key={e.code}>
                    <button
                      onClick={() => {
                        set({ region: null, entity: e.code, currencies: [] });
                      }}
                      className={cn('flex w-full items-center justify-between rounded px-2 py-1.5 pl-5 text-left hover:bg-muted', entity === e.code && 'bg-muted font-medium')}
                    >
                      <span>{e.city}</span>
                      <span className="num text-xs text-muted-foreground">{e.code}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div className="border-t border-border pt-2">
            <div className="mb-1.5 text-xs font-medium text-muted-foreground">Currencies</div>
            <div className="flex flex-wrap gap-1.5">
              {available.map((c) => {
                const on = currencies.includes(c);
                return (
                  <button
                    key={c}
                    aria-pressed={on}
                    onClick={() => set({ currencies: on ? currencies.filter((x) => x !== c) : [...currencies, c] })}
                    className={cn('num rounded-full border border-border px-2 py-0.5 text-xs', on ? 'border-accent bg-accent/15 text-accent' : 'hover:bg-muted')}
                  >
                    {c}
                  </button>
                );
              })}
              {available.length === 0 && <span className="text-xs text-muted-foreground">Loading…</span>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
