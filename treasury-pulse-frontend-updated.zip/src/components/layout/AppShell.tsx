import { useQueryClient } from '@tanstack/react-query';
import {
  Activity,
  BarChart3,
  Bell,
  Bot,
  CalendarClock,
  ChevronsLeft,
  ChevronsRight,
  FileText,
  Gauge,
  Lightbulb,
  LineChart,
  LogOut,
  Menu,
  MessageSquare,
  Moon,
  RotateCcw,
  Settings2,
  Sliders,
  Sun,
  Table2,
  Timer,
  Upload,
  Users,
  Siren,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useAlerts } from '@/api/hooks';
import { cn } from '@/lib/cn';
import { can, ROLE_LABEL, whyDenied, type Action } from '@/lib/permissions';
import { useAuthStore } from '@/stores/authStore';
import { filtersToSearch, searchToFilters, useFilterStore } from '@/stores/filterStore';
import { applyTheme, useUiStore } from '@/stores/uiStore';
import { Badge, Button, Select } from '@/components/ui/primitives';
import { toast } from '@/components/ui/toast';
import { ChatDrawer } from '@/features/chat/ChatDrawer';
import { EntitySelector } from './EntitySelector';
import { resetStore } from '@/mocks/data/store';

interface NavItem {
  to: string;
  label: string;
  icon: ReactNode;
  action?: Action;
}

const NAV: { group: string; items: NavItem[] }[] = [
  {
    group: 'Monitor',
    items: [
      { to: '/dashboard', label: 'Dashboard', icon: <Gauge className="h-4 w-4" /> },
      { to: '/transactions', label: 'Transactions', icon: <Table2 className="h-4 w-4" /> },
      { to: '/alerts', label: 'Alerts', icon: <Siren className="h-4 w-4" /> },
    ],
  },
  {
    group: 'Analyze',
    items: [
      { to: '/forecast', label: 'Forecast', icon: <LineChart className="h-4 w-4" /> },
      { to: '/liquidity', label: 'Liquidity gap', icon: <Activity className="h-4 w-4" /> },
      { to: '/what-if', label: 'What-if', icon: <Sliders className="h-4 w-4" />, action: 'what_if' },
      { to: '/benchmarks', label: 'Benchmarks', icon: <Timer className="h-4 w-4" /> },
    ],
  },
  {
    group: 'Act',
    items: [
      { to: '/upload', label: 'Upload', icon: <Upload className="h-4 w-4" />, action: 'upload' },
      { to: '/recommendations', label: 'Recommendations', icon: <Lightbulb className="h-4 w-4" /> },
      { to: '/reports', label: 'Reports', icon: <FileText className="h-4 w-4" />, action: 'reports' },
      { to: '/chat', label: 'Assistant', icon: <MessageSquare className="h-4 w-4" />, action: 'chat' },
    ],
  },
  {
    group: 'Admin',
    items: [
      { to: '/admin/users', label: 'Users', icon: <Users className="h-4 w-4" />, action: 'admin_users' },
      { to: '/admin/thresholds', label: 'Alert matrix', icon: <Settings2 className="h-4 w-4" />, action: 'admin_thresholds' },
      { to: '/admin/schedules', label: 'Schedules', icon: <CalendarClock className="h-4 w-4" />, action: 'admin_schedules' },
    ],
  },
];

function Sidebar() {
  const user = useAuthStore((s) => s.user);
  const { sidebarCollapsed, toggleSidebar } = useUiStore();
  const { search } = useLocation();
  return (
    <aside
      className={cn(
        'no-print flex shrink-0 flex-col border-r border-border bg-surface transition-[width]',
        sidebarCollapsed ? 'w-14' : 'w-56',
      )}
    >
      <div className="flex h-14 items-center gap-2 border-b border-border px-3.5">
        <BarChart3 className="h-5 w-5 shrink-0 text-accent" />
        {!sidebarCollapsed && <span className="font-semibold tracking-tight">Treasury Pulse</span>}
      </div>
      <nav className="flex-1 overflow-y-auto p-2" aria-label="Main">
        {NAV.map((g) => {
          const items = g.items.filter((i) => !i.action || can(user, i.action));
          if (!items.length) return null;
          return (
            <div key={g.group} className="mb-3">
              {!sidebarCollapsed && (
                <div className="px-2 pb-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{g.group}</div>
              )}
              {items.map((i) => (
                <NavLink
                  key={i.to}
                  to={{ pathname: i.to, search }}
                  title={sidebarCollapsed ? i.label : undefined}
                  className={({ isActive }) =>
                    cn(
                      'mb-0.5 flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm hover:bg-muted',
                      isActive && 'bg-accent/10 font-medium text-accent',
                    )
                  }
                >
                  {i.icon}
                  {!sidebarCollapsed && i.label}
                </NavLink>
              ))}
            </div>
          );
        })}
      </nav>
      <button
        onClick={toggleSidebar}
        aria-label={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        className="flex h-10 items-center justify-center border-t border-border text-muted-foreground hover:bg-muted"
      >
        {sidebarCollapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
      </button>
    </aside>
  );
}

function AlertBell() {
  const alerts = useAlerts({ status: 'OPEN' }, 60_000);
  const n = alerts.data?.length ?? 0;
  return (
    <Link to="/alerts" aria-label={`${n} open alerts`} className="relative rounded-md p-2 hover:bg-muted">
      <Bell className="h-5 w-5" />
      {n > 0 && (
        <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-crit px-1 text-[10px] font-semibold text-white">
          {n}
        </span>
      )}
    </Link>
  );
}

function AlertBanner() {
  const alerts = useAlerts({ status: 'OPEN' }, 60_000);
  const qc = useQueryClient();
  const hot = (alerts.data ?? []).filter((a) => a.severity === 'EMERGENCY' || a.severity === 'CRITICAL');
  if (hot.length === 0) return null;
  const top = [...hot].sort((a, b) => a.gap - b.gap)[0];
  return (
    <div role="alert" className="no-print flex flex-wrap items-center gap-3 border-b border-crit/30 bg-crit/10 px-5 py-2 text-sm text-crit">
      <Siren className="h-4 w-4 shrink-0" aria-hidden />
      <span className="font-medium">
        {hot.length} open {hot.length === 1 ? 'alert' : 'alerts'} need attention
      </span>
      <span className="text-foreground/80">
        Worst: {top.entityCode} {top.currency} — {top.severity.toLowerCase()} on {top.forDate}
      </span>
      <Link to="/alerts" className="font-medium underline">
        Review
      </Link>
      <button
        className="ml-auto text-xs underline"
        onClick={() => {
          void qc.invalidateQueries({ queryKey: ['alerts'] });
          toast('Evaluation re-run against current thresholds', 'success');
        }}
      >
        Run evaluation now
      </button>
    </div>
  );
}

function ThemeToggle() {
  const { theme, setTheme } = useUiStore();
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);
  const dark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  return (
    <button
      aria-label="Toggle theme"
      className="rounded-md p-2 hover:bg-muted"
      onClick={() => setTheme(dark ? 'light' : 'dark')}
    >
      {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </button>
  );
}

function UserMenu() {
  const { user, logout } = useAuthStore();
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();
  const nav = useNavigate();
  const set = useFilterStore((s) => s.set);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  if (!user) return null;
  const mocks = import.meta.env.VITE_USE_MOCKS === 'true';
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-2 rounded-md px-2 py-1 hover:bg-muted">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground">
          {user.name
            .split(' ')
            .map((p) => p[0])
            .join('')
            .slice(0, 2)}
        </span>
        <span className="hidden text-left leading-tight md:block">
          <span className="block text-xs font-medium">{user.name}</span>
          <span className="block text-[11px] text-muted-foreground">{ROLE_LABEL[user.role]}</span>
        </span>
      </button>
      {open && (
        <div className="absolute right-0 top-11 z-50 w-64 rounded-lg border border-border bg-surface p-2 shadow-xl">
          <div className="px-2 py-1.5">
            <div className="text-sm font-medium">{user.email}</div>
            <Badge tone="accent" className="mt-1">
              {ROLE_LABEL[user.role]}
            </Badge>
          </div>
          {mocks && (
            <button
              className="mt-1 flex w-full items-center gap-2 rounded px-2 py-2 text-left text-sm hover:bg-muted"
              onClick={() => {
                resetStore();
                void qc.invalidateQueries();
                set({ region: null, entity: 'PARI', currencies: ['EUR'] });
                setOpen(false);
                nav('/dashboard');
                toast('Demo mode: data reset. Start with the EUR shortfall at Paris.', 'success');
              }}
            >
              <RotateCcw className="h-4 w-4" /> Demo mode: reset &amp; replay story
            </button>
          )}
          <button
            className="flex w-full items-center gap-2 rounded px-2 py-2 text-left text-sm hover:bg-muted"
            onClick={() => {
              logout();
              qc.clear();
              nav('/login');
            }}
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      )}
    </div>
  );
}

function TopBar() {
  const { from, to, reportingCcy, set } = useFilterStore();
  const toggle = useUiStore((s) => s.toggleSidebar);
  return (
    <header className="no-print flex h-14 shrink-0 items-center gap-3 border-b border-border bg-surface px-4">
      <button className="rounded-md p-2 hover:bg-muted lg:hidden" onClick={toggle} aria-label="Toggle navigation">
        <Menu className="h-5 w-5" />
      </button>
      <EntitySelector />
      <div className="hidden items-center gap-1.5 md:flex">
        <input
          type="date"
          aria-label="From date"
          value={from ?? ''}
          onChange={(e) => set({ from: e.target.value || null })}
          className="h-9 rounded-md border border-border bg-surface px-2 text-xs"
        />
        <span className="text-muted-foreground">–</span>
        <input
          type="date"
          aria-label="To date"
          value={to ?? ''}
          onChange={(e) => set({ to: e.target.value || null })}
          className="h-9 rounded-md border border-border bg-surface px-2 text-xs"
        />
      </div>
      <div className="ml-auto flex items-center gap-1">
        <Select aria-label="Reporting currency" value={reportingCcy} onChange={(e) => set({ reportingCcy: e.target.value as 'USD' | 'EUR' })} className="w-20">
          <option>USD</option>
          <option>EUR</option>
        </Select>
        <AlertBell />
        <ThemeToggle />
        <UserMenu />
      </div>
    </header>
  );
}

/** Keeps filterStore and the URL query string mirrored so any view is shareable. */
function useFilterUrlSync() {
  const [params, setParams] = useSearchParams();
  const { set, region, entity, currencies, from, to, reportingCcy } = useFilterStore();
  const prev = useRef<{ url: string; store: string } | null>(null);

  const storeStr = useMemo(
    () => filtersToSearch({ region, entity, currencies, from, to, reportingCcy }).toString(),
    [region, entity, currencies, from, to, reportingCcy],
  );
  const urlStr = useMemo(() => {
    const p = new URLSearchParams();
    for (const k of ['region', 'entity', 'ccy', 'from', 'to', 'rep']) {
      const v = params.get(k);
      if (v) p.set(k, v);
    }
    return p.toString();
  }, [params]);

  useEffect(() => {
    const last = prev.current;
    prev.current = { url: urlStr, store: storeStr };
    if (urlStr === storeStr) return;
    // First run, or the URL changed (deep link / in-app link): URL wins.
    if (!last || urlStr !== last.url) {
      set({ region: null, entity: null, currencies: [], from: null, to: null, reportingCcy: 'USD', ...searchToFilters(new URLSearchParams(urlStr)) });
      return;
    }
    // The store changed: mirror to the URL.
    setParams(
      (prevParams) => {
        const next = new URLSearchParams(prevParams);
        for (const k of ['region', 'entity', 'ccy', 'from', 'to', 'rep']) next.delete(k);
        new URLSearchParams(storeStr).forEach((v, k) => next.set(k, v));
        return next;
      },
      { replace: true },
    );
  }, [urlStr, storeStr, set, setParams]);
}

export function AppShell() {
  useFilterUrlSync();
  const user = useAuthStore((s) => s.user);
  const openChat = useUiStore((s) => s.openChat);
  const { pathname } = useLocation();
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />
        <AlertBanner />
        <main className="min-h-0 flex-1 overflow-y-auto p-5">
          <Outlet />
        </main>
      </div>
      {can(user, 'chat') && pathname !== '/chat' && (
        <>
          <Button
            variant="primary"
            className="no-print fixed bottom-5 right-5 z-40 h-12 w-12 rounded-full shadow-lg"
            aria-label="Open assistant"
            onClick={() => openChat()}
            disabledReason={undefined}
          >
            <Bot className="h-5 w-5" />
          </Button>
          <ChatDrawer />
        </>
      )}
    </div>
  );
}

export { whyDenied };

