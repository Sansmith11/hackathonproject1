import { useEntities } from '@/api/hooks';
import { Select } from '@/components/ui/primitives';
import { useFocus } from '@/hooks/useFocus';
import { useFilterStore } from '@/stores/filterStore';

/** Page-level entity + currency picker bound to the global filters. */
export function PairPicker() {
  const entities = useEntities();
  const focus = useFocus();
  const set = useFilterStore((s) => s.set);
  return (
    <div className="flex items-center gap-2">
      <Select
        aria-label="Entity"
        value={focus.entity ?? ''}
        onChange={(e) => set({ entity: e.target.value, region: null, currencies: [] })}
      >
        {(entities.data ?? []).map((e) => (
          <option key={e.code} value={e.code}>
            {e.code} · {e.city}
          </option>
        ))}
      </Select>
      <Select
        aria-label="Currency"
        value={focus.currency ?? ''}
        onChange={(e) => set({ currencies: [e.target.value], entity: focus.entity })}
      >
        {focus.currencies.map((c) => (
          <option key={c}>{c}</option>
        ))}
      </Select>
    </div>
  );
}
