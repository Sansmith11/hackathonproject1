import { AlertOctagon, AlertTriangle, CheckCircle2, Siren } from 'lucide-react';
import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { SEVERITY_META } from '@/lib/alerts';
import { formatMoney } from '@/lib/format';
import type { Severity } from '@/types/domain';
import { Badge, Card, Skeleton } from './primitives';
import { Tooltip } from './overlay';

const ICONS = { OK: CheckCircle2, WARNING: AlertTriangle, CRITICAL: AlertOctagon, EMERGENCY: Siren };

/** Severity is never colour-only: icon + text. */
export function SeverityChip({ severity, className }: { severity: Severity; className?: string }) {
  const Icon = ICONS[severity];
  const tone = SEVERITY_META[severity].band;
  return (
    <Badge tone={tone} className={className}>
      <Icon className="h-3 w-3" aria-hidden />
      {SEVERITY_META[severity].label}
    </Badge>
  );
}

export function NoThresholdChip() {
  return <Badge tone="neutral">No threshold</Badge>;
}

export function MoneyCell({
  amount,
  currency,
  compact,
  signed,
  tone,
  className,
  tooltip,
}: {
  amount: number;
  currency: string;
  compact?: boolean;
  signed?: boolean;
  tone?: 'inflow' | 'outflow' | 'auto';
  className?: string;
  tooltip?: ReactNode;
}) {
  const color =
    tone === 'inflow'
      ? 'text-ok'
      : tone === 'outflow'
        ? 'text-crit'
        : tone === 'auto'
          ? amount < 0
            ? 'text-crit'
            : ''
          : '';
  const text = formatMoney(amount, currency, { compact });
  const el = (
    <span className={cn('num whitespace-nowrap text-right', color, className)}>
      {signed && amount > 0 ? '+' : ''}
      {text}
    </span>
  );
  if (!compact && !tooltip) return el;
  return <Tooltip content={tooltip ?? formatMoney(amount, currency)}>{el}</Tooltip>;
}

export function KpiCard({
  label,
  value,
  sub,
  tone,
  loading,
  icon,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  tone?: 'ok' | 'warn' | 'crit';
  loading?: boolean;
  icon?: ReactNode;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between text-xs font-medium text-muted-foreground">
        <span>{label}</span>
        {icon}
      </div>
      {loading ? (
        <Skeleton className="mt-2 h-8 w-28" />
      ) : (
        <div className={cn('num mt-1 text-2xl font-medium', tone === 'crit' && 'text-crit', tone === 'warn' && 'text-warn', tone === 'ok' && 'text-ok')}>
          {value}
        </div>
      )}
      {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
    </Card>
  );
}
