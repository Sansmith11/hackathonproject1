import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { SeverityChip, MoneyCell } from './display';
import { TooltipProvider } from './overlay';

describe('SeverityChip', () => {
  it('shows text, never colour alone', () => {
    render(<SeverityChip severity="EMERGENCY" />);
    expect(screen.getByText('Emergency')).toBeInTheDocument();
  });
});

describe('MoneyCell', () => {
  it('renders amount with currency code', () => {
    render(
      <TooltipProvider>
        <MoneyCell amount={1234.5} currency="EUR" />
      </TooltipProvider>,
    );
    expect(screen.getByText(/EUR/)).toBeInTheDocument();
    expect(screen.getByText(/1,234\.50/)).toBeInTheDocument();
  });
});
