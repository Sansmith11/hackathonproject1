import { create } from 'zustand';
import { CheckCircle2, Info, XCircle } from 'lucide-react';

type Kind = 'info' | 'success' | 'error';
interface ToastItem {
  id: number;
  message: string;
  kind: Kind;
}

const useToasts = create<{ items: ToastItem[]; push: (m: string, k: Kind) => void; dismiss: (id: number) => void }>(
  (set) => ({
    items: [],
    push: (message, kind) => {
      const id = Date.now() + Math.random();
      set((s) => ({ items: [...s.items, { id, message, kind }] }));
      setTimeout(() => set((s) => ({ items: s.items.filter((t) => t.id !== id) })), 4500);
    },
    dismiss: (id) => set((s) => ({ items: s.items.filter((t) => t.id !== id) })),
  }),
);

export function toast(message: string, kind: Kind = 'info'): void {
  useToasts.getState().push(message, kind);
}

export function Toaster() {
  const { items, dismiss } = useToasts();
  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2" aria-live="polite">
      {items.map((t) => (
        <button
          key={t.id}
          onClick={() => dismiss(t.id)}
          className="flex max-w-sm items-start gap-2 rounded-md border border-border bg-surface px-3 py-2 text-left text-sm shadow-lg"
        >
          {t.kind === 'success' ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" />
          ) : t.kind === 'error' ? (
            <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-crit" />
          ) : (
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          )}
          <span>{t.message}</span>
        </button>
      ))}
    </div>
  );
}
