import { AlertTriangle, Inbox, ShieldAlert } from 'lucide-react';
import type { ReactNode } from 'react';
import type { UseQueryResult } from '@tanstack/react-query';
import { Button, Card, CardHeader, Skeleton } from './primitives';
import { formatDateTime } from '@/lib/format';

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-4 py-10 text-center">
      <Inbox className="h-8 w-8 text-muted-foreground" aria-hidden />
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="max-w-sm text-xs text-muted-foreground">{hint}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-col items-center justify-center gap-2 px-4 py-10 text-center">
      <AlertTriangle className="h-8 w-8 text-crit" aria-hidden />
      <p className="text-sm font-medium">Something went wrong</p>
      {message && <p className="max-w-sm text-xs text-muted-foreground">{message}</p>}
      {onRetry && (
        <Button size="sm" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

export function Forbidden403() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-3 py-24 text-center">
      <ShieldAlert className="h-12 w-12 text-warn" aria-hidden />
      <h1 className="text-xl font-semibold">403 — Access denied</h1>
      <p className="text-sm text-muted-foreground">Your role does not have permission to view this page.</p>
    </div>
  );
}

/** Wraps a query result with skeleton / error / empty states so one widget never breaks the page. */
export function QueryBoundary<T>({
  query,
  children,
  skeleton,
  isEmpty,
  empty,
}: {
  query: UseQueryResult<T>;
  children: (data: T) => ReactNode;
  skeleton?: ReactNode;
  isEmpty?: (data: T) => boolean;
  empty?: ReactNode;
}) {
  if (query.isPending) return <>{skeleton ?? <Skeleton className="h-48 w-full" />}</>;
  if (query.isError) return <ErrorState message={query.error.message} onRetry={() => void query.refetch()} />;
  if (isEmpty?.(query.data)) return <>{empty ?? <EmptyState title="No data" />}</>;
  return <>{children(query.data)}</>;
}

export function Widget<T>({
  title,
  description,
  actions,
  query,
  children,
  isEmpty,
  empty,
  height = 'h-64',
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  query: UseQueryResult<T>;
  children: (data: T) => ReactNode;
  isEmpty?: (data: T) => boolean;
  empty?: ReactNode;
  height?: string;
  className?: string;
}) {
  return (
    <Card className={className}>
      <CardHeader title={title} description={description} actions={actions} />
      <div className="p-4">
        <QueryBoundary query={query} isEmpty={isEmpty} empty={empty} skeleton={<Skeleton className={`${height} w-full`} />}>
          {children}
        </QueryBoundary>
      </div>
    </Card>
  );
}

export function DataFreshness({ asOf }: { asOf?: string }) {
  if (!asOf) return null;
  return <span className="text-xs text-muted-foreground">As of {formatDateTime(asOf)}</span>;
}
