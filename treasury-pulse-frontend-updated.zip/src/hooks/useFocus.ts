import { useMemo } from 'react';
import { useAlerts, useDailyPositions, useEntities, usePositionSummary } from '@/api/hooks';
import { SEVERITY_RANK } from '@/lib/alerts';
import { useFilterStore } from '@/stores/filterStore';
import type { DailyPosition, Entity } from '@/types/domain';

/** Latest daily position row for every in-scope entity/currency pair. */
export function useLatestPositions(): { data: DailyPosition[]; isPending: boolean; asOfDate: string | undefined } {
  const rep = useFilterStore((s) => s.reportingCcy);
  const summary = usePositionSummary(rep);
  const asOfDate = summary.data?.asOf.slice(0, 10);
  const daily = useDailyPositions({ from: asOfDate ? shiftDate(asOfDate, -29) : undefined });
  return useMemo(() => {
    if (!asOfDate || !daily.data) return { data: [], isPending: true, asOfDate };
    return { data: daily.data, isPending: false, asOfDate };
  }, [asOfDate, daily.data]);
}

export function shiftDate(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export interface Focus {
  entity: string | null;
  currency: string | null;
  entityObj: Entity | undefined;
  /** currencies available for the focused entity */
  currencies: string[];
  ready: boolean;
}

/**
 * The single entity/currency pair that single-series widgets (forecast, gap, what-if) show.
 * Falls back to the entity with the worst open alert so the demo opens on the shortfall story.
 */
export function useFocus(): Focus {
  const f = useFilterStore();
  const entities = useEntities();
  const alerts = useAlerts({ status: 'OPEN' });
  const latest = useLatestPositions();

  return useMemo(() => {
    const list = entities.data ?? [];
    const worst = [...(alerts.data ?? [])].sort(
      (a, b) => SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity] || a.gap - b.gap,
    );
    const regionPool = f.region ? list.filter((e) => e.region === f.region) : list;
    let entity = f.entity && list.some((e) => e.code === f.entity) ? f.entity : null;
    if (!entity) {
      entity = worst.find((a) => regionPool.some((e) => e.code === a.entityCode))?.entityCode ?? regionPool[0]?.code ?? null;
    }
    const entityObj = list.find((e) => e.code === entity);
    const currencies = [...new Set(latest.data.filter((p) => p.entityCode === entity).map((p) => p.currency))];
    const pref = f.currencies.find((c) => currencies.includes(c));
    const alertCcy = worst.find((a) => a.entityCode === entity)?.currency;
    const currency =
      pref ?? (f.entity ? (currencies.includes(entityObj?.baseCurrency ?? '') ? entityObj?.baseCurrency : currencies[0]) : undefined) ??
      alertCcy ??
      entityObj?.baseCurrency ??
      null;
    return { entity, currency: currency ?? null, entityObj, currencies, ready: !!entity && !!currency };
  }, [entities.data, alerts.data, latest.data, f.entity, f.region, f.currencies]);
}
