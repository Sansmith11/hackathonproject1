import { useCallback } from 'react';
import { useEntities } from '@/api/hooks';
import { useFilterStore } from '@/stores/filterStore';

/** Predicate for the global region → entity → currency filter. */
export function useScopeFilter() {
  const entities = useEntities();
  const { region, entity, currencies } = useFilterStore();
  return useCallback(
    (entityCode: string, currency?: string) => {
      if (entity && entityCode !== entity) return false;
      if (region && entities.data?.find((e) => e.code === entityCode)?.region !== region) return false;
      if (currencies.length && currency && !currencies.includes(currency)) return false;
      return true;
    },
    [entities.data, region, entity, currencies],
  );
}
