import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useEffect, useState, type ReactNode } from 'react';
import { TooltipProvider } from '@/components/ui/overlay';
import { Toaster, toast } from '@/components/ui/toast';
import { ApiError } from '@/api/client';
import { applyTheme, useUiStore } from '@/stores/uiStore';

export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            refetchOnWindowFocus: false,
            retry: (count, err) => !(err instanceof ApiError && err.status < 500) && count < 2,
          },
          mutations: {
            onError: (e) => toast((e as Error).message, 'error'),
          },
        },
      }),
  );
  const theme = useUiStore((s) => s.theme);
  useEffect(() => {
    applyTheme(theme);
  }, [theme]);
  return (
    <QueryClientProvider client={client}>
      <TooltipProvider>
        {children}
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

