import { createBrowserRouter, Navigate, useRouteError } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { RoleGuard } from '@/components/layout/RoleGuard';
import { ErrorState } from '@/components/ui/feedback';

const page = (loader: () => Promise<{ default: React.ComponentType }>) => ({
  lazy: async () => ({ Component: (await loader()).default }),
});

function RouteError() {
  const e = useRouteError();
  return (
    <div className="p-10">
      <ErrorState message={e instanceof Error ? e.message : 'Unexpected error'} onRetry={() => window.location.reload()} />
    </div>
  );
}

export const router = createBrowserRouter([
  { path: '/login', ...page(() => import('@/features/auth/LoginPage')), errorElement: <RouteError /> },
  {
    element: <RoleGuard />,
    errorElement: <RouteError />,
    children: [
      {
        element: <AppShell />,
        errorElement: <RouteError />,
        children: [
          { index: true, element: <Navigate to="/dashboard" replace /> },
          { path: 'dashboard', ...page(() => import('@/features/dashboard/DashboardPage')) },
          { path: 'transactions', ...page(() => import('@/features/transactions/TransactionsPage')) },
          { path: 'forecast', ...page(() => import('@/features/forecast/ForecastPage')) },
          { path: 'liquidity', ...page(() => import('@/features/liquidity/LiquidityGapPage')) },
          { path: 'alerts', ...page(() => import('@/features/alerts/AlertsPage')) },
          { path: 'recommendations', ...page(() => import('@/features/recommendations/RecommendationsPage')) },
          { path: 'benchmarks', ...page(() => import('@/features/benchmarks/BenchmarksPage')) },
          { element: <RoleGuard action="chat" />, children: [{ path: 'chat', ...page(() => import('@/features/chat/ChatPage')) }] },
          { element: <RoleGuard action="upload" />, children: [{ path: 'upload', ...page(() => import('@/features/upload/UploadPage')) }] },
          { element: <RoleGuard action="what_if" />, children: [{ path: 'what-if', ...page(() => import('@/features/what-if/WhatIfPage')) }] },
          { element: <RoleGuard action="reports" />, children: [{ path: 'reports', ...page(() => import('@/features/reports/ReportsPage')) }] },
          {
            path: 'admin',
            children: [
              { element: <RoleGuard action="admin_users" />, children: [{ path: 'users', ...page(() => import('@/features/admin/UsersPage')) }] },
              { element: <RoleGuard action="admin_thresholds" />, children: [{ path: 'thresholds', ...page(() => import('@/features/admin/ThresholdsPage')) }] },
              { element: <RoleGuard action="admin_schedules" />, children: [{ path: 'schedules', ...page(() => import('@/features/admin/SchedulesPage')) }] },
            ],
          },
          { path: '*', element: <ErrorState message="Page not found" /> },
        ],
      },
    ],
  },
]);
