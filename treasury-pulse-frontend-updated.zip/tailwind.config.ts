import type { Config } from 'tailwindcss';
import animate from 'tailwindcss-animate';

const c = (v: string) => `hsl(var(--${v}) / <alpha-value>)`;

export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        border: c('border'),
        background: c('background'),
        foreground: c('foreground'),
        surface: c('surface'),
        muted: { DEFAULT: c('muted'), foreground: c('muted-foreground') },
        accent: { DEFAULT: c('accent'), foreground: c('accent-foreground') },
        ok: c('band-ok'),
        warn: c('band-warn'),
        crit: c('band-crit'),
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
    },
  },
  plugins: [animate],
} satisfies Config;
