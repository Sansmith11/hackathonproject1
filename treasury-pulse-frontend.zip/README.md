# Treasury Pulse — Frontend

Liquidity command center for a global treasury team: daily cash positions, 30-day forecast with confidence
intervals, liquidity gap vs thresholds, alert matrix, what-if scenarios, SOD/EOD reports, role-based access
and an AI assistant. The spec lives in [`docs/FRONTEND_SPEC.md`](docs/FRONTEND_SPEC.md).

The app runs **fully offline against a mock API** (MSW + a seeded synthetic data generator). No external
network calls are made at runtime (fonts are self-hosted via `@fontsource`).

## Setup

```bash
npm install
cp .env.example .env     # VITE_API_BASE_URL=/api, VITE_USE_MOCKS=true
npm run dev              # http://localhost:5173
```

| Script | Purpose |
|---|---|
| `npm run dev` / `build` / `preview` | Vite |
| `npm run lint` | ESLint |
| `npm run typecheck` | `tsc --noEmit` (strict) |
| `npm test` | Vitest + Testing Library |
| `npm run e2e` | Playwright smoke flows (`npx playwright install chromium` first) |

## Demo users (one-click on the login screen)

| Email | Role | Scope |
|---|---|---|
| `viewer@demo` | Viewer | Paris, Frankfurt — read-only |
| `analyst.paris@demo` | Analyst | EMEA entities — upload, what-if, reports, alert actions |
| `manager.apac@demo` | Treasury Manager | APAC region view + entity drill-down |
| `admin@demo` | Admin | Everything — users, alert matrix, schedules |

## The demo story (seeded, deterministic)

The demo "today" is **10 Oct 2026**. The mock forecast injects four deliberate future shortfalls:

| Position | Severity | Driver |
|---|---|---|
| Paris EUR | Emergency (from day 3) | 3 loan repayments + data-centre capex |
| Frankfurt EUR | Emergency (day 21) | Bond coupon + VAT settlement |
| Singapore USD | Critical | Syndicated loan instalment |
| London GBP | Warning | Term loan repayment |

Log in as the analyst → the banner and dashboard focus on Paris EUR. Try *What-if → +3 days receivables delay*,
*Capex postponement*, then ask the assistant *"Why is there a shortfall in EUR next week?"*.
Use the user-menu **Demo mode** entry to reset all mock state.

## Switching from mocks to the real backend

```bash
# .env
VITE_USE_MOCKS=false
VITE_API_BASE_URL=https://your-fastapi-host/api
```

The client sends `X-Session-Token` and validates every response with Zod (`src/types/schemas.ts`), so contract
drift fails loudly. Endpoints beyond the spec's table (additive): `GET/PUT /thresholds/bands`,
`GET /reports/:id/download`, `PUT /users/:id`, `PUT /thresholds/:id`, `DELETE /thresholds/:id`.

## Architecture notes

- `src/lib/` holds all money/gap/severity logic (unit-tested); components never do currency math.
- Global filters (region → entity → currency, dates, reporting ccy) live in `filterStore`, mirrored to the URL.
- Permissions are enforced three ways: `RoleGuard` on routes, `can()` for controls (disabled buttons explain
  why), and a scoped `EntitySelector`. The mock API enforces scope server-side (403 on out-of-scope entities).
- **Payment delay** in What-if is modelled as *receivables arriving late* (a stress); **capex postponement**
  is the relief lever.
- If a browser cannot register a service worker, `src/mocks/browser.ts` falls back to intercepting `fetch`.
- TanStack Query hooks are centralised in `src/api/hooks.ts` (shared across features).

## Screenshots for the demo video

1. Login with demo-user cards · 2. Dashboard with alert banner · 3. Liquidity-gap chart with bands ·
4. Forecast with 80/95% CI and rationale · 5. Heatmap view · 6. What-if +3 days · 7. Assistant chart + action plan ·
8. Alert matrix (Admin) · 9. Reports preview · 10. Upload wizard validation report.
