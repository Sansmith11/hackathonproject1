import { z } from 'zod';
import { api } from '../client';
import type { IntradayBucket, ReportingCcyArg } from './types';
import {
  dailyPositionSchema,
  entitySchema,
  fxRatesSchema,
  intradaySchema,
  loginResponseSchema,
  positionSummarySchema,
  transactionPageSchema,
  uploadHistorySchema,
  uploadResultSchema,
  userSchema,
} from '@/types/schemas';
import type { User } from '@/types/domain';

export const authApi = {
  login: (email: string) =>
    api('/auth/login', { method: 'POST', body: { email }, schema: loginResponseSchema }),
  me: () => api('/auth/me', { schema: userSchema }),
};

export const referenceApi = {
  entities: () => api('/entities', { schema: z.array(entitySchema) }),
  fx: (base: ReportingCcyArg) => api('/fx-rates', { query: { base }, schema: fxRatesSchema }),
};

export interface TxnQuery {
  entity?: string | null;
  currency?: string | null;
  direction?: string | null;
  category?: string | null;
  productType?: string | null;
  settlementStatus?: string | null;
  rating?: string | null;
  from?: string | null;
  to?: string | null;
  q?: string | null;
  page?: number;
  pageSize?: number;
  sort?: string;
}

export const txnApi = {
  list: (q: TxnQuery) => api('/transactions', { query: { ...q }, schema: transactionPageSchema }),
};

export const positionsApi = {
  daily: (q: { entity?: string | null; currency?: string | null; from?: string; to?: string }) =>
    api('/positions/daily', { query: q, schema: z.array(dailyPositionSchema) }),
  summary: (reportingCcy: string) =>
    api('/positions/summary', { query: { reportingCcy }, schema: positionSummarySchema }),
  intraday: (q: { entity?: string | null; currency?: string | null; date?: string }) =>
    api<IntradayBucket[]>('/positions/intraday', { query: q, schema: z.array(intradaySchema) }),
};

export const uploadsApi = {
  list: () => api('/uploads', { schema: z.array(uploadHistorySchema) }),
  submit: (file: File, rowsParsed: number, rowsRejected: number, errors: unknown[]) => {
    const form = new FormData();
    form.set('file', file);
    form.set('rowsParsed', String(rowsParsed));
    form.set('rowsRejected', String(rowsRejected));
    form.set('errors', JSON.stringify(errors));
    return api('/uploads', { method: 'POST', form, schema: uploadResultSchema });
  },
};

export const usersApi = {
  list: () => api('/users', { schema: z.array(userSchema) }),
  create: (u: Omit<User, 'id'>) => api('/users', { method: 'POST', body: u, schema: userSchema }),
  update: (u: User) => api(`/users/${u.id}`, { method: 'PUT', body: u, schema: userSchema }),
};
