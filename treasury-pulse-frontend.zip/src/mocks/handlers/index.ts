import { delay, http, HttpResponse } from 'msw';
import { can } from '@/lib/permissions';
import { deployableSurplus } from '@/lib/gap';
import type {
  Alert,
  AlertStatus,
  BenchmarksResponse,
  ChatContext,
  PositionSummary,
  Region,
  ScenarioParams,
  Severity,
  Threshold,
  Transaction,
  User,
} from '@/types/domain';
import { answer } from '../data/chat';
import {
  allGapRows,
  buildForecast,
  gapRowsFor,
  historicalAlerts,
  liveAlerts,
  recommendationsFor,
  runScenario,
} from '../data/forecast';
import {
  ENTITIES,
  FX_TO_USD,
  TODAY,
  getDataset,
  getEntity,
  hashString,
  mulberry32,
  pairKey,
  round2,
} from '../data/generator';
import { reportCsv, reportLines, textToPdf } from '../data/report';
import { nextId, store } from '../data/store';

const BASE = (import.meta.env.VITE_API_BASE_URL as string | undefined) ?? '/api';
const url = (p: string) => `${BASE}${p}`;

const err = (status: number, code: string, message: string, details?: unknown) =>
  HttpResponse.json({ error: { code, message, details } }, { status });

const lat = () => delay(300 + Math.floor(Math.random() * 500));

function userFrom(req: Request): User | null {
  const token = req.headers.get('X-Session-Token');
  if (!token?.startsWith('tok-')) return null;
  return store.users.find((u) => `tok-${u.id}` === token) ?? null;
}

function allowedEntities(user: User): Set<string> {
  if (user.role === 'ADMIN') return new Set(ENTITIES.map((e) => e.code));
  const set = new Set(user.entityCodes);
  if (user.role === 'TREASURY_MANAGER') {
    for (const e of ENTITIES) if (user.regions.includes(e.region)) set.add(e.code);
  }
  return set;
}

const regionOf = (code: string): Region | undefined => getEntity(code)?.region;

/** Wraps a handler with auth + latency + scope check on ?entity= . */
function guarded(
  fn: (ctx: { req: Request; user: User; allowed: Set<string>; params: Record<string, string>; q: URLSearchParams }) => Promise<Response> | Response,
  opts: { scopeEntity?: boolean } = { scopeEntity: true },
) {
  return async ({ request, params }: { request: Request; params: Record<string, unknown> }) => {
    await lat();
    const user = userFrom(request);
    if (!user) return err(401, 'UNAUTHENTICATED', 'Session expired or missing');
    const allowed = allowedEntities(user);
    const q = new URL(request.url).searchParams;
    const entity = q.get('entity');
    if (opts.scopeEntity && entity && !allowed.has(entity)) {
      return err(403, 'FORBIDDEN_SCOPE', `Entity ${entity} is outside your scope`);
    }
    return fn({ req: request, user, allowed, params: params as Record<string, string>, q });
  };
}

const forbid = (action: string) => err(403, 'FORBIDDEN', `Your role cannot perform: ${action}`);

function mergedAlerts(allowed: Set<string>): Alert[] {
  const hist = historicalAlerts().filter((a) => allowed.has(a.entityCode));
  const all = [...liveAlerts(allowed), ...hist];
  return all.map((a) => {
    const st = store.alertState.get(a.id);
    return st ? { ...a, status: st.status, resolvedAt: st.resolvedAt ?? a.resolvedAt, note: st.note ?? a.note } : a;
  });
}

function rate(ccy: string, reporting: string): number {
  return (FX_TO_USD[ccy] ?? 1) / (FX_TO_USD[reporting] ?? 1);
}

const reportBlobs = new Map<string, { bytes: Uint8Array | string; mime: string }>();

export const handlers = [
  /* ---- auth ---- */
  http.post(url('/auth/login'), async ({ request }) => {
    await lat();
    const body = (await request.json()) as { email?: string };
    const user = store.users.find((u) => u.email === body.email);
    if (!user) return err(401, 'BAD_CREDENTIALS', 'Unknown demo user');
    return HttpResponse.json({ token: `tok-${user.id}`, user });
  }),
  http.get(url('/auth/me'), guarded(({ user }) => HttpResponse.json(user))),

  /* ---- reference ---- */
  http.get(url('/entities'), guarded(({ allowed }) => HttpResponse.json(ENTITIES.filter((e) => allowed.has(e.code))))),
  http.get(url('/fx-rates'), guarded(({ q }) => {
    const base = q.get('base') ?? 'USD';
    const rates = Object.fromEntries(Object.keys(FX_TO_USD).map((c) => [c, round2(rate(c, base) * 1e6) / 1e6]));
    return HttpResponse.json({ date: q.get('date') ?? TODAY, base, rates });
  })),

  /* ---- uploads ---- */
  http.post(url('/uploads'), guarded(async ({ req, user }) => {
    if (!can(user, 'upload')) return forbid('upload transactions');
    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) return err(400, 'NO_FILE', 'A file is required');
    const rowsParsed = Number(form.get('rowsParsed') ?? 0);
    const rowsRejected = Number(form.get('rowsRejected') ?? 0);
    const errors = JSON.parse(String(form.get('errors') ?? '[]'));
    const uploadId = nextId('upl');
    store.uploads.unshift({ uploadId, fileName: file.name, uploadedAt: new Date().toISOString(), uploadedBy: user.email, rowsParsed, rowsRejected });
    return HttpResponse.json({ uploadId, rowsParsed, rowsRejected, errors: errors.slice(0, 200) });
  })),
  http.get(url('/uploads'), guarded(() => HttpResponse.json(store.uploads))),

  /* ---- transactions ---- */
  http.get(url('/transactions'), guarded(({ allowed, q }) => {
    const entity = q.get('entity');
    const f = {
      currency: q.get('currency'),
      direction: q.get('direction'),
      category: q.get('category'),
      productType: q.get('productType'),
      settlementStatus: q.get('settlementStatus'),
      rating: q.get('rating'),
      from: q.get('from'),
      to: q.get('to'),
      text: q.get('q')?.toLowerCase(),
    };
    let rows = getDataset().transactions.filter(
      (t) =>
        allowed.has(t.entityCode) &&
        (!entity || t.entityCode === entity) &&
        (!f.currency || t.currency === f.currency) &&
        (!f.direction || t.direction === f.direction) &&
        (!f.category || t.category === f.category) &&
        (!f.productType || t.productType === f.productType) &&
        (!f.settlementStatus || t.settlementStatus === f.settlementStatus) &&
        (!f.rating || t.counterpartyRiskRating === f.rating) &&
        (!f.from || t.transactionDate >= f.from) &&
        (!f.to || t.transactionDate <= f.to) &&
        (!f.text ||
          t.transactionId.toLowerCase().includes(f.text) ||
          t.counterparty.toLowerCase().includes(f.text) ||
          t.category.toLowerCase().includes(f.text)),
    );
    const [sortKey, sortDir] = (q.get('sort') ?? 'transactionDate:desc').split(':');
    if (sortKey !== 'transactionDate' || sortDir !== 'desc') {
      const k = sortKey as keyof Transaction;
      const dir = sortDir === 'asc' ? 1 : -1;
      rows = [...rows].sort((a, b) => (a[k]! < b[k]! ? -1 : a[k]! > b[k]! ? 1 : 0) * dir);
    }
    const page = Math.max(1, Number(q.get('page') ?? 1));
    const pageSize = Math.min(500, Math.max(1, Number(q.get('pageSize') ?? 25)));
    return HttpResponse.json({
      items: rows.slice((page - 1) * pageSize, page * pageSize),
      total: rows.length,
      page,
      pageSize,
    });
  })),

  /* ---- positions ---- */
  http.get(url('/positions/daily'), guarded(({ allowed, q }) => {
    const entity = q.get('entity');
    const ccy = q.get('currency');
    const from = q.get('from') ?? '0000';
    const to = q.get('to') ?? '9999';
    const out = [];
    for (const [k, rows] of getDataset().positions) {
      const [e, c] = k.split('|');
      if (!allowed.has(e) || (entity && e !== entity) || (ccy && c !== ccy)) continue;
      out.push(...rows.filter((r) => r.date >= from && r.date <= to));
    }
    return HttpResponse.json(out);
  })),
  http.get(url('/positions/summary'), guarded(({ allowed, q }) => {
    const rep = q.get('reportingCcy') ?? 'USD';
    const ds = getDataset();
    const byCcy = new Map<string, number>();
    const byRegion = new Map<Region, { amount: number; entities: Set<string> }>();
    let total = 0;
    for (const p of ds.pairs) {
      if (!allowed.has(p.entityCode)) continue;
      const last = ds.positions.get(pairKey(p.entityCode, p.currency))!.at(-1)!;
      const v = last.closingBalance * rate(p.currency, rep);
      total += v;
      byCcy.set(p.currency, (byCcy.get(p.currency) ?? 0) + v);
      const r = regionOf(p.entityCode)!;
      const cur = byRegion.get(r) ?? { amount: 0, entities: new Set() };
      cur.amount += v;
      cur.entities.add(p.entityCode);
      byRegion.set(r, cur);
    }
    const alerts = liveAlerts(allowed).filter((a) => a.status !== 'RESOLVED');
    const gaps = allGapRows(allowed);
    const shortfallEntities = new Set(gaps.filter((g) => g.severity === 'EMERGENCY').map((g) => g.entityCode));
    const minByPair = new Map<string, { min: number; thr: number; ccy: string }>();
    for (const g of gaps) {
      const k = pairKey(g.entityCode, g.currency);
      const cur = minByPair.get(k);
      if (!cur || g.projected < cur.min) minByPair.set(k, { min: g.projected, thr: g.threshold, ccy: g.currency });
    }
    let surplus = 0;
    let minGap = Number.POSITIVE_INFINITY;
    for (const v of minByPair.values()) {
      surplus += deployableSurplus(v.min, v.thr) * rate(v.ccy, rep);
      minGap = Math.min(minGap, (v.min - v.thr) * rate(v.ccy, rep));
    }
    const summary: PositionSummary = {
      asOf: `${TODAY}T16:00:00+05:30`,
      reportingCcy: rep,
      totalCash: round2(total),
      byCurrency: [...byCcy].map(([currency, amount]) => ({ currency, amount: round2(amount), share: total ? amount / total : 0 })).sort((a, b) => b.amount - a.amount),
      byRegion: [...byRegion].map(([region, v]) => ({
        region,
        amount: round2(v.amount),
        entities: v.entities.size,
        openAlerts: alerts.filter((a) => regionOf(a.entityCode) === region).length,
      })),
      openAlerts: {
        EMERGENCY: alerts.filter((a) => a.severity === 'EMERGENCY').length,
        CRITICAL: alerts.filter((a) => a.severity === 'CRITICAL').length,
        WARNING: alerts.filter((a) => a.severity === 'WARNING').length,
      },
      entitiesInShortfall: shortfallEntities.size,
      deployableSurplus: round2(surplus),
      minGap30d: Number.isFinite(minGap) ? round2(minGap) : 0,
    };
    return HttpResponse.json(summary);
  })),
  http.get(url('/positions/intraday'), guarded(({ allowed, q }) => {
    const entity = q.get('entity');
    const ccy = q.get('currency');
    const date = q.get('date') ?? TODAY;
    let inflows = 0;
    let outflows = 0;
    for (const [k, rows] of getDataset().positions) {
      const [e, c] = k.split('|');
      if (!allowed.has(e) || (entity && e !== entity) || (ccy && c !== ccy)) continue;
      const r = rows.find((x) => x.date === date) ?? rows.at(-1)!;
      inflows += r.inflows;
      outflows += r.outflows;
    }
    const rng = mulberry32(hashString(`${entity}${ccy}${date}`));
    const prof = Array.from({ length: 24 }, (_, h) => (h >= 7 && h <= 18 ? 1 + rng() : 0.1 * rng()));
    const s = prof.reduce((a, b) => a + b, 0);
    const prof2 = prof.map((v) => v * (0.7 + 0.6 * rng()));
    const s2 = prof2.reduce((a, b) => a + b, 0);
    return HttpResponse.json(
      prof.map((v, hour) => ({ hour, inflows: round2((inflows * v) / s), outflows: round2((outflows * prof2[hour]) / s2) })),
    );
  })),

  /* ---- forecast, gap ---- */
  http.get(url('/forecast'), guarded(({ q }) => {
    const e = q.get('entity');
    const c = q.get('currency');
    if (!e || !c) return err(400, 'BAD_REQUEST', 'entity and currency are required');
    const f = buildForecast(e, c);
    return f ? HttpResponse.json(f) : err(404, 'NOT_FOUND', `No forecast for ${e}/${c}`);
  })),
  http.get(url('/liquidity-gap'), guarded(({ allowed, q }) => {
    const e = q.get('entity');
    const c = q.get('currency');
    const horizon = Number(q.get('horizon') ?? 30);
    const rows = (e && c ? gapRowsFor(e, c) : allGapRows(allowed)).filter(
      (g) => (!e || g.entityCode === e) && (!c || g.currency === c),
    );
    return HttpResponse.json(rows.filter((_, i) => i % 30 < horizon));
  })),

  /* ---- thresholds ---- */
  http.get(url('/thresholds'), guarded(() => HttpResponse.json(store.thresholds))),
  http.get(url('/thresholds/bands'), guarded(() => HttpResponse.json(store.bands))),
  http.put(url('/thresholds/bands'), guarded(async ({ req, user }) => {
    if (!can(user, 'admin_thresholds')) return forbid('configure the alert matrix');
    const b = (await req.json()) as { critical: number; warning: number };
    if (!(b.critical > 0 && b.warning > b.critical)) return err(400, 'VALIDATION', 'Warning band must exceed critical band');
    store.bands = { critical: b.critical, warning: b.warning };
    return HttpResponse.json(store.bands);
  })),
  http.post(url('/thresholds'), guarded(async ({ req, user }) => {
    if (!can(user, 'admin_thresholds')) return forbid('configure the alert matrix');
    const t = (await req.json()) as Omit<Threshold, 'id'>;
    const created: Threshold = { ...t, id: nextId('thr') };
    store.thresholds.push(created);
    return HttpResponse.json(created, { status: 201 });
  })),
  http.put(url('/thresholds/:id'), guarded(async ({ req, user, params }) => {
    if (!can(user, 'admin_thresholds')) return forbid('configure the alert matrix');
    const i = store.thresholds.findIndex((t) => t.id === params.id);
    if (i < 0) return err(404, 'NOT_FOUND', 'Threshold not found');
    store.thresholds[i] = { ...(await req.json() as Threshold), id: params.id };
    return HttpResponse.json(store.thresholds[i]);
  })),
  http.delete(url('/thresholds/:id'), guarded(({ user, params }) => {
    if (!can(user, 'admin_thresholds')) return forbid('configure the alert matrix');
    store.thresholds = store.thresholds.filter((t) => t.id !== params.id);
    return HttpResponse.json({ ok: true });
  })),

  /* ---- alerts ---- */
  http.get(url('/alerts'), guarded(({ allowed, q }) => {
    const status = q.get('status') as AlertStatus | null;
    const sev = q.get('severity') as Severity | null;
    const from = q.get('from');
    const to = q.get('to');
    const rows = mergedAlerts(allowed)
      .filter((a) => (!status || a.status === status) && (!sev || a.severity === sev) && (!from || a.createdAt.slice(0, 10) >= from) && (!to || a.createdAt.slice(0, 10) <= to))
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
    return HttpResponse.json(rows);
  })),
  http.patch(url('/alerts/:id'), guarded(async ({ req, user, allowed, params }) => {
    if (!can(user, 'ack_alerts')) return forbid('acknowledge or resolve alerts');
    const body = (await req.json()) as { status: AlertStatus; note?: string };
    const alert = mergedAlerts(allowed).find((a) => a.id === params.id);
    if (!alert) return err(404, 'NOT_FOUND', 'Alert not found');
    store.alertState.set(alert.id, {
      status: body.status,
      note: body.note,
      resolvedAt: body.status === 'RESOLVED' ? new Date().toISOString() : undefined,
    });
    return HttpResponse.json(mergedAlerts(allowed).find((a) => a.id === params.id));
  })),

  /* ---- scenarios & recommendations ---- */
  http.post(url('/scenarios/run'), guarded(async ({ req, user, allowed }) => {
    if (!can(user, 'what_if')) return forbid('run what-if scenarios');
    const body = (await req.json()) as ScenarioParams & { entity: string; currency: string };
    if (!allowed.has(body.entity)) return err(403, 'FORBIDDEN_SCOPE', `Entity ${body.entity} is outside your scope`);
    const r = runScenario(body.entity, body.currency, body);
    return r ? HttpResponse.json(r) : err(404, 'NOT_FOUND', 'Unknown entity/currency');
  }, { scopeEntity: false })),
  http.get(url('/recommendations'), guarded(({ allowed, q }) => HttpResponse.json(recommendationsFor(allowed, q.get('entity'))))),

  /* ---- reports ---- */
  http.post(url('/reports/generate'), guarded(async ({ req, user, allowed }) => {
    if (!can(user, 'reports')) return forbid('generate reports');
    const body = (await req.json()) as { type: 'SOD' | 'EOD'; format: 'PDF' | 'CSV'; entity?: string | null };
    if (body.entity && !allowed.has(body.entity)) return err(403, 'FORBIDDEN_SCOPE', 'Entity outside scope');
    const lines = reportLines(body.type, allowed, body.entity);
    const isPdf = body.format === 'PDF';
    const content: Uint8Array | string = isPdf ? textToPdf(lines) : reportCsv(lines);
    const id = nextId('rpt');
    reportBlobs.set(id, { bytes: content, mime: isPdf ? 'application/pdf' : 'text/csv' });
    store.reports.unshift({
      id,
      type: body.type,
      format: body.format,
      entityCode: body.entity ?? null,
      generatedAt: new Date().toISOString(),
      generatedBy: user.email,
      sizeBytes: typeof content === 'string' ? content.length : content.byteLength,
    });
    return new HttpResponse(content as BodyInit, {
      headers: { 'Content-Type': isPdf ? 'application/pdf' : 'text/csv', 'X-Report-Id': id },
    });
  })),
  http.get(url('/reports/history'), guarded(() => HttpResponse.json(store.reports))),
  http.get(url('/reports/:id/download'), guarded(({ params }) => {
    const b = reportBlobs.get(params.id);
    if (!b) return err(404, 'NOT_FOUND', 'Report no longer available');
    return new HttpResponse(b.bytes as BodyInit, { headers: { 'Content-Type': b.mime } });
  })),
  http.get(url('/reports/schedules'), guarded(() => HttpResponse.json(store.schedules))),
  http.put(url('/reports/schedules'), guarded(async ({ req, user }) => {
    if (!can(user, 'admin_schedules')) return forbid('edit report schedules');
    store.schedules = (await req.json()) as typeof store.schedules;
    return HttpResponse.json(store.schedules);
  })),

  /* ---- users ---- */
  http.get(url('/users'), guarded(({ user }) => (can(user, 'admin_users') ? HttpResponse.json(store.users) : forbid('manage users')))),
  http.post(url('/users'), guarded(async ({ req, user }) => {
    if (!can(user, 'admin_users')) return forbid('manage users');
    const body = (await req.json()) as Omit<User, 'id'>;
    if (store.users.some((u) => u.email === body.email)) return err(409, 'DUPLICATE', 'Email already exists');
    const created = { ...body, id: nextId('u') };
    store.users.push(created);
    return HttpResponse.json(created, { status: 201 });
  })),
  http.put(url('/users/:id'), guarded(async ({ req, user, params }) => {
    if (!can(user, 'admin_users')) return forbid('manage users');
    const body = (await req.json()) as User;
    const i = store.users.findIndex((u) => u.id === params.id);
    if (i < 0) return err(404, 'NOT_FOUND', 'User not found');
    const admins = store.users.filter((u) => u.role === 'ADMIN' && u.id !== params.id).length;
    if (body.role !== 'ADMIN' && store.users[i].role === 'ADMIN' && admins === 0) {
      return err(409, 'LAST_ADMIN', 'Cannot remove the last Admin');
    }
    store.users[i] = { ...body, id: params.id };
    return HttpResponse.json(store.users[i]);
  })),

  /* ---- chat (streamed) ---- */
  http.post(url('/chat'), async ({ request }) => {
    const user = userFrom(request);
    if (!user) return err(401, 'UNAUTHENTICATED', 'Session expired or missing');
    if (!can(user, 'chat')) return forbid('use the chatbot');
    const body = (await request.json()) as { conversationId?: string; message: string; context?: ChatContext };
    const allowed = allowedEntities(user);
    const a = answer(body.message, body.context, allowed);
    const conversationId = body.conversationId ?? nextId('conv');
    const enc = new TextEncoder();
    const tokens = a.text.match(/\S+\s*/g) ?? [a.text];
    const stream = new ReadableStream({
      async start(controller) {
        await new Promise((r) => setTimeout(r, 400));
        for (const t of tokens) {
          controller.enqueue(enc.encode(`data: ${JSON.stringify({ type: 'token', text: t })}\n\n`));
          await new Promise((r) => setTimeout(r, 25));
        }
        controller.enqueue(enc.encode(`data: ${JSON.stringify({ type: 'final', ...a.final, conversationId })}\n\n`));
        controller.close();
      },
    });
    return new HttpResponse(stream, { headers: { 'Content-Type': 'text/event-stream' } });
  }),

  /* ---- benchmarks ---- */
  http.get(url('/benchmarks'), guarded(({ allowed }) => {
    const ds = getDataset();
    const backtest: BenchmarksResponse['backtest'] = [];
    const perEntity = [];
    let sumAbsPct = 0;
    let sumSq = 0;
    let n = 0;
    for (const e of ENTITIES.filter((x) => allowed.has(x.code))) {
      const rows = ds.positions.get(pairKey(e.code, e.baseCurrency))!.slice(-30);
      const rng = mulberry32(hashString(e.code));
      let ap = 0;
      let sq = 0;
      rows.forEach((r) => {
        const fc = r.closingBalance * (1 + (rng() - 0.5) * 0.06);
        ap += Math.abs((r.closingBalance - fc) / r.closingBalance);
        sq += ((r.closingBalance - fc) * (FX_TO_USD[e.baseCurrency] ?? 1)) ** 2;
        if (e.code === 'PARI') backtest.push({ date: r.date, actual: r.closingBalance, forecast: round2(fc) });
      });
      perEntity.push({ entityCode: e.code, mape: round2((ap / rows.length) * 100), rmse: round2(Math.sqrt(sq / rows.length)) });
      sumAbsPct += ap;
      sumSq += sq;
      n += rows.length;
    }
    const res: BenchmarksResponse = {
      mape: n ? round2((sumAbsPct / n) * 100) : 0,
      rmse: n ? round2(Math.sqrt(sumSq / n)) : 0,
      perEntity,
      backtest,
      timings: { dashboardLoadMs: 820, forecastMs: 1380, chatMs: 2100, parse10k: 1850, parse50k: 7600, parse100k: 14900 },
    };
    return HttpResponse.json(res);
  })),
];
